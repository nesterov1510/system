"""Central identity and version information for MSB-CBMRS."""

PROJECT_INFO = {
    "short_name": "MSB-CBMRS",
    "full_name": "Customer Base Management Repair Services",
    "company": "M.E.R.Y.O.S.A.B Electronics",
    "version": "0.9.11",
}

from .project_info import PROJECT_INFO

__all__ = ["PROJECT_INFO"]

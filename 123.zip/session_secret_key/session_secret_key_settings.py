# session_secret_key/session_secret_key_settings.py
"""
Отдельная настройка Flask SECRET_KEY для универсального шаблона.

Зачем отдельная папка:
- чтобы не смешивать session security с on_off_debug;
- чтобы в каждом новом проекте было понятно, где лежит ключ Flask;
- чтобы app.py оставался чистым и шаблонным.

Приоритет получения ключа:
1) переменная окружения SESSION_SECRET_KEY;
2) файл session_secret_key/session_secret_key.env;
3) dev-заглушка dev-only-change-me только для разработки.

Важно:
- сам SESSION_SECRET_KEY никогда не выводится в print/debug/log;
- в логи пишется только статус: найден / не найден / загружен / ошибка.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Optional, Tuple


# ==========================================================
# Подключение нашего debug/log модуля
# ==========================================================
# Важно:
# если файл session_secret_key_settings.py когда-нибудь используют отдельно,
# без папки on_off_debug, приложение не должно падать только из-за логов.
# Поэтому есть fallback-функции.
try:
    from on_off_debug import (
        debug_info_print,
        debug_success_print,
        debug_warning_print,
        debug_error_print,
        critical_error_print,
    )
except Exception:  # pragma: no cover - аварийный fallback без лог-модуля
    def debug_info_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_success_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_warning_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_error_print(message, source: Optional[str] = None) -> None:
        return None

    def critical_error_print(message, source: Optional[str] = None) -> None:
        return None


BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / "session_secret_key.env"

DEFAULT_DEV_SECRET_KEY = "dev-only-change-me"
DEFAULT_MIN_LENGTH = 32

LOG_SOURCE = "session_secret_key.settings"


# ==========================================================
# ENV reader
# ==========================================================

def read_session_secret_key_env(env_path: Optional[str | Path] = None) -> Dict[str, str]:
    """Читает session_secret_key.env без сторонних библиотек."""
    path = Path(env_path) if env_path else ENV_PATH
    data: Dict[str, str] = {}

    if not path.exists():
        debug_warning_print(
            f"Файл session secret env не найден: {path}",
            source=LOG_SOURCE,
        )
        return data

    try:
        with path.open("r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                line = line.strip()

                if not line or line.startswith("#") or "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if not key:
                    debug_warning_print(
                        f"Пропущена строка env без ключа. line={line_number}",
                        source=LOG_SOURCE,
                    )
                    continue

                data[key] = value

        debug_success_print(
            "Файл session_secret_key.env успешно прочитан. Секретные значения не выводятся.",
            source=LOG_SOURCE,
        )

    except Exception as e:
        debug_error_print(
            f"Ошибка чтения session_secret_key.env: {e}",
            source=LOG_SOURCE,
        )
        return {}

    return data


# ==========================================================
# Small env helpers
# ==========================================================

def _env_bool(data: Dict[str, str], key: str, default: bool = False) -> bool:
    value = os.environ.get(key, data.get(key))

    if value is None:
        return default

    value = str(value).strip().lower()
    true_values = {"true", "1", "yes", "y", "on", "enable", "enabled"}
    false_values = {"false", "0", "no", "n", "off", "disable", "disabled"}

    if value in true_values:
        return True
    if value in false_values:
        return False

    debug_warning_print(
        f"Некорректное bool-значение для {key}. Используется default={default}.",
        source=LOG_SOURCE,
    )
    return default


def _env_int(data: Dict[str, str], key: str, default: int) -> int:
    value = os.environ.get(key, data.get(key))

    if value is None:
        return default

    try:
        result = int(str(value).strip())
        if result > 0:
            return result
    except Exception:
        pass

    debug_warning_print(
        f"Некорректное int-значение для {key}. Используется default={default}.",
        source=LOG_SOURCE,
    )
    return default


# ==========================================================
# Secret key loader
# ==========================================================

def _load_secret_key_with_source(data: Dict[str, str]) -> Tuple[str, str]:
    """
    Возвращает SECRET_KEY и источник.

    Источник нужен только для логов:
    - system_environment
    - session_secret_key_env_file
    - development_default

    Сам ключ в логи не пишется.
    """
    system_value = os.environ.get("SESSION_SECRET_KEY")
    if system_value and str(system_value).strip():
        return str(system_value).strip(), "system_environment"

    file_value = data.get("SESSION_SECRET_KEY")
    if file_value and str(file_value).strip():
        return str(file_value).strip(), "session_secret_key_env_file"

    return DEFAULT_DEV_SECRET_KEY, "development_default"


def get_session_secret_key() -> str:
    """
    Возвращает Flask SECRET_KEY.

    В strict-режиме запрещает:
    - пустой ключ;
    - dev-заглушку;
    - слишком короткий ключ.

    Важно:
    сам ключ никогда не выводится в логи.
    """
    data = read_session_secret_key_env()

    secret_key, key_source = _load_secret_key_with_source(data)
    secret_key = str(secret_key).strip()

    strict = _env_bool(data, "SESSION_SECRET_KEY_STRICT", default=False)
    min_length = _env_int(data, "SESSION_SECRET_KEY_MIN_LENGTH", default=DEFAULT_MIN_LENGTH)

    debug_info_print(
        f"Проверка SESSION_SECRET_KEY начата. source={key_source}, strict={strict}, min_length={min_length}",
        source=LOG_SOURCE,
    )

    if not secret_key:
        debug_warning_print(
            "SESSION_SECRET_KEY не загружен: значение пустое.",
            source=LOG_SOURCE,
        )
    elif secret_key == DEFAULT_DEV_SECRET_KEY:
        debug_warning_print(
            "SESSION_SECRET_KEY использует dev-заглушку. Для production это запрещено.",
            source=LOG_SOURCE,
        )
    else:
        debug_success_print(
            f"SESSION_SECRET_KEY загружен. source={key_source}. Сам ключ скрыт.",
            source=LOG_SOURCE,
        )

    if strict:
        if not secret_key:
            critical_error_print(
                "SESSION_SECRET_KEY пустой в strict-режиме. Приложение не должно стартовать в production.",
                source=LOG_SOURCE,
            )
            raise RuntimeError("SESSION_SECRET_KEY пустой. Для production нужен отдельный случайный ключ.")

        if secret_key == DEFAULT_DEV_SECRET_KEY:
            critical_error_print(
                "SESSION_SECRET_KEY оставлен как dev-only-change-me в strict-режиме.",
                source=LOG_SOURCE,
            )
            raise RuntimeError(
                "SESSION_SECRET_KEY оставлен как dev-only-change-me. "
                "Для production сгенерируй ключ: "
                'python -c "import secrets; print(secrets.token_hex(32))"'
            )

        if len(secret_key) < min_length:
            critical_error_print(
                f"SESSION_SECRET_KEY слишком короткий в strict-режиме: length={len(secret_key)}, min={min_length}. Сам ключ скрыт.",
                source=LOG_SOURCE,
            )
            raise RuntimeError(
                f"SESSION_SECRET_KEY слишком короткий: {len(secret_key)} символов. "
                f"Минимум: {min_length}."
            )

        debug_success_print(
            "SESSION_SECRET_KEY прошёл strict-проверку. Сам ключ скрыт.",
            source=LOG_SOURCE,
        )

    return secret_key


# ==========================================================
# Flask apply helper
# ==========================================================

def apply_session_secret_key(app) -> None:
    """
    Применяет SECRET_KEY к Flask-приложению.

    Важно:
    сам ключ никогда не выводится в print/debug/log.
    """
    app.config["SECRET_KEY"] = get_session_secret_key()

    debug_success_print(
        "SECRET_KEY применён к Flask app.config. Сам ключ скрыт.",
        source=LOG_SOURCE,
    )

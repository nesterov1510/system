# start_ip_controll/ip_controll.py

from __future__ import annotations

import ipaddress
import os
import socket
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple


# ==========================================================
# Безопасное подключение on_off_debug
# ==========================================================
try:
    from on_off_debug import (
        debug_info_print,
        debug_success_print,
        debug_warning_print,
        debug_error_print,
        critical_error_print,
    )
except Exception:  # pragma: no cover - fallback, если модуль используют отдельно
    def debug_info_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_success_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_warning_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_error_print(message, source: Optional[str] = None) -> None:
        return None

    def critical_error_print(message, source: Optional[str] = None) -> None:
        return None


BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / "ip_controll.env"

LOG_SOURCE = "start_ip_controll.ip_controll"

DEFAULT_PORT = 5001
LOCAL_HOST = "127.0.0.1"
ALL_INTERFACES_HOST = "0.0.0.0"


@dataclass(frozen=True)
class FlaskStartConfig:
    """Готовая конфигурация для app.run(...)."""

    host: str
    port: int
    local_host_enabled: bool
    all_ip_start_enabled: bool
    allowed_ip_check_enabled: bool
    allowed_start_rules: Tuple[str, ...]
    detected_local_ips: Tuple[str, ...]


# ==========================================================
# ENV reader
# ==========================================================

def read_ip_controll_env(env_path: Optional[str | Path] = None) -> Dict[str, str]:
    """Читает start_ip_controll/ip_controll.env без сторонних библиотек."""
    path = Path(env_path) if env_path else ENV_PATH
    data: Dict[str, str] = {}

    if not path.exists():
        debug_warning_print(
            f"Файл ip_controll.env не найден: {path}. Будут использованы default-настройки.",
            source=LOG_SOURCE,
        )
        return data

    try:
        with path.open("r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                line = line.strip()

                if not line or line.startswith("#") or "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if not key:
                    debug_warning_print(
                        f"Пропущена строка ip_controll.env без ключа. line={line_number}",
                        source=LOG_SOURCE,
                    )
                    continue

                data[key] = value

        debug_success_print(
            "Файл ip_controll.env успешно прочитан.",
            source=LOG_SOURCE,
        )

    except Exception as e:
        debug_error_print(
            f"Ошибка чтения ip_controll.env: {e}",
            source=LOG_SOURCE,
        )
        return {}

    return data


# ==========================================================
# Small helpers
# ==========================================================

def _env_value(data: Dict[str, str], key: str, default: str) -> str:
    value = os.environ.get(key, data.get(key))
    if value is None:
        return default
    value = str(value).strip()
    return value if value else default


def _env_bool(data: Dict[str, str], key: str, default: bool = False) -> bool:
    value = os.environ.get(key, data.get(key))

    if value is None:
        return default

    value = str(value).strip().lower()
    true_values = {"true", "1", "yes", "y", "on", "enable", "enabled", "да", "истина"}
    false_values = {"false", "0", "no", "n", "off", "disable", "disabled", "нет", "ложь"}

    if value in true_values:
        return True
    if value in false_values:
        return False

    message = f"Некорректное bool-значение для {key}: {value}."
    critical_error_print(message, source=LOG_SOURCE)
    raise RuntimeError(message)


def _env_int(data: Dict[str, str], key: str, default: int) -> int:
    value = os.environ.get(key, data.get(key))

    if value is None:
        return default

    try:
        return int(str(value).strip())
    except Exception:
        message = f"Некорректное int-значение для {key}: {value}."
        critical_error_print(message, source=LOG_SOURCE)
        raise RuntimeError(message)


def _csv_list(value: str) -> List[str]:
    if not value:
        return []
    return [item.strip() for item in str(value).split(",") if item.strip()]


def _unique_sorted(values: Sequence[str]) -> Tuple[str, ...]:
    return tuple(sorted({str(item).strip() for item in values if str(item).strip()}))


def _fail_start(message: str) -> None:
    """Останавливает запуск приложения при неправильной start-конфигурации."""
    critical_error_print(message, source=LOG_SOURCE)
    raise RuntimeError(message)


# ==========================================================
# IP helpers
# ==========================================================

def _is_ip_address(value: str) -> bool:
    try:
        ipaddress.ip_address(str(value).strip())
        return True
    except Exception:
        return False


def _is_network_rule(value: str) -> bool:
    return "/" in str(value or "")


def _is_valid_ip_or_network_rule(value: str) -> bool:
    value = str(value or "").strip()

    if not value:
        return False

    try:
        if _is_network_rule(value):
            ipaddress.ip_network(value, strict=False)
        else:
            ipaddress.ip_address(value)
        return True
    except Exception:
        return False


def _ip_matches_rule(ip_value: str, rule: str) -> bool:
    try:
        ip_obj = ipaddress.ip_address(str(ip_value).strip())
        rule = str(rule or "").strip()

        if not rule:
            return False

        if _is_network_rule(rule):
            return ip_obj in ipaddress.ip_network(rule, strict=False)

        return ip_obj == ipaddress.ip_address(rule)

    except Exception:
        return False


def _ip_matches_any_rule(ip_value: str, rules: Sequence[str]) -> bool:
    return any(_ip_matches_rule(ip_value, rule) for rule in rules)


def _get_detected_local_ips() -> Tuple[str, ...]:
    """
    Возвращает IP-адреса текущей машины.

    Не использует внешние библиотеки.
    Интернет для UDP-метода фактически не нужен: сокет только определяет,
    какой локальный интерфейс был бы выбран для выхода наружу.
    """
    found: List[str] = [LOCAL_HOST]

    # 1) IP через UDP route detection
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.2)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        if ip:
            found.append(ip)
    except Exception as e:
        debug_warning_print(
            f"Не удалось определить IP через UDP route detection: {e}",
            source=LOG_SOURCE,
        )

    # 2) IP через hostname
    try:
        hostname = socket.gethostname()
        hostname_ip = socket.gethostbyname(hostname)
        if hostname_ip:
            found.append(hostname_ip)
    except Exception as e:
        debug_warning_print(
            f"Не удалось определить IP через hostname: {e}",
            source=LOG_SOURCE,
        )

    # 3) Все адреса hostname через getaddrinfo
    try:
        hostname = socket.gethostname()
        for item in socket.getaddrinfo(hostname, None):
            ip = item[4][0]
            if ip:
                found.append(ip)
    except Exception as e:
        debug_warning_print(
            f"Не удалось получить список IP через getaddrinfo: {e}",
            source=LOG_SOURCE,
        )

    cleaned = []
    for ip in found:
        ip = str(ip).split("%", 1)[0].strip()
        if _is_ip_address(ip):
            cleaned.append(ip)

    return _unique_sorted(cleaned)


def _validate_allowed_rules(raw_rules: Sequence[str]) -> Tuple[str, ...]:
    valid_rules: List[str] = []

    for rule in raw_rules:
        if _is_valid_ip_or_network_rule(rule):
            valid_rules.append(rule)
            continue

        _fail_start(
            f"MAIN_KAKIYE_IP_RAZRESHEN_DLYA_START содержит некорректное правило: {rule}"
        )

    return tuple(valid_rules)


def _detect_allowed_local_ips(detected_local_ips: Sequence[str], allowed_rules: Sequence[str]) -> Tuple[str, ...]:
    if not allowed_rules:
        return tuple(detected_local_ips)

    matched = [ip for ip in detected_local_ips if _ip_matches_any_rule(ip, allowed_rules)]
    return _unique_sorted(matched)


def _choose_specific_host_from_allowed_ips(allowed_local_ips: Sequence[str]) -> str:
    """
    Выбирает конкретный IP для bind, если запуск на всех IP выключен.

    Предпочитаем не loopback, чтобы сервер мог слушать реальный интерфейс.
    """
    for ip in allowed_local_ips:
        if ip not in {"127.0.0.1", "::1"}:
            return ip

    return LOCAL_HOST


# ==========================================================
# Public loader
# ==========================================================

def get_flask_start_config() -> FlaskStartConfig:
    """
    Возвращает готовые host/port для Flask app.run(...).

    Приоритет настроек:
    1) системные переменные окружения;
    2) start_ip_controll/ip_controll.env;
    3) default-значения.
    """
    data = read_ip_controll_env()

    main_local_host = _env_bool(data, "MAIN_LOCAL_HOST", default=True)
    main_na_vceh_ip_start = _env_bool(data, "MAIN_NA_VCEH_IP_START", default=False)
    main_allowed_ip_check = _env_bool(data, "MAIN_RAZRESHENNIYE_IP_PROVERKA", default=False)

    raw_allowed_rules = _csv_list(
        _env_value(data, "MAIN_KAKIYE_IP_RAZRESHEN_DLYA_START", "")
    )

    port = _env_int(data, "MAIN_START_PORT", DEFAULT_PORT)

    if port < 1 or port > 65535:
        _fail_start(f"MAIN_START_PORT={port} вне системного диапазона 1-65535.")

    detected_local_ips = _get_detected_local_ips()

    if main_allowed_ip_check:
        allowed_rules = _validate_allowed_rules(raw_allowed_rules)
        allowed_local_ips = _detect_allowed_local_ips(detected_local_ips, allowed_rules)
    else:
        allowed_rules = tuple()
        allowed_local_ips = tuple(detected_local_ips)

    debug_info_print(
        (
            "Проверка MAIN Flask start config начата. "
            f"MAIN_LOCAL_HOST={main_local_host}, "
            f"MAIN_NA_VCEH_IP_START={main_na_vceh_ip_start}, "
            f"MAIN_RAZRESHENNIYE_IP_PROVERKA={main_allowed_ip_check}, "
            f"MAIN_START_PORT={port}"
        ),
        source=LOG_SOURCE,
    )

    debug_info_print(
        f"Обнаруженные IP сервера: {list(detected_local_ips)}",
        source=LOG_SOURCE,
    )

    if main_allowed_ip_check:
        if not allowed_rules:
            _fail_start(
                "MAIN_RAZRESHENNIYE_IP_PROVERKA=True, но "
                "MAIN_KAKIYE_IP_RAZRESHEN_DLYA_START пустой. "
                "Укажи IP/сеть или выключи проверку: MAIN_RAZRESHENNIYE_IP_PROVERKA=False."
            )

        debug_info_print(
            f"Проверка разрешённых IP/сетей включена. Правила: {list(allowed_rules)}",
            source=LOG_SOURCE,
        )

        if not allowed_local_ips:
            _fail_start(
                "Ни один IP текущего сервера не входит в "
                f"MAIN_KAKIYE_IP_RAZRESHEN_DLYA_START={list(allowed_rules)}. "
                f"Обнаруженные IP: {list(detected_local_ips)}"
            )
    else:
        debug_warning_print(
            (
                "MAIN_RAZRESHENNIYE_IP_PROVERKA=False: "
                "проверка MAIN_KAKIYE_IP_RAZRESHEN_DLYA_START выключена, список IP/сетей игнорируется."
            ),
            source=LOG_SOURCE,
        )

    # ------------------------------------------------------
    # Host decision
    # ------------------------------------------------------
    if main_na_vceh_ip_start:
        host = ALL_INTERFACES_HOST
        debug_warning_print(
            (
                "MAIN_NA_VCEH_IP_START=True: Flask будет слушать все интерфейсы сервера. "
                "Открывать надо через 127.0.0.1 или реальный IP сервера, не через 0.0.0.0."
            ),
            source=LOG_SOURCE,
        )

    elif main_local_host:
        host = LOCAL_HOST
        debug_info_print(
            "MAIN_LOCAL_HOST=True: Flask будет доступен только локально внутри этого ПК/сервера.",
            source=LOG_SOURCE,
        )

    elif allowed_local_ips:
        host = _choose_specific_host_from_allowed_ips(allowed_local_ips)
        debug_info_print(
            f"Выбран конкретный разрешённый IP для запуска Flask: {host}",
            source=LOG_SOURCE,
        )

    else:
        _fail_start(
            "Не удалось выбрать host для запуска Flask: "
            "MAIN_NA_VCEH_IP_START=False, MAIN_LOCAL_HOST=False, "
            "и нет подходящего разрешённого IP."
        )

    debug_success_print(
        (
            "MAIN Flask start config готов: "
            f"host={host}, port={port}, "
            f"MAIN_LOCAL_HOST={main_local_host}, "
            f"MAIN_NA_VCEH_IP_START={main_na_vceh_ip_start}, "
            f"MAIN_RAZRESHENNIYE_IP_PROVERKA={main_allowed_ip_check}"
        ),
        source=LOG_SOURCE,
    )

    return FlaskStartConfig(
        host=host,
        port=port,
        local_host_enabled=main_local_host,
        all_ip_start_enabled=main_na_vceh_ip_start,
        allowed_ip_check_enabled=main_allowed_ip_check,
        allowed_start_rules=allowed_rules,
        detected_local_ips=detected_local_ips,
    )

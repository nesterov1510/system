# access_control/access_settings.py
"""
Access Control core для универсального Flask-шаблона.

Этот файл НЕ регистрирует routes напрямую.
Routes и static подключаются через Blueprint в access_control/blueprint.py.

Имена настроек только MAIN_ACCESS_*.
Логи только через on_off_debug.
Flask SECRET_KEY здесь НЕ меняется — им управляет session_secret_key/.
"""
from __future__ import annotations

import ipaddress
import os
import time
from pathlib import Path
from typing import Dict, Optional

from flask import request, render_template, redirect, url_for, session, g

from access_control.user_store import (
    authenticate, get_user,
    get_login_lock_status_db, register_failed_login_db, clear_failed_logins_db, clear_user_login_attempts_db,
)


# ==========================================================
# Безопасное подключение on_off_debug
# ==========================================================
try:
    from on_off_debug import (
        debug_info_print,
        debug_success_print,
        debug_warning_print,
        debug_error_print,
        debug_error1_print,
        critical_error_print,
    )
except Exception:  # pragma: no cover
    def debug_info_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_success_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_warning_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_error_print(message, source: Optional[str] = None) -> None:
        return None

    def debug_error1_print(message, source: Optional[str] = None) -> None:
        return None

    def critical_error_print(message, source: Optional[str] = None) -> None:
        return None


BASE_DIR = Path(__file__).resolve().parent
ACCESS_ENV_PATH = BASE_DIR / "access.env"

LOG_SOURCE = "access_control.access_settings"

ACCESS_CONFIG: Dict = {}
ACCESS_CONFIG_LOADED = False


ACCESS_EXEMPT_ENDPOINTS = {
    # main app static
    "static",

    # access_control blueprint
    "access_control.static",
    "access_control.access_control_page",
    "access_control.access_control_page_legacy",
    "access_control.access_control_page_hyphen",
    "access_control.access_login_route",
    "access_control.access_logout_route",
}


# ==========================================================
# ENV reader
# ==========================================================

def read_access_env_file() -> Dict[str, str]:
    """
    Читает access_control/access.env без сторонних библиотек.

    Здесь НЕ пишем success-лог, потому что эта функция может быть вызвана
    внутри запроса. Успешную загрузку логирует только reload_access_config(log=True).
    """
    data: Dict[str, str] = {}

    if not ACCESS_ENV_PATH.exists():
        return data

    try:
        with ACCESS_ENV_PATH.open("r", encoding="utf-8", errors="ignore") as file:
            for line_number, line in enumerate(file, start=1):
                clean = line.strip()

                if not clean or clean.startswith("#") or "=" not in clean:
                    continue

                key, value = clean.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if not key:
                    debug_warning_print(
                        f"Пропущена строка access.env без ключа. line={line_number}",
                        source=LOG_SOURCE,
                    )
                    continue

                data[key] = value

    except Exception as e:
        debug_error_print(
            f"Ошибка чтения access.env: {e}",
            source=LOG_SOURCE,
        )
        return {}

    return data


def _raw_env_value(data: Dict[str, str], name: str, default: str = "") -> str:
    """
    Возвращает значение только по новому имени MAIN_ACCESS_*.
    Старые ACCESS_* намеренно не используются, чтобы в шаблоне не было каши.
    """
    value = os.environ.get(name, data.get(name, default))
    return str(value or "").strip()


def access_env_bool(data: Dict[str, str], name: str, default: str = "1") -> bool:
    value = _raw_env_value(data, name, default).lower()
    return value not in {"0", "false", "no", "off", "disable", "disabled", "нет", "ложь"}


def access_env_int(data: Dict[str, str], name: str, default: str = "12") -> int:
    value = _raw_env_value(data, name, default)

    try:
        return int(str(value).strip())
    except Exception:
        debug_warning_print(
            f"Некорректное int-значение {name}. Используется default={default}.",
            source=LOG_SOURCE,
        )
        return int(default)


def access_env_str(data: Dict[str, str], name: str, default: str = "") -> str:
    return _raw_env_value(data, name, default)


def parse_access_list(value: str) -> list[str]:
    if not value:
        return []

    return [
        item.strip()
        for item in value.replace("\n", ",").split(",")
        if item.strip()
    ]


def build_access_config(data: Dict[str, str]) -> Dict:
    """
    Собирает конфиг только из MAIN_ACCESS_*.
    """
    return {
        "enabled": access_env_bool(data, "MAIN_ACCESS_ENABLED", "1"),
        "username": access_env_str(data, "MAIN_ACCESS_USERNAME", "admin"),

        "password": access_env_str(data, "MAIN_ACCESS_PASSWORD", ""),
        "password_hash": access_env_str(data, "MAIN_ACCESS_PASSWORD_HASH", ""),

        "allowed_ips_raw": access_env_str(data, "MAIN_ACCESS_ALLOWED_IPS", "127.0.0.1,::1"),
        "allowed_ips": parse_access_list(
            access_env_str(data, "MAIN_ACCESS_ALLOWED_IPS", "127.0.0.1,::1")
        ),
        "trust_proxy": access_env_bool(data, "MAIN_ACCESS_TRUST_PROXY", "0"),
        "session_hours": access_env_int(data, "MAIN_ACCESS_SESSION_HOURS", "12"),
        "database_url": access_env_str(data, "MAIN_ACCESS_DATABASE_URL", ""),

        # Отдельный access secret. Не применяем к Flask SECRET_KEY.
        "access_secret_key": access_env_str(data, "MAIN_ACCESS_SECRET_KEY", ""),

        "log_failed": access_env_bool(data, "MAIN_ACCESS_LOG_FAILED", "1"),

        "max_failed_attempts": access_env_int(data, "MAIN_ACCESS_MAX_FAILED_ATTEMPTS", "5"),
        "failed_window_minutes": access_env_int(data, "MAIN_ACCESS_FAILED_WINDOW_MINUTES", "10"),
        "lock_minutes": access_env_int(data, "MAIN_ACCESS_LOCK_MINUTES", "15"),
        "failed_delay_seconds": access_env_int(data, "MAIN_ACCESS_FAILED_DELAY_SECONDS", "1"),

        # One-time emergency recovery. This is consumed at startup and then
        # automatically disabled/cleared in access.env. Ordinary authentication
        # never uses these values.
        "recovery_on_start": access_env_bool(data, "MAIN_ACCESS_RECOVERY_ON_START", "0"),
        "recovery_username": access_env_str(data, "MAIN_ACCESS_RECOVERY_USERNAME", ""),
        "recovery_password": access_env_str(data, "MAIN_ACCESS_RECOVERY_PASSWORD", ""),
    }


def reload_access_config(log: bool = False) -> Dict:
    """
    Перезагружает конфиг доступа.

    log=True использовать только при старте или ручной перезагрузке.
    Не использовать log=True внутри каждого request.
    """
    global ACCESS_CONFIG, ACCESS_CONFIG_LOADED

    data = read_access_env_file()
    config = build_access_config(data)

    ACCESS_CONFIG = config
    ACCESS_CONFIG_LOADED = True

    if log:
        if ACCESS_ENV_PATH.exists():
            debug_success_print(
                "access.env успешно прочитан. Секретные значения не выводятся.",
                source=LOG_SOURCE,
            )
        else:
            debug_warning_print(
                f"access.env не найден: {ACCESS_ENV_PATH}. Используются default-настройки.",
                source=LOG_SOURCE,
            )

        if config.get("password_hash"):
            debug_success_print(
                "MAIN_ACCESS_PASSWORD_HASH загружен. Hash не выводится.",
                source=LOG_SOURCE,
            )
        else:
            debug_warning_print(
                "MAIN_ACCESS_PASSWORD_HASH пустой. Будет использован MAIN_ACCESS_PASSWORD, если он задан.",
                source=LOG_SOURCE,
            )

        if config.get("access_secret_key"):
            debug_success_print(
                "MAIN_ACCESS_SECRET_KEY загружен. Значение скрыто. Flask SECRET_KEY управляется session_secret_key/.",
                source=LOG_SOURCE,
            )
        else:
            debug_warning_print(
                "MAIN_ACCESS_SECRET_KEY пустой. Flask SECRET_KEY всё равно управляется session_secret_key/.",
                source=LOG_SOURCE,
            )

        debug_success_print(
            (
                "Access Control config готов: "
                f"enabled={config['enabled']}, "
                f"trust_proxy={config['trust_proxy']}, "
                f"session_hours={config['session_hours']}, "
                f"allowed_ips_count={len(config['allowed_ips'])}"
            ),
            source=LOG_SOURCE,
        )

    return config


def get_access_config() -> Dict:
    """
    Возвращает кешированный access config.

    Здесь нет success-логов, потому что функция вызывается на каждый request.
    """
    if not ACCESS_CONFIG_LOADED:
        return reload_access_config(log=False)

    return ACCESS_CONFIG


# ==========================================================
# Request helpers
# ==========================================================

def get_client_ip() -> str:
    config = get_access_config()

    if config["trust_proxy"]:
        forwarded_for = request.headers.get("X-Forwarded-For", "").strip()
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()

        real_ip = request.headers.get("X-Real-IP", "").strip()
        if real_ip:
            return real_ip

    return request.remote_addr or "unknown"


def is_ip_allowed(ip_text: str) -> bool:
    config = get_access_config()
    allowed_items = config["allowed_ips"]

    if not allowed_items:
        return False

    if "*" in allowed_items:
        return True

    try:
        client_ip = ipaddress.ip_address(ip_text)
    except Exception:
        return False

    for item in allowed_items:
        try:
            if "/" in item:
                if client_ip in ipaddress.ip_network(item, strict=False):
                    return True
            else:
                if client_ip == ipaddress.ip_address(item):
                    return True
        except Exception:
            debug_warning_print(
                f"Некорректное правило MAIN_ACCESS_ALLOWED_IPS пропущено: {item}",
                source=LOG_SOURCE,
            )
            continue

    return False


def is_safe_next_url(next_url: str) -> bool:
    return bool(
        next_url
        and next_url.startswith("/")
        and not next_url.startswith("//")
    )


def get_current_access_user() -> dict | None:
    """Returns the current database user, cached for the lifetime of one request."""
    if getattr(g, "_access_user_loaded", False):
        return getattr(g, "_access_user", None)

    user_id = session.get("access_user_id")
    user = None
    if user_id:
        try:
            user = get_user(int(user_id))
        except Exception:
            user = None

    g._access_user = user
    g._access_user_loaded = True
    return user


def is_access_logged_in() -> bool:
    config = get_access_config()

    if not config["enabled"]:
        return True

    if not session.get("access_logged_in"):
        return False

    login_at = session.get("access_login_at")
    if not login_at:
        session.clear()
        return False

    try:
        max_age = max(1, int(config["session_hours"])) * 3600
        if time.time() - float(login_at) > max_age:
            username = session.get("access_user", "unknown")
            ip_text = session.get("access_ip", "unknown")
            session.clear()
            debug_warning_print(
                f"SESSION EXPIRED | ip={ip_text} | username={username}",
                source=LOG_SOURCE,
            )
            return False
    except Exception as e:
        session.clear()
        debug_error1_print(f"Ошибка проверки срока session: {e}", source=LOG_SOURCE)
        return False

    # Database re-check makes disabling an account effective on the next request.
    user = get_current_access_user()
    if not user or not user.get("is_active") or user.get("is_archived"):
        session.clear()
        return False

    return True


# ==========================================================
# Route-level permission map
# ==========================================================

ROUTE_VIEW_PERMISSIONS = {
    "dashboard": "dashboard.view",
    "wse_remonty": "repairs.view",
    "priemka": "repairs.create",
    "klienty": "clients.view",
    "sklad": "warehouse.view",
    "donors": "donors.view",
    "oplata": "payments.view",
    "call_center": "callcenter.view",
    "chat": "chat.use",
    "notifications": "notifications.view",
    "print_center": "print.use",
    "sms": "sms.use",
    "ai": "ai.use",
    "reports": "reports.view",
    "admin": "admin.view",
}

def _permission_for_endpoint(endpoint: str) -> str | None:
    prefix = (endpoint or "").split(".", 1)[0]
    return ROUTE_VIEW_PERMISSIONS.get(prefix)


# ==========================================================
# Protect hook
# ==========================================================

def protect_admin_routes():
    config = get_access_config()

    if not config["enabled"]:
        return None

    endpoint = request.endpoint or ""

    if endpoint in ACCESS_EXEMPT_ENDPOINTS:
        return None

    current_ip = get_client_ip()

    if not is_ip_allowed(current_ip):
        critical_error_print(
            f"BLOCKED IP | ip={current_ip} | path={request.path} | endpoint={endpoint}",
            source=LOG_SOURCE,
        )

        return redirect(url_for(
            "access_control.access_control_page",
            error=f"Доступ запрещён для IP: {current_ip}",
            next=request.full_path if request.query_string else request.path,
        ))

    if not is_access_logged_in():
        return redirect(url_for(
            "access_control.access_control_page",
            msg="Сначала войдите в систему.",
            next=request.full_path if request.query_string else request.path,
        ))

    required_permission = _permission_for_endpoint(endpoint)
    if required_permission:
        from access_control.user_store import has_permission
        user = get_current_access_user()
        if not has_permission(user, required_permission):
            return render_template(
                "access_control/forbidden.html",
                required_permission=required_permission,
                current_user=user,
            ), 403

    return None


# ==========================================================
# Pages
# ==========================================================

def render_access_page(
    error_message: str = "",
    system_message: str = "",
    login_value: str = "",
    next_url: str = "/",
):
    current_ip = get_client_ip()
    config = get_access_config()

    if is_access_logged_in():
        # Logged-in users are routed to the management screen by access_control_page.
        return redirect(url_for("access_control.access_control_page"))

    return render_template(
        "access_control/access-login.html",
        session_user=session.get("access_user"),
        is_logged_in=False,
        system_message=system_message,
        error_message=error_message,
        login_value=login_value,
        next_url=next_url if is_safe_next_url(next_url) else "/",
        access_enabled=config["enabled"],
        access_current_ip=current_ip,
        access_ip_allowed=is_ip_allowed(current_ip),
        access_allowed_ips=config["allowed_ips_raw"],
        access_trust_proxy=config["trust_proxy"],
        access_session_hours=config["session_hours"],
    )


def access_control_page():
    error_message = request.args.get("error", "").strip()
    system_message = request.args.get("msg", "").strip()
    next_url = request.args.get("next", "/").strip() or "/"

    current_ip = get_client_ip()
    if not is_ip_allowed(current_ip):
        error_message = error_message or f"Доступ запрещён для IP: {current_ip}"
        # Never expose the management console from a disallowed network, even if
        # the browser still carries a previously valid session cookie.
        session.clear()
        return render_access_page(
            error_message=error_message,
            system_message=system_message,
            next_url=next_url,
        )

    if is_access_logged_in():
        from access_control.management import render_user_management
        return render_user_management(system_message=system_message, error_message=error_message)

    return render_access_page(
        error_message=error_message,
        system_message=system_message,
        next_url=next_url,
    )


# ==========================================================
# Anti brute-force
# ==========================================================

def get_login_lock_status(username: str, ip_text: str) -> dict:
    return get_login_lock_status_db(username=username, ip_text=ip_text)

def register_failed_login(username: str, ip_text: str) -> dict:
    config = get_access_config()
    max_failed = max(1, int(config["max_failed_attempts"]))
    window_seconds = max(60, int(config["failed_window_minutes"]) * 60)
    lock_seconds = max(60, int(config["lock_minutes"]) * 60)
    result = register_failed_login_db(
        username=username,
        ip_text=ip_text,
        max_failed=max_failed,
        window_seconds=window_seconds,
        lock_seconds=lock_seconds,
    )
    if result["locked"]:
        critical_error_print(
            f"BRUTE-FORCE LOCK | ip={ip_text} | username={username} | locked_seconds={result['remaining_seconds']}",
            source=LOG_SOURCE,
        )
    return result

def clear_failed_logins(username: str, ip_text: str) -> None:
    clear_failed_logins_db(username=username, ip_text=ip_text)

def format_lock_time(seconds: int) -> str:
    seconds = max(0, int(seconds))

    minutes = seconds // 60
    rest_seconds = seconds % 60

    if minutes <= 0:
        return f"{rest_seconds} сек."

    return f"{minutes} мин. {rest_seconds} сек."


def consume_one_time_recovery(config: Dict) -> bool:
    """Disable and erase one-time recovery credentials after DB recovery.

    Recovery is intentionally stored in the normal Access Control config so no
    separate reset program or alternate user database exists. After a successful
    startup recovery the switch is turned off and the plaintext recovery password
    is removed from access.env atomically.
    """
    if not config.get("_recovery_applied"):
        return False

    updates = {
        "MAIN_ACCESS_RECOVERY_ON_START": "0",
        "MAIN_ACCESS_RECOVERY_PASSWORD": "",
    }
    try:
        lines = ACCESS_ENV_PATH.read_text(encoding="utf-8").splitlines() if ACCESS_ENV_PATH.exists() else []
        found = set()
        out = []
        for line in lines:
            stripped = line.strip()
            replaced = False
            if stripped and not stripped.startswith("#") and "=" in line:
                key = line.split("=", 1)[0].strip()
                if key in updates:
                    out.append(f"{key}={updates[key]}")
                    found.add(key)
                    replaced = True
            if not replaced:
                out.append(line)
        for key, value in updates.items():
            if key not in found:
                out.append(f"{key}={value}")

        tmp = ACCESS_ENV_PATH.with_suffix(".env.tmp")
        tmp.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
        os.replace(tmp, ACCESS_ENV_PATH)
        debug_success_print(
            "Одноразовое восстановление Супер Админа выполнено; recovery-флаг выключен, открытый recovery-пароль удалён из access.env.",
            source=LOG_SOURCE,
        )
        return True
    except Exception as exc:
        critical_error_print(
            f"Пароль в БД восстановлен, но не удалось выключить recovery в access.env: {exc}. Немедленно установите MAIN_ACCESS_RECOVERY_ON_START=0 и очистите MAIN_ACCESS_RECOVERY_PASSWORD.",
            source=LOG_SOURCE,
        )
        return False


# ==========================================================
# Login / logout
# ==========================================================

def access_login_route():
    config = get_access_config()
    current_ip = get_client_ip()

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    remember = request.form.get("remember", "").strip() == "1"
    next_url = request.form.get("next", "/").strip() or "/"

    if not config["enabled"]:
        return redirect(next_url if is_safe_next_url(next_url) else "/")

    if not is_ip_allowed(current_ip):
        critical_error_print(f"LOGIN BLOCKED BY IP | ip={current_ip} | username={username}", source=LOG_SOURCE)
        return render_access_page(
            error_message=f"Ваш IP не разрешён: {current_ip}",
            login_value=username,
            next_url=next_url,
        )

    lock_status = get_login_lock_status(username=username, ip_text=current_ip)

    # Important: a lock must throttle wrong passwords, not permanently block a
    # legitimate owner who now knows the correct DB password. We still verify
    # the password while locked (PBKDF2 is intentionally expensive), and an
    # invalid locked attempt is additionally delayed below. A correct password
    # immediately clears all anti-brute-force rows for this account/current IP.
    user = authenticate(username, password)
    if user:
        clear_failed_logins(username=username, ip_text=current_ip)
        clear_user_login_attempts_db(user, ip_text=current_ip)
        session.clear()
        session["access_logged_in"] = True
        session["access_user_id"] = int(user["id"])
        session["access_user"] = user["username"]
        session["access_role"] = user["role"]
        session["access_login_at"] = str(time.time())
        session["access_ip"] = current_ip
        session.permanent = remember
        debug_success_print(
            f"LOGIN OK | ip={current_ip} | username={user['username']} | role={user['role']} | remember={remember}",
            source=LOG_SOURCE,
        )
        return redirect(next_url if is_safe_next_url(next_url) else "/")

    if lock_status["locked"]:
        # Keep a hard delay for every wrong password during an active lock.
        # This preserves brute-force throttling while allowing the real owner
        # to recover instantly with the correct password.
        delay_seconds = max(2, int(config.get("failed_delay_seconds", 1)))
        time.sleep(delay_seconds)
        if config["log_failed"]:
            debug_warning_print(
                f"LOGIN STILL LOCKED | ip={current_ip} | username={username} | remaining_seconds={lock_status['remaining_seconds']}",
                source=LOG_SOURCE,
            )
        return render_access_page(
            error_message=(
                "Слишком много неправильных попыток входа. "
                f"Правильный пароль снимет блокировку сразу; для неверного пароля осталось ждать "
                f"{format_lock_time(lock_status['remaining_seconds'])}."
            ),
            login_value=username,
            next_url=next_url,
        )

    failed_info = register_failed_login(username=username, ip_text=current_ip)
    delay_seconds = max(0, int(config.get("failed_delay_seconds", 1)))
    if delay_seconds:
        time.sleep(delay_seconds)
    if config["log_failed"]:
        debug_warning_print(
            f"LOGIN FAILED | ip={current_ip} | username={username} | remaining_attempts={failed_info['remaining_attempts']} | locked={failed_info['locked']}",
            source=LOG_SOURCE,
        )
    if failed_info["locked"]:
        error_message = (
            "Слишком много неправильных попыток входа. "
            f"Доступ временно заблокирован на {format_lock_time(failed_info['remaining_seconds'])}"
        )
    else:
        error_message = f"Неверный логин или пароль. Осталось попыток: {failed_info['remaining_attempts']}"
    return render_access_page(
        error_message=error_message,
        login_value=username,
        next_url=next_url,
    )


def access_logout_route():
    current_ip = get_client_ip()
    username = session.get("access_user", "unknown")

    session.clear()

    debug_info_print(
        f"LOGOUT | ip={current_ip} | username={username}",
        source=LOG_SOURCE,
    )

    return redirect(
        url_for("access_control.access_control_page", msg="Вы вышли из системы.")
    )

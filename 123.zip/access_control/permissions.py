"""Roles and granular permissions for MSB-CBMRS Access Control."""
from __future__ import annotations

from collections import OrderedDict

ROLE_LABELS = OrderedDict([
    ("super_admin", "Супер Админ"),
    ("admin", "Админ"),
    ("manager", "Менеджер"),
    ("operator", "Оператор"),
    ("master", "Мастер"),
    ("master_assistant", "Помощник мастера"),
    ("accountant", "Бухгалтер"),
    ("reader", "Читатель"),
])

PERMISSION_GROUPS = OrderedDict([
    ("Панель", OrderedDict([
        ("dashboard.view", "Открывать панель"),
        ("finance.view", "Видеть финансовые показатели"),
    ])),
    ("Ремонты", OrderedDict([
        ("repairs.view", "Просматривать ремонты"),
        ("repairs.create", "Создавать приёмку / ремонт"),
        ("repairs.edit", "Редактировать ремонт"),
        ("repairs.status", "Менять статус ремонта"),
        ("repairs.assign", "Назначать мастеров"),
        ("repairs.delete", "Удалять / архивировать ремонт"),
    ])),
    ("Клиенты", OrderedDict([
        ("clients.view", "Просматривать клиентов"),
        ("clients.create", "Добавлять клиентов"),
        ("clients.edit", "Редактировать клиентов"),
        ("clients.delete", "Удалять / объединять клиентов"),
    ])),
    ("Склад и доноры", OrderedDict([
        ("warehouse.view", "Просматривать склад"),
        ("warehouse.edit", "Изменять склад и остатки"),
        ("donors.view", "Просматривать донорскую технику"),
        ("donors.edit", "Изменять донорскую технику"),
    ])),
    ("Деньги", OrderedDict([
        ("payments.view", "Просматривать оплаты"),
        ("payments.create", "Принимать / добавлять оплату"),
        ("payments.refund", "Возвраты и корректировки"),
        ("expenses.manage", "Добавлять и изменять расходы"),
    ])),
    ("Коммуникации", OrderedDict([
        ("callcenter.view", "Открывать Call-центр"),
        ("callcenter.manage", "Управлять очередью Call-центра"),
        ("chat.use", "Пользоваться внутренним чатом"),
        ("notifications.view", "Просматривать уведомления"),
        ("sms.use", "Отправлять SMS"),
        ("sms.manage", "Настраивать SMS"),
    ])),
    ("Печать и отчёты", OrderedDict([
        ("print.use", "Печатать документы / этикетки"),
        ("print.manage", "Управлять принтерами и шаблонами"),
        ("reports.view", "Просматривать отчёты"),
        ("reports.export", "Экспортировать отчёты"),
        ("ai.use", "Использовать AI-функции"),
    ])),
    ("Администрирование", OrderedDict([
        ("admin.view", "Открывать администрирование"),
        ("users.view", "Просматривать пользователей"),
        ("users.create", "Добавлять пользователей"),
        ("users.edit", "Редактировать пользователей и права"),
        ("users.disable", "Блокировать / активировать пользователей"),
        ("users.delete", "Архивировать пользователей"),
        ("roles.manage", "Назначать роли"),
        ("access.settings", "Изменять настройки доступа"),
        ("audit.view", "Просматривать аудит действий"),
    ])),
])

ALL_PERMISSIONS = tuple(
    permission
    for group in PERMISSION_GROUPS.values()
    for permission in group.keys()
)

ROLE_DEFAULT_PERMISSIONS = {
    "super_admin": set(ALL_PERMISSIONS),
    "admin": set(ALL_PERMISSIONS) - {"users.delete"},
    "manager": {
        "dashboard.view", "finance.view",
        "repairs.view", "repairs.create", "repairs.edit", "repairs.status", "repairs.assign",
        "clients.view", "clients.create", "clients.edit",
        "warehouse.view", "warehouse.edit", "donors.view", "donors.edit",
        "payments.view", "payments.create", "expenses.manage",
        "callcenter.view", "callcenter.manage", "chat.use", "notifications.view",
        "sms.use", "print.use", "reports.view", "reports.export", "ai.use",
    },
    "operator": {
        "dashboard.view", "repairs.view", "repairs.create", "repairs.edit", "repairs.status",
        "clients.view", "clients.create", "clients.edit", "warehouse.view",
        "payments.view", "payments.create", "callcenter.view", "callcenter.manage",
        "chat.use", "notifications.view", "sms.use", "print.use",
    },
    "master": {
        "dashboard.view", "repairs.view", "repairs.edit", "repairs.status",
        "clients.view", "warehouse.view", "donors.view", "chat.use",
        "notifications.view", "print.use",
    },
    "master_assistant": {
        "dashboard.view", "repairs.view", "repairs.edit", "clients.view",
        "warehouse.view", "donors.view", "chat.use", "notifications.view",
    },
    "accountant": {
        "dashboard.view", "finance.view", "repairs.view", "clients.view",
        "payments.view", "payments.create", "payments.refund", "expenses.manage",
        "reports.view", "reports.export", "notifications.view",
    },
    "reader": {
        "dashboard.view", "repairs.view", "clients.view", "warehouse.view", "donors.view",
        "reports.view",
    },
}


def normalize_role(role: str) -> str:
    role = (role or "reader").strip().lower()
    return role if role in ROLE_LABELS else "reader"


def sanitize_permissions(values) -> list[str]:
    allowed = set(ALL_PERMISSIONS)
    unique = []
    seen = set()
    for value in values or []:
        value = str(value).strip()
        if value in allowed and value not in seen:
            unique.append(value)
            seen.add(value)
    return unique


def default_permissions_for(role: str) -> list[str]:
    role = normalize_role(role)
    values = ROLE_DEFAULT_PERMISSIONS.get(role, set())
    return [permission for permission in ALL_PERMISSIONS if permission in values]


def role_label(role: str) -> str:
    return ROLE_LABELS.get(normalize_role(role), "Читатель")

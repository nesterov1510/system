# access_control/__init__.py
"""Public API for the access_control module."""

# init_access_control lives in blueprint.py because it registers the
# Blueprint and the before_request protection hook on a Flask app.
from .blueprint import init_access_control
from .access_settings import (
    get_access_config,
    is_access_logged_in,
    get_client_ip,
    is_ip_allowed,
)

__all__ = [
    "init_access_control",
    "get_access_config",
    "is_access_logged_in",
    "get_client_ip",
    "is_ip_allowed",
]

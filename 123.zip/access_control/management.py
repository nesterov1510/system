"""User and permission management UI/actions for /access-control/."""
from __future__ import annotations

import secrets
from functools import wraps
from pathlib import Path

from flask import abort, redirect, render_template, request, send_from_directory, session, url_for
from werkzeug.utils import secure_filename

from .access_settings import get_client_ip, get_current_access_user
from .permissions import (
    ALL_PERMISSIONS,
    PERMISSION_GROUPS,
    ROLE_DEFAULT_PERMISSIONS,
    ROLE_LABELS,
    default_permissions_for,
)
from .user_store import (
    archive_user,
    count_active_users,
    count_active_super_admins,
    create_user,
    get_user,
    has_permission,
    list_users,
    set_user_active,
    update_user,
)


PASSPORT_DIR = Path(__file__).resolve().parent / "data" / "passports"
PASSPORT_ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".webp"}
PASSPORT_MAX_BYTES = 10 * 1024 * 1024


def _save_passport_upload(file_storage) -> tuple[str, str]:
    if file_storage is None or not getattr(file_storage, "filename", ""):
        raise ValueError("Файл паспорта не выбран.")
    original = secure_filename(file_storage.filename or "")
    if not original:
        raise ValueError("Некорректное имя файла паспорта.")
    ext = Path(original).suffix.lower()
    if ext not in PASSPORT_ALLOWED_EXTENSIONS:
        raise ValueError("Паспорт: разрешены PDF, JPG, JPEG, PNG и WebP.")
    stream = file_storage.stream
    try:
        stream.seek(0, 2)
        size = stream.tell()
        stream.seek(0)
    except Exception:
        size = 0
    if size <= 0:
        raise ValueError("Файл паспорта пустой.")
    if size > PASSPORT_MAX_BYTES:
        raise ValueError("Файл паспорта слишком большой. Максимум 10 МБ.")
    PASSPORT_DIR.mkdir(parents=True, exist_ok=True)
    stored = f"{secrets.token_hex(20)}{ext}"
    file_storage.save(PASSPORT_DIR / stored)
    return stored, original


def _remove_passport(stored_name: str | None) -> None:
    if not stored_name:
        return
    try:
        target = (PASSPORT_DIR / Path(stored_name).name)
        if target.is_file():
            target.unlink()
    except Exception:
        pass



def current_user() -> dict | None:
    return get_current_access_user()


def _csrf_token() -> str:
    token = session.get("access_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["access_csrf_token"] = token
    return token


def _verify_csrf() -> None:
    expected = session.get("access_csrf_token") or ""
    provided = request.form.get("csrf_token", "")
    if not expected or not secrets.compare_digest(expected, provided):
        abort(400, description="CSRF token is invalid")


def require_permission(permission: str):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            user = current_user()
            if not has_permission(user, permission):
                return render_template(
                    "access_control/forbidden.html",
                    required_permission=permission,
                    current_user=user,
                ), 403
            return fn(*args, **kwargs)
        return wrapped
    return decorator


def _actor_can_manage_target(actor: dict, target: dict | None, requested_role: str | None = None) -> None:
    if actor.get("role") == "super_admin":
        return
    if target and target.get("role") == "super_admin":
        abort(403, description="Только Супер Админ может изменять Супер Админа.")
    if requested_role == "super_admin":
        abort(403, description="Только Супер Админ может назначать роль Супер Админ.")


def _form_payload() -> dict:
    return {
        "username": request.form.get("username", ""),
        "password": request.form.get("password", ""),
        "new_password": request.form.get("new_password", ""),
        "confirm_password": request.form.get("confirm_password", ""),
        "first_name": request.form.get("first_name", ""),
        "last_name": request.form.get("last_name", ""),
        "birth_date": request.form.get("birth_date", ""),
        "email": request.form.get("email", ""),
        "phone": request.form.get("phone", ""),
        "role": request.form.get("role", "reader"),
        "permissions": request.form.getlist("permissions"),
        "permissions_explicit": request.form.get("permissions_explicit", "") == "1",
        "is_active": request.form.get("is_active", "1") == "1",
    }


def render_user_management(system_message: str = "", error_message: str = ""):
    user = current_user()
    if not has_permission(user, "users.view"):
        return render_template(
            "access_control/forbidden.html",
            required_permission="users.view",
            current_user=user,
        ), 403

    users_list = list_users(include_archived=False)
    # Never expose password hashes or raw storage fields to Jinja/HTML.
    for item in users_list:
        item["has_passport"] = bool(item.get("passport_file"))
        item.pop("password_hash", None)
        item.pop("permissions_json", None)
        item.pop("passport_file", None)
    role_defaults = {
        role: default_permissions_for(role)
        for role in ROLE_LABELS.keys()
    }
    return render_template(
        "access_control/access-control.html",
        current_user=user,
        users=users_list,
        active_user_count=count_active_users(),
        role_labels=ROLE_LABELS,
        permission_groups=PERMISSION_GROUPS,
        all_permissions=ALL_PERMISSIONS,
        role_defaults=role_defaults,
        csrf_token=_csrf_token(),
        system_message=system_message,
        error_message=error_message,
    )


@require_permission("users.create")
def create_user_route():
    _verify_csrf()
    actor = current_user()
    data = _form_payload()
    if not has_permission(actor, "roles.manage") and data.get("role") != "reader":
        return redirect(url_for("access_control.access_control_page", error="Нет права назначать роли."))
    _actor_can_manage_target(actor, None, data.get("role"))
    stored_passport = None
    try:
        upload = request.files.get("passport_file")
        if upload is not None and getattr(upload, "filename", ""):
            stored_passport, original_name = _save_passport_upload(upload)
            data["passport_file"] = stored_passport
            data["passport_original_name"] = original_name
        created = create_user(data, actor_id=actor["id"], ip=get_client_ip())
        return redirect(url_for(
            "access_control.access_control_page",
            msg=f"Пользователь {created['display_name']} добавлен.",
        ))
    except Exception as exc:
        _remove_passport(stored_passport)
        return redirect(url_for("access_control.access_control_page", error=str(exc)))


@require_permission("users.edit")
def update_user_route(user_id: int):
    _verify_csrf()
    actor = current_user()
    target = get_user(user_id)
    if not target:
        abort(404)
    data = _form_payload()
    if data.get("role") != target.get("role") and not has_permission(actor, "roles.manage"):
        return redirect(url_for("access_control.access_control_page", error="Нет права изменять роль пользователя."))
    _actor_can_manage_target(actor, target, data.get("role"))
    if target.get("role") == "super_admin" and data.get("role") != "super_admin" and count_active_super_admins() <= 1:
        return redirect(url_for("access_control.access_control_page", error="Нельзя снять роль у последнего активного Супер Админа."))
    new_password = (data.get("new_password") or "")
    confirm_password = (data.get("confirm_password") or "")
    if new_password or confirm_password:
        if not actor or actor.get("role") != "super_admin":
            abort(403, description="Только Супер Админ может изменять пароль пользователя.")
        if new_password != confirm_password:
            return redirect(url_for("access_control.access_control_page", error="Пароли не совпадают."))
        if len(new_password) < 8:
            return redirect(url_for("access_control.access_control_page", error="Новый пароль должен содержать минимум 8 символов."))

    new_passport = None
    old_passport = target.get("passport_file")
    try:
        upload = request.files.get("passport_file")
        if upload is not None and getattr(upload, "filename", ""):
            new_passport, original_name = _save_passport_upload(upload)
            data["passport_file"] = new_passport
            data["passport_original_name"] = original_name
        updated = update_user(user_id, data, actor_id=actor["id"], ip=get_client_ip())
        if new_passport and old_passport and old_passport != new_passport:
            _remove_passport(old_passport)
        return redirect(url_for(
            "access_control.access_control_page",
            msg=f"Пользователь {updated['display_name']} обновлён.",
        ))
    except Exception as exc:
        _remove_passport(new_passport)
        return redirect(url_for("access_control.access_control_page", error=str(exc)))


@require_permission("users.view")
def passport_user_route(user_id: int):
    target = get_user(user_id)
    if not target:
        abort(404)
    stored = target.get("passport_file")
    if not stored:
        abort(404, description="Копия паспорта не загружена.")
    safe_stored = Path(str(stored)).name
    target_path = PASSPORT_DIR / safe_stored
    if not target_path.is_file():
        abort(404, description="Файл паспорта отсутствует на диске.")
    download_name = target.get("passport_original_name") or f"passport-{user_id}{target_path.suffix}"
    return send_from_directory(PASSPORT_DIR, safe_stored, as_attachment=True, download_name=download_name)


@require_permission("users.disable")
def toggle_user_route(user_id: int):
    _verify_csrf()
    actor = current_user()
    target = get_user(user_id)
    if not target:
        abort(404)
    _actor_can_manage_target(actor, target)
    if target.get("role") == "super_admin" and target.get("is_active") and count_active_super_admins() <= 1:
        return redirect(url_for("access_control.access_control_page", error="Нельзя заблокировать последнего активного Супер Админа."))
    if int(actor["id"]) == int(user_id) and target.get("is_active"):
        return redirect(url_for("access_control.access_control_page", error="Нельзя заблокировать собственную активную сессию."))
    set_user_active(user_id, not bool(target.get("is_active")), actor_id=actor["id"], ip=get_client_ip())
    state = "активирован" if not target.get("is_active") else "заблокирован"
    return redirect(url_for("access_control.access_control_page", msg=f"Пользователь {state}."))


@require_permission("users.delete")
def archive_user_route(user_id: int):
    _verify_csrf()
    actor = current_user()
    target = get_user(user_id)
    if not target:
        abort(404)
    _actor_can_manage_target(actor, target)
    if target.get("role") == "super_admin" and target.get("is_active") and count_active_super_admins() <= 1:
        return redirect(url_for("access_control.access_control_page", error="Нельзя архивировать последнего активного Супер Админа."))
    if int(actor["id"]) == int(user_id):
        return redirect(url_for("access_control.access_control_page", error="Нельзя архивировать собственную учётную запись."))
    archive_user(user_id, actor_id=actor["id"], ip=get_client_ip())
    return redirect(url_for("access_control.access_control_page", msg="Пользователь перенесён в архив."))

"""Database-backed user store for MSB-CBMRS Access Control.

SQLite is the zero-config development fallback. Production can switch to
PostgreSQL by setting MAIN_ACCESS_DATABASE_URL without changing application code.
"""
from __future__ import annotations

import json
import os
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import (
    Boolean, Column, Date, DateTime, Integer, MetaData, String, Table, Text,
    create_engine, delete, func, insert, inspect, select, update,
)
from sqlalchemy.engine import Engine
from werkzeug.security import check_password_hash, generate_password_hash

from .permissions import (
    ALL_PERMISSIONS,
    default_permissions_for,
    normalize_role,
    role_label,
    sanitize_permissions,
)

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DEFAULT_SQLITE = DATA_DIR / "access_control.db"

metadata = MetaData()

users = Table(
    "access_users", metadata,
    Column("id", Integer, primary_key=True),
    Column("username", String(80), nullable=False, unique=True, index=True),
    Column("password_hash", String(512), nullable=False),
    Column("first_name", String(100), nullable=False),
    Column("last_name", String(100), nullable=False),
    Column("birth_date", Date, nullable=True),
    Column("email", String(254), nullable=True, unique=True, index=True),
    Column("phone", String(64), nullable=True, unique=True, index=True),
    Column("passport_file", String(500), nullable=True),
    Column("passport_original_name", String(255), nullable=True),
    Column("role", String(40), nullable=False, index=True),
    Column("permissions_json", Text, nullable=False, default="[]"),
    Column("is_active", Boolean, nullable=False, default=True, index=True),
    Column("is_archived", Boolean, nullable=False, default=False, index=True),
    Column("created_by", Integer, nullable=True),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False),
    Column("last_login_at", DateTime(timezone=True), nullable=True),
)

audit_log = Table(
    "access_audit_log", metadata,
    Column("id", Integer, primary_key=True),
    Column("actor_user_id", Integer, nullable=True, index=True),
    Column("target_user_id", Integer, nullable=True, index=True),
    Column("action", String(80), nullable=False, index=True),
    Column("ip", String(80), nullable=True),
    Column("payload_json", Text, nullable=False, default="{}"),
    Column("created_at", DateTime(timezone=True), nullable=False, index=True),
)

login_attempts = Table(
    "access_login_attempts", metadata,
    Column("attempt_key", String(320), primary_key=True),
    Column("failed_count", Integer, nullable=False, default=0),
    Column("first_failed_at", DateTime(timezone=True), nullable=True),
    Column("last_failed_at", DateTime(timezone=True), nullable=True, index=True),
    Column("locked_until", DateTime(timezone=True), nullable=True, index=True),
)

_ENGINE: Engine | None = None


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _database_url(config: dict | None = None) -> str:
    configured = ""
    if config:
        configured = str(config.get("database_url") or "").strip()
    configured = os.environ.get("MAIN_ACCESS_DATABASE_URL", configured).strip()
    if configured:
        return configured
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{DEFAULT_SQLITE.as_posix()}"


def _ensure_user_schema(engine_obj: Engine) -> None:
    """Adds columns introduced after the first Access Control release.

    SQLAlchemy create_all() intentionally does not alter existing tables, so
    lightweight additive migrations are applied here for SQLite/PostgreSQL.
    """
    try:
        existing = {col["name"] for col in inspect(engine_obj).get_columns("access_users")}
    except Exception:
        return
    additions = {
        "passport_file": "VARCHAR(500)",
        "passport_original_name": "VARCHAR(255)",
    }
    with engine_obj.begin() as conn:
        for name, sql_type in additions.items():
            if name not in existing:
                conn.exec_driver_sql(f"ALTER TABLE access_users ADD COLUMN {name} {sql_type}")


def init_user_store(config: dict) -> Engine:
    global _ENGINE
    if _ENGINE is not None:
        return _ENGINE

    url = _database_url(config)
    kwargs: dict[str, Any] = {"pool_pre_ping": True, "future": True}
    if url.startswith("sqlite"):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
    else:
        kwargs.update({"pool_size": 10, "max_overflow": 10, "pool_recycle": 1800})

    _ENGINE = create_engine(url, **kwargs)
    metadata.create_all(_ENGINE)
    _ensure_user_schema(_ENGINE)

    if url.startswith("sqlite"):
        with _ENGINE.begin() as conn:
            conn.exec_driver_sql("PRAGMA journal_mode=WAL")
            conn.exec_driver_sql("PRAGMA synchronous=NORMAL")
            conn.exec_driver_sql("PRAGMA busy_timeout=30000")

    ensure_bootstrap_super_admin(config)
    apply_one_time_super_admin_recovery(config)
    return _ENGINE


def engine() -> Engine:
    if _ENGINE is None:
        raise RuntimeError("Access user store is not initialized")
    return _ENGINE


def _row_to_dict(row) -> dict | None:
    if row is None:
        return None
    data = dict(row._mapping)
    try:
        data["permissions"] = sanitize_permissions(json.loads(data.get("permissions_json") or "[]"))
    except Exception:
        data["permissions"] = []
    data["role_label"] = role_label(data.get("role"))
    data["birth_date_iso"] = data["birth_date"].isoformat() if data.get("birth_date") else ""
    data["display_name"] = " ".join(
        part for part in [data.get("first_name"), data.get("last_name")] if part
    ) or data.get("username")
    return data


def ensure_bootstrap_super_admin(config: dict) -> None:
    with engine().begin() as conn:
        count = conn.execute(select(func.count()).select_from(users)).scalar_one()
        if count:
            return
        username = str(config.get("username") or "meryosab").strip() or "meryosab"
        password_hash = str(config.get("password_hash") or "").strip()
        if not password_hash:
            password = str(config.get("password") or "").strip()
            if not password:
                password = "Change-Me-Immediately!"
            password_hash = _hash_password(password)
        now = utcnow()
        conn.execute(insert(users).values(
            username=username,
            password_hash=password_hash,
            first_name="Super",
            last_name="Admin",
            birth_date=None,
            email=None,
            phone=None,
            passport_file=None,
            passport_original_name=None,
            role="super_admin",
            permissions_json=json.dumps(list(ALL_PERMISSIONS), ensure_ascii=False),
            is_active=True,
            is_archived=False,
            created_by=None,
            created_at=now,
            updated_at=now,
        ))


def apply_one_time_super_admin_recovery(config: dict) -> bool:
    """Recover the existing bootstrap Super Admin inside the normal DB.

    This is deliberately one-time and opt-in. It does not create another user,
    does not use a second database and is not consulted during normal logins.
    The caller consumes/erases the recovery secret from access.env after success.
    """
    if not bool(config.get("recovery_on_start")):
        return False

    bootstrap_username = str(config.get("username") or "").strip()
    recovery_username = str(config.get("recovery_username") or bootstrap_username).strip()
    recovery_password = str(config.get("recovery_password") or "")

    if not recovery_username or recovery_username.lower() != bootstrap_username.lower():
        raise RuntimeError("Recovery разрешён только для bootstrap Супер Админа MAIN_ACCESS_USERNAME.")
    if len(recovery_password) < 8:
        raise RuntimeError("MAIN_ACCESS_RECOVERY_PASSWORD должен содержать минимум 8 символов.")

    with engine().begin() as conn:
        row = conn.execute(
            select(users).where(func.lower(users.c.username) == recovery_username.lower())
        ).first()
        if not row:
            raise RuntimeError("Bootstrap Супер Админ не найден в access_users.")
        current = _row_to_dict(row)
        if current.get("role") != "super_admin":
            raise RuntimeError("Recovery остановлен: bootstrap-пользователь больше не является Супер Админом.")

        new_hash = _hash_password(recovery_password)
        if not _password_hash_is_valid(new_hash, recovery_password):
            raise RuntimeError("Не удалось создать проверяемый hash recovery-пароля.")

        conn.execute(
            update(users).where(users.c.id == int(current["id"])).values(
                password_hash=new_hash,
                is_active=True,
                is_archived=False,
                permissions_json=json.dumps(list(ALL_PERMISSIONS), ensure_ascii=False),
                updated_at=utcnow(),
            )
        )
        # Emergency recovery must remove both identifier and generic IP locks.
        conn.execute(delete(login_attempts))
        conn.execute(insert(audit_log).values(
            actor_user_id=None,
            target_user_id=int(current["id"]),
            action="security.super_admin_recovery",
            ip="startup",
            payload_json=json.dumps({"username": recovery_username}, ensure_ascii=False),
            created_at=utcnow(),
        ))

    recovered = find_user_by_identifier(recovery_username)
    if not recovered or not _password_hash_is_valid(recovered.get("password_hash", ""), recovery_password):
        raise RuntimeError("Recovery-пароль не прошёл контрольную проверку после записи в access_users.")

    config["_recovery_applied"] = True
    return True


def get_user(user_id: int) -> dict | None:
    with engine().connect() as conn:
        row = conn.execute(select(users).where(users.c.id == int(user_id))).first()
    return _row_to_dict(row)


def find_user_by_identifier(identifier: str) -> dict | None:
    identifier = (identifier or "").strip()
    if not identifier:
        return None
    low = identifier.lower()
    stmt = select(users).where(
        (func.lower(users.c.username) == low)
        | (func.lower(func.coalesce(users.c.email, "")) == low)
        | (func.lower(func.coalesce(users.c.phone, "")) == low)
    )
    with engine().connect() as conn:
        return _row_to_dict(conn.execute(stmt).first())


def authenticate(identifier: str, password: str) -> dict | None:
    user = find_user_by_identifier(identifier)
    if not user or not user.get("is_active") or user.get("is_archived"):
        return None
    try:
        valid = check_password_hash(user["password_hash"], password)
    except Exception:
        valid = False
    if not valid:
        return None
    with engine().begin() as conn:
        conn.execute(update(users).where(users.c.id == user["id"]).values(last_login_at=utcnow()))
    user["last_login_at"] = utcnow()
    return user


def list_users(include_archived: bool = False) -> list[dict]:
    stmt = select(users)
    if not include_archived:
        stmt = stmt.where(users.c.is_archived.is_(False))
    stmt = stmt.order_by(users.c.is_active.desc(), users.c.last_name, users.c.first_name, users.c.id)
    with engine().connect() as conn:
        return [_row_to_dict(row) for row in conn.execute(stmt).fetchall()]


def count_active_users() -> int:
    stmt = select(func.count()).select_from(users).where(users.c.is_active.is_(True), users.c.is_archived.is_(False))
    with engine().connect() as conn:
        return int(conn.execute(stmt).scalar_one())


def count_active_super_admins() -> int:
    stmt = select(func.count()).select_from(users).where(
        users.c.role == "super_admin",
        users.c.is_active.is_(True),
        users.c.is_archived.is_(False),
    )
    with engine().connect() as conn:
        return int(conn.execute(stmt).scalar_one())


def _normalize_optional(value: str | None) -> str | None:
    value = (value or "").strip()
    return value or None


def _parse_date(value: str | None) -> date | None:
    value = (value or "").strip()
    if not value:
        return None
    return date.fromisoformat(value)


def _hash_password(password: str) -> str:
    """Create a portable Werkzeug password hash used by MSB-CBMRS.

    PBKDF2 is selected explicitly instead of relying on Werkzeug's changing
    default method. Existing scrypt/PBKDF2 hashes remain readable because
    check_password_hash detects the method stored inside each hash.
    """
    return generate_password_hash(password, method="pbkdf2:sha256:600000")


def _password_hash_is_valid(password_hash: str, password: str) -> bool:
    try:
        return bool(check_password_hash(password_hash or "", password or ""))
    except Exception:
        return False


def _check_unique(conn, column, value, exclude_id: int | None = None) -> None:
    if not value:
        return
    stmt = select(users.c.id).where(func.lower(column) == str(value).lower())
    if exclude_id:
        stmt = stmt.where(users.c.id != int(exclude_id))
    found = conn.execute(stmt).first()
    if found:
        raise ValueError("Такое значение уже используется другим пользователем.")


def create_user(data: dict, actor_id: int | None = None, ip: str = "") -> dict:
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    first_name = (data.get("first_name") or "").strip()
    last_name = (data.get("last_name") or "").strip()
    role = normalize_role(data.get("role"))
    email = _normalize_optional(data.get("email"))
    phone = _normalize_optional(data.get("phone"))
    passport_file = _normalize_optional(data.get("passport_file"))
    passport_original_name = _normalize_optional(data.get("passport_original_name"))
    if len(username) < 3:
        raise ValueError("Логин должен содержать минимум 3 символа.")
    if len(password) < 8:
        raise ValueError("Пароль должен содержать минимум 8 символов.")
    if not first_name or not last_name:
        raise ValueError("Имя и фамилия обязательны.")
    if not (data.get("birth_date") or "").strip():
        raise ValueError("Дата рождения обязательна.")
    if not email:
        raise ValueError("Email обязателен.")
    if not phone:
        raise ValueError("Телефон обязателен.")
    permissions = sanitize_permissions(data.get("permissions"))
    if not permissions and not data.get("permissions_explicit"):
        permissions = default_permissions_for(role)
    if role == "super_admin":
        permissions = list(ALL_PERMISSIONS)
    now = utcnow()
    with engine().begin() as conn:
        _check_unique(conn, users.c.username, username)
        _check_unique(conn, users.c.email, email)
        _check_unique(conn, users.c.phone, phone)
        result = conn.execute(insert(users).values(
            username=username,
            password_hash=_hash_password(password),
            first_name=first_name,
            last_name=last_name,
            birth_date=_parse_date(data.get("birth_date")),
            email=email,
            phone=phone,
            passport_file=passport_file,
            passport_original_name=passport_original_name,
            role=role,
            permissions_json=json.dumps(permissions, ensure_ascii=False),
            is_active=bool(data.get("is_active", True)),
            is_archived=False,
            created_by=actor_id,
            created_at=now,
            updated_at=now,
        ))
        user_id = int(result.inserted_primary_key[0])
    write_audit(actor_id, user_id, "user.create", {"username": username, "role": role}, ip)
    return get_user(user_id)


def update_user(user_id: int, data: dict, actor_id: int | None = None, ip: str = "") -> dict:
    current = get_user(user_id)
    if not current:
        raise ValueError("Пользователь не найден.")

    username = (data.get("username") or current["username"]).strip()
    first_name = (data.get("first_name") or "").strip()
    last_name = (data.get("last_name") or "").strip()
    role = normalize_role(data.get("role"))
    email = _normalize_optional(data.get("email"))
    phone = _normalize_optional(data.get("phone"))
    passport_file = _normalize_optional(data.get("passport_file")) or current.get("passport_file")
    passport_original_name = _normalize_optional(data.get("passport_original_name")) or current.get("passport_original_name")
    new_password = data.get("new_password") or ""

    if not first_name or not last_name:
        raise ValueError("Имя и фамилия обязательны.")
    if not (data.get("birth_date") or "").strip():
        raise ValueError("Дата рождения обязательна.")
    if not email:
        raise ValueError("Email обязателен.")
    if not phone:
        raise ValueError("Телефон обязателен.")
    if new_password and len(new_password) < 8:
        raise ValueError("Новый пароль должен содержать минимум 8 символов.")

    permissions = sanitize_permissions(data.get("permissions"))
    if role == "super_admin":
        permissions = list(ALL_PERMISSIONS)

    new_password_hash = _hash_password(new_password) if new_password else None
    if new_password_hash and not _password_hash_is_valid(new_password_hash, new_password):
        raise RuntimeError("Не удалось проверить новый hash пароля до сохранения.")

    with engine().begin() as conn:
        _check_unique(conn, users.c.username, username, user_id)
        _check_unique(conn, users.c.email, email, user_id)
        _check_unique(conn, users.c.phone, phone, user_id)
        values = dict(
            username=username,
            first_name=first_name,
            last_name=last_name,
            birth_date=_parse_date(data.get("birth_date")),
            email=email,
            phone=phone,
            passport_file=passport_file,
            passport_original_name=passport_original_name,
            role=role,
            permissions_json=json.dumps(permissions, ensure_ascii=False),
            is_active=bool(data.get("is_active", current.get("is_active", True))),
            updated_at=utcnow(),
        )
        if new_password_hash:
            values["password_hash"] = new_password_hash
        result = conn.execute(
            update(users).where(users.c.id == int(user_id)).values(**values)
        )
        if int(result.rowcount or 0) != 1:
            raise ValueError("Пользователь не найден при сохранении.")

    updated = get_user(user_id)
    if new_password and (not updated or not _password_hash_is_valid(updated.get("password_hash", ""), new_password)):
        raise RuntimeError("Пароль не прошёл контрольную проверку после записи в базу.")

    if new_password:
        # Password was changed by an authorised Super Admin. Old failed-login
        # counters for this account must not keep the owner locked out.
        clear_user_login_attempts_db(current, ip_text=ip)
        clear_user_login_attempts_db(updated, ip_text=ip)

    write_audit(
        actor_id, user_id, "user.update",
        {"username": username, "role": role, "password_changed": bool(new_password)},
        ip,
    )
    return updated

def set_user_active(user_id: int, active: bool, actor_id: int | None = None, ip: str = "") -> None:
    with engine().begin() as conn:
        conn.execute(update(users).where(users.c.id == int(user_id)).values(is_active=bool(active), updated_at=utcnow()))
    write_audit(actor_id, user_id, "user.activate" if active else "user.disable", {}, ip)


def archive_user(user_id: int, actor_id: int | None = None, ip: str = "") -> None:
    with engine().begin() as conn:
        conn.execute(update(users).where(users.c.id == int(user_id)).values(is_active=False, is_archived=True, updated_at=utcnow()))
    write_audit(actor_id, user_id, "user.archive", {}, ip)


def has_permission(user: dict | None, permission: str) -> bool:
    if not user or not user.get("is_active") or user.get("is_archived"):
        return False
    if user.get("role") == "super_admin":
        return True
    return permission in set(user.get("permissions") or [])


def write_audit(actor_id: int | None, target_id: int | None, action: str, payload: dict | None, ip: str = "") -> None:
    try:
        with engine().begin() as conn:
            conn.execute(insert(audit_log).values(
                actor_user_id=actor_id,
                target_user_id=target_id,
                action=action,
                ip=ip or None,
                payload_json=json.dumps(payload or {}, ensure_ascii=False),
                created_at=utcnow(),
            ))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Database-backed anti brute-force state. Safe across multiple WSGI workers.
# ---------------------------------------------------------------------------

def _attempt_keys(username: str, ip_text: str) -> list[str]:
    normalized = (username or "").strip().lower()
    return [f"ip::{ip_text}", f"user::{ip_text}::{normalized}"]


def get_login_lock_status_db(username: str, ip_text: str) -> dict:
    now = utcnow()
    locked_until = None
    locked_key = ""
    with engine().connect() as conn:
        for key in _attempt_keys(username, ip_text):
            row = conn.execute(select(login_attempts).where(login_attempts.c.attempt_key == key)).first()
            if not row:
                continue
            value = row._mapping.get("locked_until")
            if value and value.tzinfo is None:
                value = value.replace(tzinfo=timezone.utc)
            if value and value > now and (locked_until is None or value > locked_until):
                locked_until = value
                locked_key = key
    if locked_until:
        remaining = max(0, int((locked_until - now).total_seconds()))
        return {"locked": True, "locked_until": locked_until, "remaining_seconds": remaining, "key": locked_key}
    return {"locked": False, "locked_until": None, "remaining_seconds": 0, "key": ""}


def register_failed_login_db(username: str, ip_text: str, max_failed: int, window_seconds: int, lock_seconds: int) -> dict:
    from datetime import timedelta
    now = utcnow()
    result = {"locked": False, "remaining_attempts": max_failed, "locked_until": None, "remaining_seconds": 0}
    with engine().begin() as conn:
        for key in _attempt_keys(username, ip_text):
            stmt = select(login_attempts).where(login_attempts.c.attempt_key == key)
            if conn.dialect.name != "sqlite":
                stmt = stmt.with_for_update()
            row = conn.execute(stmt).first()
            if row:
                data = row._mapping
                first = data.get("first_failed_at")
                if first and first.tzinfo is None:
                    first = first.replace(tzinfo=timezone.utc)
                count = int(data.get("failed_count") or 0)
                if not first or (now - first).total_seconds() > window_seconds:
                    first = now
                    count = 0
                count += 1
                locked = now + timedelta(seconds=lock_seconds) if count >= max_failed else None
                conn.execute(update(login_attempts).where(login_attempts.c.attempt_key == key).values(
                    failed_count=count, first_failed_at=first, last_failed_at=now, locked_until=locked,
                ))
            else:
                count = 1
                locked = now + timedelta(seconds=lock_seconds) if count >= max_failed else None
                conn.execute(insert(login_attempts).values(
                    attempt_key=key, failed_count=count, first_failed_at=now, last_failed_at=now, locked_until=locked,
                ))
            remaining = max(0, max_failed - count)
            result["remaining_attempts"] = min(result["remaining_attempts"], remaining)
            if locked and (result["locked_until"] is None or locked > result["locked_until"]):
                result["locked"] = True
                result["locked_until"] = locked
    if result["locked_until"]:
        result["remaining_seconds"] = max(0, int((result["locked_until"] - now).total_seconds()))
    return result


def clear_failed_logins_db(username: str, ip_text: str) -> None:
    with engine().begin() as conn:
        conn.execute(delete(login_attempts).where(login_attempts.c.attempt_key.in_(_attempt_keys(username, ip_text))))


def clear_user_login_attempts_db(user: dict | None, ip_text: str = "") -> None:
    """Clear anti-brute-force rows that belong to one user.

    Login can be performed by username, email or phone, therefore all aliases
    are removed.  When ``ip_text`` is supplied, the generic IP lock for the
    current management/login request is also cleared.  This is intentionally
    DB-backed so every WSGI worker observes the unlock immediately.
    """
    if not user:
        return
    identifiers = {
        str(user.get("username") or "").strip().lower(),
        str(user.get("email") or "").strip().lower(),
        str(user.get("phone") or "").strip().lower(),
    }
    identifiers.discard("")
    conditions = []
    for identifier in identifiers:
        # user::<ip>::<identifier> -- any IP, this exact login alias.
        conditions.append(login_attempts.c.attempt_key.like(f"user::%::{identifier}"))
    if ip_text:
        conditions.append(login_attempts.c.attempt_key == f"ip::{ip_text}")
    if not conditions:
        return
    predicate = conditions[0]
    for condition in conditions[1:]:
        predicate = predicate | condition
    with engine().begin() as conn:
        conn.execute(delete(login_attempts).where(predicate))


def clear_all_login_attempts_db() -> None:
    """Emergency/admin helper: clear all anti-brute-force counters."""
    with engine().begin() as conn:
        conn.execute(delete(login_attempts))


def cleanup_login_attempts_db(max_age_seconds: int = 86400) -> None:
    from datetime import timedelta
    threshold = utcnow() - timedelta(seconds=max(3600, int(max_age_seconds)))
    with engine().begin() as conn:
        conn.execute(delete(login_attempts).where(
            login_attempts.c.last_failed_at.is_not(None),
            login_attempts.c.last_failed_at < threshold,
            (login_attempts.c.locked_until.is_(None)) | (login_attempts.c.locked_until < utcnow()),
        ))

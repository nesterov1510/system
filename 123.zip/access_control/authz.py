"""Reusable server-side permission checks for MSB-CBMRS routes."""
from __future__ import annotations

from functools import wraps
from flask import abort, session

from .user_store import get_user, has_permission


def current_access_user() -> dict | None:
    user_id = session.get("access_user_id")
    if not user_id:
        return None
    try:
        return get_user(int(user_id))
    except Exception:
        return None


def can_access(permission: str) -> bool:
    return has_permission(current_access_user(), permission)


def access_permission_required(permission: str):
    """Use on any future action route, e.g. @access_permission_required('repairs.delete')."""
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not can_access(permission):
                abort(403, description=f"Missing permission: {permission}")
            return fn(*args, **kwargs)
        return wrapped
    return decorator

(() => {
  'use strict';

  const bySel = (s, root = document) => root.querySelector(s);
  const all = (s, root = document) => Array.from(root.querySelectorAll(s));

  document.addEventListener('DOMContentLoaded', () => {
    const passwordToggle = bySel('[data-password-toggle]');
    const loginPassword = bySel('#accessPassword');
    if (passwordToggle && loginPassword) {
      passwordToggle.addEventListener('click', () => {
        const show = loginPassword.type === 'password';
        loginPassword.type = show ? 'text' : 'password';
        passwordToggle.textContent = show ? 'Скрыть' : 'Показать';
      });
    }

    const search = bySel('[data-user-search]');
    const roleFilter = bySel('[data-role-filter]');
    const rows = all('[data-user-row]');
    const noResults = bySel('[data-no-results]');
    const applyFilters = () => {
      if (!rows.length) return;
      const q = (search?.value || '').trim().toLowerCase();
      const role = roleFilter?.value || '';
      let shown = 0;
      rows.forEach((row) => {
        const ok = (!q || (row.dataset.search || '').includes(q)) && (!role || row.dataset.role === role);
        row.hidden = !ok;
        if (ok) shown += 1;
      });
      if (noResults) noResults.hidden = shown !== 0;
    };
    search?.addEventListener('input', applyFilters);
    roleFilter?.addEventListener('change', applyFilters);

    const modal = bySel('[data-user-modal]');
    const form = bySel('[data-user-form]');
    if (!modal || !form) return;

    const roleSelect = bySel('[data-user-role]', form);
    const permissionBoxes = all('[data-permission]', form);
    const title = bySel('[data-modal-title]');
    const passwordInput = bySel('[data-user-password]', form);
    const passwordRequired = bySel('[data-password-required]', form);
    const editPasswordSection = bySel('[data-edit-password-section]', form);
    const editNewPassword = bySel('[data-edit-new-password]', form);
    const editConfirmPassword = bySel('[data-edit-confirm-password]', form);
    const passportInput = bySel('[data-user-passport]', form);
    const passportCurrent = bySel('[data-passport-current]', form);
    const passportLink = bySel('[data-passport-link]', form);
    const passportName = bySel('[data-passport-name]', form);
    const editActions = bySel('[data-edit-actions]', form);
    const defaultsNode = bySel('#accessRoleDefaults');
    let roleDefaults = {};
    try { roleDefaults = JSON.parse(defaultsNode?.textContent || '{}'); } catch (_) {}
    let editingUser = null;

    const setPermissions = (values) => {
      const set = new Set(values || []);
      permissionBoxes.forEach((box) => { box.checked = set.has(box.value); });
    };

    const applyRoleDefaults = () => setPermissions(roleDefaults[roleSelect?.value] || []);

    const openModal = () => {
      modal.hidden = false;
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    };
    const closeModal = () => {
      modal.hidden = true;
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    };

    const resetForCreate = () => {
      editingUser = null;
      form.reset();
      form.action = '/access_control/users/create';
      if (title) title.textContent = 'Добавить пользователя';
      if (passwordInput) { passwordInput.required = true; passwordInput.value = ''; }
      if (passwordRequired) passwordRequired.hidden = false;
      if (editPasswordSection) editPasswordSection.hidden = true;
      if (editNewPassword) editNewPassword.value = '';
      if (editConfirmPassword) editConfirmPassword.value = '';
      if (passportInput) { passportInput.required = false; passportInput.value = ''; }
      if (passportCurrent) passportCurrent.hidden = true;
      if (passportLink) passportLink.href = '#';
      if (passportName) passportName.textContent = '';
      if (editActions) editActions.hidden = true;
      if (roleSelect) roleSelect.value = 'operator';
      applyRoleDefaults();
    };

    bySel('[data-user-create]')?.addEventListener('click', () => { resetForCreate(); openModal(); });
    all('[data-user-modal-close]').forEach((el) => el.addEventListener('click', closeModal));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !modal.hidden) closeModal(); });

    bySel('[data-apply-role]', form)?.addEventListener('click', applyRoleDefaults);
    bySel('[data-permissions-all]', form)?.addEventListener('click', () => permissionBoxes.forEach((b) => { b.checked = true; }));
    bySel('[data-permissions-none]', form)?.addEventListener('click', () => permissionBoxes.forEach((b) => { b.checked = false; }));

    all('[data-user-edit]').forEach((button) => {
      button.addEventListener('click', () => {
        let user;
        try { user = JSON.parse(button.dataset.user || '{}'); } catch (_) { return; }
        editingUser = user;
        form.reset();
        form.action = `/access_control/users/${user.id}/update`;
        if (title) title.textContent = `Редактировать: ${user.display_name || user.username}`;
        const put = (name, value) => { const field = form.elements.namedItem(name); if (field) field.value = value ?? ''; };
        put('first_name', user.first_name); put('last_name', user.last_name);
        put('birth_date', user.birth_date_iso || ''); put('email', user.email || ''); put('phone', user.phone || '');
        put('username', user.username); put('role', user.role); put('is_active', user.is_active ? '1' : '0');
        if (passwordInput) { passwordInput.required = false; passwordInput.value = ''; }
        if (passwordRequired) passwordRequired.hidden = true;
        if (editPasswordSection) editPasswordSection.hidden = false;
        if (editNewPassword) editNewPassword.value = '';
        if (editConfirmPassword) editConfirmPassword.value = '';
        if (passportInput) { passportInput.required = false; passportInput.value = ''; }
        if (passportCurrent) passportCurrent.hidden = !user.has_passport;
        if (passportLink) passportLink.href = user.has_passport ? `/access_control/users/${user.id}/passport` : '#';
        if (passportName) passportName.textContent = user.passport_original_name || '';
        setPermissions(user.permissions || []);
        if (editActions) editActions.hidden = false;
        openModal();
      });
    });

    bySel('[data-toggle-submit]')?.addEventListener('click', () => {
      if (!editingUser) return;
      const aux = bySel('[data-toggle-form]');
      if (!aux) return;
      aux.action = `/access_control/users/${editingUser.id}/toggle`;
      if (confirm(editingUser.is_active ? 'Заблокировать пользователя?' : 'Активировать пользователя?')) aux.submit();
    });
    bySel('[data-archive-submit]')?.addEventListener('click', () => {
      if (!editingUser) return;
      const aux = bySel('[data-archive-form]');
      if (!aux) return;
      aux.action = `/access_control/users/${editingUser.id}/archive`;
      if (confirm('Перенести пользователя в архив? Вход будет заблокирован.')) aux.submit();
    });
  });
})();

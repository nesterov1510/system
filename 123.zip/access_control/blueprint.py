# access_control/blueprint.py
"""Blueprint for MSB-CBMRS Access Control and user administration."""
from __future__ import annotations

from datetime import timedelta

from flask import Blueprint, Flask, redirect, url_for

from access_control.access_settings import (
    access_control_page,
    access_login_route,
    access_logout_route,
    protect_admin_routes,
    reload_access_config,
    consume_one_time_recovery,
)
from access_control.user_store import init_user_store
from access_control.management import (
    create_user_route,
    update_user_route,
    toggle_user_route,
    archive_user_route,
    passport_user_route,
)

try:
    from on_off_debug import debug_success_print
except Exception:  # pragma: no cover
    def debug_success_print(message, source=None) -> None:
        return None

LOG_SOURCE = "access_control.blueprint"


def create_access_control_blueprint() -> Blueprint:
    access_bp = Blueprint(
        "access_control",
        __name__,
        template_folder="templates",
        static_folder="static",
        static_url_path="/access_control_static",
    )

    # Canonical MSB-CBMRS administration URL.
    access_bp.add_url_rule(
        "/access_control/",
        endpoint="access_control_page",
        view_func=access_control_page,
        methods=["GET"],
    )

    # Compatibility with previous releases.
    access_bp.add_url_rule(
        "/access-control/",
        endpoint="access_control_page_hyphen",
        view_func=lambda: redirect(url_for("access_control.access_control_page")),
        methods=["GET"],
    )
    access_bp.add_url_rule(
        "/access-control",
        endpoint="access_control_page_legacy",
        view_func=lambda: redirect(url_for("access_control.access_control_page")),
        methods=["GET"],
    )

    access_bp.add_url_rule(
        "/access_control/login",
        endpoint="access_login_route",
        view_func=access_login_route,
        methods=["POST"],
    )
    access_bp.add_url_rule(
        "/access_control/logout",
        endpoint="access_logout_route",
        view_func=access_logout_route,
        methods=["POST"],
    )

    access_bp.add_url_rule("/access_control/users/create", endpoint="create_user", view_func=create_user_route, methods=["POST"])
    access_bp.add_url_rule("/access_control/users/<int:user_id>/update", endpoint="update_user", view_func=update_user_route, methods=["POST"])
    access_bp.add_url_rule("/access_control/users/<int:user_id>/toggle", endpoint="toggle_user", view_func=toggle_user_route, methods=["POST"])
    access_bp.add_url_rule("/access_control/users/<int:user_id>/archive", endpoint="archive_user", view_func=archive_user_route, methods=["POST"])
    access_bp.add_url_rule("/access_control/users/<int:user_id>/passport", endpoint="passport_user", view_func=passport_user_route, methods=["GET"])

    return access_bp


def init_access_control(app: Flask) -> None:
    config = reload_access_config(log=True)
    init_user_store(config)
    if config.get("_recovery_applied"):
        consume_one_time_recovery(config)
        # Reload after consuming the secret so runtime config no longer carries it.
        config = reload_access_config(log=False)

    app.permanent_session_lifetime = timedelta(
        hours=max(1, int(config["session_hours"]))
    )
    app.before_request(protect_admin_routes)
    app.register_blueprint(create_access_control_blueprint())

    debug_success_print(
        "Access Control blueprint подключён к Flask-приложению.",
        source=LOG_SOURCE,
    )

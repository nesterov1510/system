# on_off_debug/flask_debug_app.py
"""
Compatibility helper.

Лучший способ для новых проектов — подключать debug-интерфейс через Blueprint:

    from on_off_debug import register_debug_blueprint
    register_debug_blueprint(app)

Этот файл оставлен как минимальная фабрика только для быстрого standalone-теста модуля.
"""
from flask import Flask

from on_off_debug.blueprint import register_debug_blueprint


def create_debug_test_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "change-me-in-production"
    register_debug_blueprint(app, url_prefix="/debug", enable_test_routes=True)
    return app

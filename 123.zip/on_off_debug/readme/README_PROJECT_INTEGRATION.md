# Project Integration Guide

Короткая инструкция, как подключить `on_off_debug` к любому Python/Flask-проекту.

## 1. Куда положить модуль

Папку `on_off_debug` нужно скопировать прямо внутрь проекта.

Пример структуры Flask-проекта:

my_flask_project/
├── app.py
├── *********/
├── *********/
├── *********/
└── on_off_debug/
    ├── __init__.py
    ├── debug_mode.py
    ├── debug_module.env
    ├── env_tools.py
    ├── auto_clean_log.py
    ├── critical_notify.py
    └── internal_logger.py

===================================================

from on_off_debug.debug_mode import (
    debug_info_print,
    debug_success_print,
    debug_success1_print,
    debug_warning_print,
    debug_error_print,
    debug_error1_print,
    critical_error_print,
    get_flask_debug_mode,
)

И Flask debug теперь управляется через через мой модуль 

if __name__ == "__main__":
    flask_debug = get_flask_debug_mode()

    debug_info_print(
        f"Flask запускается *********, ********, debug={flask_debug}",
        source="app.start"
    )

    app.run(
        host="****",
        ****=****,
        debug=flask_debug,
    )

===============================================




# Уровни логирования `on_off_debug`: когда какой уровень использовать

В проекте больше не используем обычный:

```python
print("что-то")
```

Вместо этого используем уровни:

```python
debug_info_print()
debug_success_print()
debug_success1_print()
debug_warning_print()
debug_error_print()
debug_error1_print()
critical_error_print()
```

Главная логика:

```text
INFO       — просто событие
SUCCESS    — действие успешно выполнено
SUCCESS1   — дополнительный успешный внутренний этап
WARNING    — есть предупреждение, но сервис работает
ERROR      — операция сломалась, но приложение живое
ERROR1     — внутренняя ошибка второго уровня
CRITICAL   — опасная/критическая ситуация + уведомление
```

---

# 1. Общая диаграмма выбора уровня

```mermaid
flowchart TD
    A[Произошло событие в проекте] --> B{Это просто информация?}
    B -- Да --> INFO[debug_info_print]

    B -- Нет --> C{Действие успешно завершилось?}
    C -- Да --> D{Это основной успех или внутренний этап?}
    D -- Основной успех --> SUCCESS[debug_success_print]
    D -- Внутренний этап --> SUCCESS1[debug_success1_print]

    C -- Нет --> E{Есть проблема, но сервис продолжает работать?}
    E -- Да --> F{Это предупреждение или ошибка операции?}
    F -- Предупреждение --> WARNING[debug_warning_print]
    F -- Ошибка операции --> ERROR[debug_error_print]

    E -- Нет --> G{Это внутренняя глубокая ошибка?}
    G -- Да --> ERROR1[debug_error1_print]

    G -- Нет --> H{Это безопасность, взлом, подбор пароля, потеря данных, падение важного сервиса?}
    H -- Да --> CRITICAL[critical_error_print + уведомление]
    H -- Нет --> ERROR2[debug_error_print]
```

---

# 2. Простая текстовая диаграмма

```text
Событие произошло
│
├── Просто информация?
│   └── debug_info_print()
│
├── Всё прошло успешно?
│   ├── Основной успех
│   │   └── debug_success_print()
│   └── Подробный внутренний успех
│       └── debug_success1_print()
│
├── Есть подозрение, но сервис работает?
│   └── debug_warning_print()
│
├── Операция сломалась, но приложение живое?
│   └── debug_error_print()
│
├── Ошибка внутри обработчика / парсера / вложенного процесса?
│   └── debug_error1_print()
│
└── Опасная ситуация?
    ├── подбор пароля
    ├── попытка взлома
    ├── запрещённый IP
    ├── потеря данных
    ├── ошибка платежа
    ├── важный сервис недоступен
    └── critical_error_print()
```

---

# 3. `debug_info_print()`

## Когда использовать

`debug_info_print()` используется для обычной информации.
Это не ошибка и не успех, а просто запись события.

## Подходит для случаев

```text
приложение запустилось
пользователь открыл страницу
началась синхронизация
началась обработка файла
загружается конфигурация
worker начал работу
получен обычный запрос
запущен health check
```

## Примеры

```python
debug_info_print(
    "Приложение запущено",
    source="app.start"
)
```

```python
debug_info_print(
    "Началась обработка заявки",
    source="orders.process"
)
```

```python
debug_info_print(
    "Пользователь открыл dashboard",
    source="route.dashboard"
)
```

## Когда НЕ использовать

Не использовать для ошибок, предупреждений и critical-ситуаций.

---

# 4. `debug_success_print()`

## Когда использовать

`debug_success_print()` используется, когда важное действие успешно завершилось.

## Подходит для случаев

```text
данные успешно сохранены
файл успешно создан
заявка отправлена
API вернул правильный ответ
подключение успешно выполнено
задача worker завершилась
пользователь успешно авторизовался
webhook успешно обработан
```

## Примеры

```python
debug_success_print(
    "Заявка успешно сохранена",
    source="orders.save"
)
```

```python
debug_success_print(
    "Внешний API успешно ответил",
    source="external_api"
)
```

```python
debug_success_print(
    "Пользователь успешно вошёл",
    source="access_control.login"
)
```

## Когда НЕ использовать

Не использовать просто для старта процесса.
Для старта лучше:

```python
debug_info_print()
```

---

# 5. `debug_success1_print()`

## Когда использовать

`debug_success1_print()` — это дополнительный успешный уровень.
Он нужен для внутренних этапов большой операции.

## Подходит для случаев

```text
внутренний шаг завершён
подэтап прошёл успешно
кэш обновлён
временный файл создан
проверка прошла успешно
внутренняя часть синхронизации завершена
```

## Примеры

```python
debug_success1_print(
    "Внутренний этап проверки завершён",
    source="worker.step_1"
)
```

```python
debug_success1_print(
    "Кэш успешно обновлён",
    source="cache.update"
)
```

```python
debug_success1_print(
    "JSON-файл успешно прочитан",
    source="json.loader"
)
```

## Когда НЕ использовать

Не использовать для главного результата операции.
Главный результат лучше писать через:

```python
debug_success_print()
```

---

# 6. `debug_warning_print()`

## Когда использовать

`debug_warning_print()` используется, когда есть проблема или подозрение, но приложение продолжает нормально работать.

Это ещё не ошибка.
Но это место надо видеть.

## Подходит для случаев

```text
параметр в env пустой, используется default
API ответил медленно
файл пустой, но это не ломает работу
пользователь один раз ввёл неправильный пароль
данные неполные, но можно продолжить
необязательный модуль не найден
заявка пришла без необязательного поля
```

## Примеры

```python
debug_warning_print(
    "DEBUG_APP_IP не указан, используется auto",
    source="config"
)
```

```python
debug_warning_print(
    "API ответил медленно",
    source="external_api"
)
```

```python
debug_warning_print(
    "Неверный пароль. Попытка 1",
    source="access_control.login"
)
```

## Когда НЕ использовать

Не использовать для настоящих ошибок, где операция уже сломалась.
Там нужен:

```python
debug_error_print()
```

Если есть атака, подбор пароля или запрещённый доступ — нужен:

```python
critical_error_print()
```

---

# 7. `debug_error_print()`

## Когда использовать

`debug_error_print()` используется, когда операция сломалась, но всё приложение ещё работает.

## Подходит для случаев

```text
один файл не прочитался
один API-запрос не прошёл
одна заявка не отправилась
одна задача worker упала
один пользовательский запрос дал ошибку
ошибка обработки одного сообщения
ошибка записи одного файла
```

## Примеры

```python
debug_error_print(
    "Ошибка чтения файла",
    source="file_reader"
)
```

```python
debug_error_print(
    "Ошибка отправки заявки",
    source="lead_sender"
)
```

```python
debug_error_print(
    "Ошибка обработки одного сообщения",
    source="telegram.worker"
)
```

## Когда НЕ использовать

Если проблема угрожает всему сервису, безопасности или данным — это уже:

```python
critical_error_print()
```

---

# 8. `debug_error1_print()`

## Когда использовать

`debug_error1_print()` — это ошибка второго уровня.
Её удобно использовать для внутренних ошибок внутри обработчиков.

## Подходит для случаев

```text
ошибка парсинга JSON
ошибка обработки вложения
ошибка временного файла
ошибка внутри обработчика
ошибка конвертации данных
ошибка внутреннего подэтапа
```

## Примеры

```python
debug_error1_print(
    "Ошибка парсинга JSON",
    source="json.parser"
)
```

```python
debug_error1_print(
    "Ошибка обработки вложения",
    source="attachments.process"
)
```

```python
debug_error1_print(
    "Ошибка временного файла",
    source="temp.file"
)
```

## Когда НЕ использовать

Не использовать для главной ошибки операции.
Главная ошибка:

```python
debug_error_print()
```

Внутренняя подробная ошибка:

```python
debug_error1_print()
```

---

# 9. `critical_error_print()`

## Когда использовать

`critical_error_print()` используется только в реально важных местах.

Это уровень:

```text
опасно
срочно
нужно увидеть сразу
может быть взлом
может быть потеря данных
может быть падение важного сервиса
```

Только `critical_error_print()` может отправлять уведомления:

```text
Email
Telegram
Webhook
```

если это включено в `debug_module.env`.

## Подходит для случаев

```text
подбор пароля
попытка взлома
запрещённый IP лезет в admin
подозрительный API token
ошибка платежного webhook
важный сервис недоступен
важный файл данных пропал
нет доступа к хранилищу
приложение не может стартовать
повторяется много ошибок подряд
подозрение на атаку
```

## Примеры

### Подбор пароля

```python
if failed_count >= 5:
    critical_error_print(
        f"Возможный подбор пароля. user={username}, ip={client_ip}, attempts={failed_count}",
        source="access_control.login"
    )
```

### Запрещённый IP

```python
if not is_ip_allowed(client_ip):
    critical_error_print(
        f"Запрещённый IP пытается открыть закрытый раздел. ip={client_ip}, path={path}",
        source="access_control.ip_filter"
    )
```

### Подозрительный API token

```python
critical_error_print(
    f"Недействительный API token для приватного route. ip={client_ip}",
    source="api.auth"
)
```

### Важный сервис недоступен

```python
critical_error_print(
    "Критическая ошибка: основной сервис недоступен",
    source="service.health"
)
```

### Ошибка отправки заявки

```python
critical_error_print(
    "Критическая ошибка: невозможно отправить заявку",
    source="lead_sender"
)
```

### Ошибка платежа

```python
critical_error_print(
    f"Неверная подпись payment webhook. ip={client_ip}",
    source="payment.webhook"
)
```

### Потеря данных

```python
critical_error_print(
    "Критический файл данных отсутствует",
    source="storage.check"
)
```

## Когда НЕ использовать

Не использовать для мелких ошибок.

Не critical:

```text
пользователь один раз ошибся в форме
один раз неверно ввёл пароль
один API-запрос не прошёл
один файл не найден, но есть fallback
один раз медленный ответ
```

Для этого есть:

```python
debug_warning_print()
debug_error_print()
```

---

# 10. Таблица выбора уровня

| Ситуация                         | Уровень                  |
| -------------------------------- | ------------------------ |
| Приложение запустилось           | `debug_info_print()`     |
| Началась синхронизация           | `debug_info_print()`     |
| Пользователь открыл страницу     | `debug_info_print()`     |
| Данные успешно сохранены         | `debug_success_print()`  |
| Заявка успешно отправлена        | `debug_success_print()`  |
| Внутренний этап успешно завершён | `debug_success1_print()` |
| API ответил медленно             | `debug_warning_print()`  |
| Используется default-настройка   | `debug_warning_print()`  |
| Один раз неверный пароль         | `debug_warning_print()`  |
| Один файл не прочитался          | `debug_error_print()`    |
| Один API-запрос упал             | `debug_error_print()`    |
| Ошибка парсинга JSON             | `debug_error1_print()`   |
| Ошибка вложенного обработчика    | `debug_error1_print()`   |
| 5+ неверных паролей              | `critical_error_print()` |
| Запрещённый IP открыл admin      | `critical_error_print()` |
| Подозрительный token             | `critical_error_print()` |
| Ошибка платежного webhook        | `critical_error_print()` |
| Важный сервис недоступен         | `critical_error_print()` |
| Потеря важных данных             | `critical_error_print()` |

---

# 11. Диаграмма уровней по серьёзности

```text
Низкий уровень важности
│
├── INFO
│   Обычная информация
│
├── SUCCESS
│   Успешное действие
│
├── SUCCESS1
│   Подробный успешный этап
│
├── WARNING
│   Предупреждение, но сервис живой
│
├── ERROR
│   Операция сломалась, но приложение работает
│
├── ERROR1
│   Внутренняя ошибка второго уровня
│
└── CRITICAL
    Опасная ситуация + уведомление

Высокий уровень важности
```

---

# 12. Диаграмма “что делать при событии”

```text
Событие
│
├── Просто сообщить?
│   └── INFO
│
├── Успешно?
│   ├── Главный успех
│   │   └── SUCCESS
│   └── Внутренний успех
│       └── SUCCESS1
│
├── Подозрительно, но работает?
│   └── WARNING
│
├── Сломалась одна операция?
│   └── ERROR
│
├── Ошибка внутри подэтапа?
│   └── ERROR1
│
└── Опасно?
    ├── безопасность
    ├── подбор пароля
    ├── запрещённый IP
    ├── платеж
    ├── потеря данных
    ├── сервис недоступен
    └── CRITICAL
```

---

# 13. Пример полного блока try/except

```python
from on_off_debug.debug_mode import (
    debug_info_print,
    debug_success_print,
    debug_warning_print,
    debug_error_print,
    debug_error1_print,
    critical_error_print,
)


def process_task(task_id: int):
    debug_info_print(
        f"Началась обработка задачи #{task_id}",
        source="task.process"
    )

    try:
        task = load_task(task_id)

        if not task:
            debug_warning_print(
                f"Задача #{task_id} не найдена",
                source="task.process"
            )
            return False

        try:
            data = parse_task_data(task)

        except Exception as e:
            debug_error1_print(
                f"Ошибка парсинга данных задачи #{task_id}: {e}",
                source="task.parser"
            )
            return False

        save_result(data)

        debug_success_print(
            f"Задача #{task_id} успешно обработана",
            source="task.process"
        )

        return True

    except ConnectionError as e:
        critical_error_print(
            f"Критическая ошибка подключения при задаче #{task_id}: {e}",
            source="task.connection"
        )
        return False

    except Exception as e:
        debug_error_print(
            f"Ошибка обработки задачи #{task_id}: {e}",
            source="task.process"
        )
        return False
```

---

# 14. Главное правило

```text
INFO       — я просто сообщаю
SUCCESS    — получилось
SUCCESS1   — внутренний этап получился
WARNING    — странно, но живём
ERROR      — операция упала, но сервис живой
ERROR1     — внутренняя ошибка
CRITICAL   — опасно, надо срочно видеть
```

`critical_error_print()` не ставим везде подряд.
Иначе уведомления превратятся в шум, а шум в мониторинге — это как сигнализация, которая орёт от каждого комара.





────────────────────────────────────────────────────────────

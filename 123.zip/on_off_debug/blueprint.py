# on_off_debug/blueprint.py
"""
Blueprint-подключение универсального модуля on_off_debug.

on_off_debug должен быть полностью переносимым:
- скопировал папку on_off_debug в любой Flask-проект;
- импортировал register_debug_blueprint;
- получил страницу просмотра логов.

Тестовых маршрутов здесь нет. Это нормальный production-вариант.

Важно:
фильтр стандартного Werkzeug access-log для /debug/api/logs/live
подключается внутри этого модуля автоматически.
app.py не должен импортировать внутренние служебные функции on_off_debug.
"""
from __future__ import annotations

from flask import Blueprint, Flask

from on_off_debug.debug_mode import debug_success_print
from on_off_debug.routes import register_on_off_debug_routes
from on_off_debug.werkzeug_live_log_filter import enable_werkzeug_live_log_filter


def create_debug_blueprint() -> Blueprint:
    """Создаёт Blueprint для просмотра логов on_off_debug."""
    debug_bp = Blueprint(
        "on_off_debug",
        __name__,
        template_folder="templates",
        static_folder="static",
        static_url_path="/on_off_debug_static",
    )

    register_on_off_debug_routes(debug_bp)
    return debug_bp


def register_debug_blueprint(
    app: Flask,
    url_prefix: str = "/debug",
) -> None:
    """
    Подключает on_off_debug к существующему Flask-приложению.

    Пример:
        from on_off_debug import register_debug_blueprint
        register_debug_blueprint(app, url_prefix="/debug")

    После подключения:
        /debug/logs

    Дополнительно:
        автоматически включается фильтр консольного шума Werkzeug
        для live API /debug/api/logs/live.
    """
    enable_werkzeug_live_log_filter()

    app.register_blueprint(
        create_debug_blueprint(),
        url_prefix=url_prefix,
    )

    debug_success_print(
        f"on_off_debug blueprint подключён. url_prefix={url_prefix}",
        source="on_off_debug.blueprint.register_debug_blueprint",
    )

# on_off_debug/werkzeug_live_log_filter.py
"""
Фильтр стандартного Werkzeug access-log для live API логов.

Зачем нужен:
страница /debug/logs в live-режиме постоянно делает запросы:

    /debug/api/logs/live

Werkzeug по умолчанию печатает каждый такой GET в консоль.
Это не ошибка и не наш debug-лог, а обычный access-log dev-сервера Flask.

Этот фильтр скрывает только такие live-запросы из консоли,
чтобы мониторинг логов не засорял терминал.

Важно:
- сами debug/error/critical логи НЕ отключаются;
- события безопасности НЕ скрываются;
- API продолжает работать;
- скрывается только строка Werkzeug вида:
  "GET /debug/api/logs/live?... HTTP/1.1" 200 -
"""
from __future__ import annotations

import logging


class HideDebugLiveApiFilter(logging.Filter):
    """Скрывает из консоли только access-log запросы /debug/api/logs/live."""

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        return "/debug/api/logs/live" not in message


def enable_werkzeug_live_log_filter() -> None:
    """
    Подключает фильтр к логгеру werkzeug.

    Использовать в app.py один раз после создания app.
    """
    logger = logging.getLogger("werkzeug")

    for existing_filter in logger.filters:
        if isinstance(existing_filter, HideDebugLiveApiFilter):
            return

    logger.addFilter(HideDebugLiveApiFilter())

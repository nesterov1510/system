# on_off_debug/routes.py
"""
Routes для HTML-интерфейса логов.

Файл лежит внутри on_off_debug, чтобы служебный debug-модуль был
самодостаточным и переносимым между Flask-проектами.
"""
from __future__ import annotations

from flask import Blueprint, jsonify, redirect, render_template, request, url_for

from on_off_debug.debug_mode import debug_info_print
from on_off_debug.log_reader_dlya_html_stranissy import get_log_view_data


def _get_limit_from_request(default: int = 300) -> int:
    raw_limit = request.args.get("limit", str(default))
    try:
        return int(raw_limit)
    except Exception:
        return default


def register_on_off_debug_routes(debug_bp: Blueprint) -> None:
    """Регистрирует маршруты просмотра логов внутри переданного Blueprint."""

    @debug_bp.route("/")
    def index():
        return redirect(url_for("on_off_debug.logs"))

    @debug_bp.route("/logs")
    def logs():
        level = request.args.get("level", "")
        date = request.args.get("date", "")
        filename = request.args.get("file", "")
        limit_int = _get_limit_from_request()

        data = get_log_view_data(
            selected_level=level,
            selected_date=date,
            selected_file=filename,
            limit=limit_int,
            auto_latest=True,
        )

        debug_info_print(
            (
                "Открыта страница мониторинга логов. "
                f"level={level or 'auto'}, date={date or 'auto'}, file={filename or 'auto'}"
            ),
            source="on_off_debug.routes.logs",
        )

        return render_template("on_off_debug/log.html", **data)

    @debug_bp.route("/api/logs/live")
    def logs_live_api():
        """
        JSON API для автообновления страницы логов.

        Важно: этот route специально НЕ пишет debug_info_print на каждый poll,
        иначе сама страница логов будет создавать бесконечный шум в логах.
        """
        data = get_log_view_data(
            selected_level=request.args.get("level", ""),
            selected_date=request.args.get("date", ""),
            selected_file=request.args.get("file", ""),
            limit=_get_limit_from_request(),
            auto_latest=True,
        )
        return jsonify(data)

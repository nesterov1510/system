// on_off_debug/static/js/log/log.js
(function () {
    "use strict";

    const cfg = window.MSB_LOG_VIEWER_CONFIG || {};
    const apiUrl = cfg.apiUrl || "";

    const els = {
        refreshNowBtn: document.getElementById("refreshNowBtn"),
        autoRefreshToggle: document.getElementById("autoRefreshToggle"),
        autoScrollToggle: document.getElementById("autoScrollToggle"),
        refreshIntervalSelect: document.getElementById("refreshIntervalSelect"),
        liveDot: document.getElementById("liveDot"),
        liveStatusText: document.getElementById("liveStatusText"),
        lastUpdateText: document.getElementById("lastUpdateText"),
        logFilter: document.getElementById("logFilter"),
        levelSelect: document.getElementById("levelSelect"),
        dateSelect: document.getElementById("dateSelect"),
        fileSelect: document.getElementById("fileSelect"),
        limitInput: document.getElementById("limitInput"),
        levelList: document.getElementById("levelList"),
        levelsCountText: document.getElementById("levelsCountText"),
        currentLevelText: document.getElementById("currentLevelText"),
        visibleLinesText: document.getElementById("visibleLinesText"),
        fileSizeText: document.getElementById("fileSizeText"),
        currentPathText: document.getElementById("currentPathText"),
        fileMtimeText: document.getElementById("fileMtimeText"),
        totalLinesText: document.getElementById("totalLinesText"),
        logWindow: document.getElementById("logWindow"),
        criticalLinesText: document.getElementById("criticalLinesText"),
        errorLinesText: document.getElementById("errorLinesText"),
        error1LinesText: document.getElementById("error1LinesText"),
        warningLinesText: document.getElementById("warningLinesText"),
    };

    let timerId = null;
    let isLoading = false;

    function getInterval() {
        const raw = parseInt(els.refreshIntervalSelect?.value || "2000", 10);
        return Number.isFinite(raw) && raw >= 500 ? raw : 2000;
    }

    function buildParams() {
        const params = new URLSearchParams();
        params.set("level", els.levelSelect?.value || "");
        params.set("date", els.dateSelect?.value || "");
        params.set("file", els.fileSelect?.value || "");
        params.set("limit", els.limitInput?.value || cfg.initialLimit || "300");
        return params;
    }

    function setStatus(mode, text) {
        if (!els.liveDot || !els.liveStatusText) return;
        els.liveDot.classList.remove("paused", "error");
        if (mode === "paused") els.liveDot.classList.add("paused");
        if (mode === "error") els.liveDot.classList.add("error");
        els.liveStatusText.textContent = text;
    }

    function replaceOptions(select, values, selectedValue, labelMap, titleMap) {
        if (!select) return;

        const safeValues = Array.isArray(values) ? values : [];
        const currentValue = selectedValue || select.value || "";
        const oldOptions = Array.from(select.options).map((opt) => opt.value).join("|");
        const newOptions = safeValues.join("|");

        if (oldOptions === newOptions) {
            select.value = currentValue;
            return;
        }

        select.innerHTML = "";

        safeValues.forEach((value) => {
            const option = document.createElement("option");
            option.value = value;

            const label = labelMap && labelMap[value] ? labelMap[value] : value;
            const title = titleMap && titleMap[value] ? titleMap[value] : "";
            option.textContent = title ? `${label} — ${title}` : label;

            if (value === currentValue) option.selected = true;
            select.appendChild(option);
        });

        if (currentValue) select.value = currentValue;
    }

    function lineClass(line, selectedLevel) {
        const text = `${selectedLevel || ""} ${line || ""}`.toLowerCase();
        if (text.includes("critical")) return "line-critical";
        if (text.includes("error") || text.includes("ошибка")) return "line-error";
        if (text.includes("warning") || text.includes("предупреж")) return "line-warning";
        if (text.includes("success") || text.includes("успеш")) return "line-success";
        return "line-info";
    }

    function renderLines(lines, selectedLevel) {
        if (!els.logWindow) return;

        const atBottom = els.logWindow.scrollTop + els.logWindow.clientHeight >= els.logWindow.scrollHeight - 40;
        const shouldScroll = els.autoScrollToggle?.checked || atBottom;

        els.logWindow.innerHTML = "";

        if (!lines || !lines.length) {
            const empty = document.createElement("div");
            empty.className = "empty-log";
            empty.textContent = "Для выбранного уровня логов пока нет записей.";
            els.logWindow.appendChild(empty);
        } else {
            const fragment = document.createDocumentFragment();
            lines.forEach((line) => {
                const pre = document.createElement("pre");
                pre.className = `log-line ${lineClass(line, selectedLevel)}`;
                pre.textContent = line;
                fragment.appendChild(pre);
            });
            els.logWindow.appendChild(fragment);
        }

        if (shouldScroll) {
            els.logWindow.scrollTop = els.logWindow.scrollHeight;
        }
    }

    function severityClass(item) {
        return `severity-${item.severity || "info"}`;
    }

    function renderStats(stats, selectedLevel) {
        if (!els.levelList) return;

        els.levelList.innerHTML = "";

        const safeStats = Array.isArray(stats) ? stats : [];
        if (!safeStats.length) {
            const muted = document.createElement("p");
            muted.className = "muted";
            muted.textContent = "Уровни логов не найдены.";
            els.levelList.appendChild(muted);
            return;
        }

        const fragment = document.createDocumentFragment();
        safeStats.forEach((item) => {
            const btn = document.createElement("button");
            btn.type = "button";
            btn.className = `level-item ${severityClass(item)} ${item.name === selectedLevel ? "active" : ""}`;
            btn.dataset.level = item.name;

            const span = document.createElement("span");
            span.textContent = item.label || item.name;

            const title = document.createElement("b");
            title.textContent = item.title || item.name;

            const small = document.createElement("small");
            small.textContent = `${item.total_files || 0} файлов / ${item.total_lines || 0} строк / ${item.total_size_human || "0 B"}`;

            btn.appendChild(span);
            btn.appendChild(title);
            btn.appendChild(small);

            btn.addEventListener("click", () => {
                selectLevel(item.name);
            });

            fragment.appendChild(btn);
        });

        els.levelList.appendChild(fragment);
    }

    function updateErrorPanel(summary) {
        const safe = summary || {};
        if (els.criticalLinesText) els.criticalLinesText.textContent = String(safe.critical_lines || 0);
        if (els.errorLinesText) els.errorLinesText.textContent = String(safe.error_lines || 0);
        if (els.error1LinesText) els.error1LinesText.textContent = String(safe.error1_lines || 0);
        if (els.warningLinesText) els.warningLinesText.textContent = String(safe.warning_lines || 0);
    }

    function applyData(data) {
        if (!data || !data.ok) return;

        replaceOptions(els.levelSelect, data.levels, data.selected_level, data.level_labels, data.level_titles);
        replaceOptions(els.dateSelect, data.dates, data.selected_date);
        replaceOptions(els.fileSelect, data.files, data.selected_file);

        if (els.levelSelect && data.selected_level) els.levelSelect.value = data.selected_level;
        if (els.dateSelect && data.selected_date) els.dateSelect.value = data.selected_date;
        if (els.fileSelect && data.selected_file) els.fileSelect.value = data.selected_file;

        renderStats(data.stats, data.selected_level);
        renderLines(data.log_lines, data.selected_level);
        updateErrorPanel(data.error_summary);

        if (els.levelsCountText) els.levelsCountText.textContent = `${(data.stats || []).length} уровней`;
        if (els.currentLevelText) els.currentLevelText.textContent = data.selected_level_label || data.selected_level || "не выбран";
        if (els.visibleLinesText) els.visibleLinesText.textContent = String(data.visible_lines || 0);
        if (els.fileSizeText) els.fileSizeText.textContent = data.file_size_human || "0 B";
        if (els.currentPathText) els.currentPathText.textContent = data.selected_log_path || "не выбран";
        if (els.fileMtimeText) els.fileMtimeText.textContent = `Изменён: ${data.file_mtime || "нет данных"}`;
        if (els.totalLinesText) els.totalLinesText.textContent = `Всего строк: ${data.total_file_lines || 0}`;
        if (els.lastUpdateText) els.lastUpdateText.textContent = `Последнее обновление: ${data.last_update || ""}`;
    }

    async function fetchLiveData() {
        if (isLoading || !apiUrl) return;
        isLoading = true;

        try {
            const response = await fetch(`${apiUrl}?${buildParams().toString()}`, {
                method: "GET",
                headers: { "Accept": "application/json" },
                cache: "no-store",
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const data = await response.json();
            applyData(data);
            setStatus(els.autoRefreshToggle?.checked ? "live" : "paused", els.autoRefreshToggle?.checked ? "LIVE включён" : "LIVE остановлен");
        } catch (error) {
            setStatus("error", "Ошибка обновления");
            if (els.lastUpdateText) els.lastUpdateText.textContent = `Ошибка: ${error.message}`;
        } finally {
            isLoading = false;
        }
    }

    function startTimer() {
        stopTimer();
        if (!els.autoRefreshToggle?.checked) {
            setStatus("paused", "LIVE остановлен");
            return;
        }
        setStatus("live", "LIVE включён");
        timerId = window.setInterval(fetchLiveData, getInterval());
    }

    function stopTimer() {
        if (timerId) {
            window.clearInterval(timerId);
            timerId = null;
        }
    }

    function selectLevel(level) {
        if (els.levelSelect) els.levelSelect.value = level || "";
        if (els.dateSelect) els.dateSelect.value = "";
        if (els.fileSelect) els.fileSelect.value = "";
        fetchLiveData();
    }

    function bindEvents() {
        els.refreshNowBtn?.addEventListener("click", fetchLiveData);
        els.autoRefreshToggle?.addEventListener("change", startTimer);
        els.refreshIntervalSelect?.addEventListener("change", startTimer);

        [els.levelSelect, els.dateSelect, els.fileSelect, els.limitInput].forEach((el) => {
            el?.addEventListener("change", fetchLiveData);
        });

        els.logFilter?.addEventListener("submit", (event) => {
            event.preventDefault();
            fetchLiveData();
        });

        document.querySelectorAll(".level-item[data-level]").forEach((btn) => {
            btn.addEventListener("click", () => selectLevel(btn.dataset.level || ""));
        });

        document.querySelectorAll("[data-error-card]").forEach((card) => {
            card.addEventListener("click", () => selectLevel(card.dataset.errorCard || ""));
        });
    }

    document.addEventListener("DOMContentLoaded", () => {
        bindEvents();
        renderLines(Array.from(document.querySelectorAll(".log-line")).map((x) => x.textContent), cfg.initialLevel || "");
        fetchLiveData();
        startTimer();
    });
})();

// on_off_debug/static/js/debug.js
console.log("on_off_debug blueprint UI loaded");

document.addEventListener("DOMContentLoaded", () => {
    document.documentElement.dataset.onOffDebug = "ready";
});

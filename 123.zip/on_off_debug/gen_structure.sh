#!/usr/bin/env bash
set -uo pipefail

OUTPUT="structure_project.txt"
PROMPT_OUTPUT="prompt_for_you_ai.txt"
DIVIDER="$(printf '─%.0s' {1..60})"

# ==========================================================
# 📦 ИСКЛЮЧЕНИЯ ДЛЯ СТРУКТУРЫ
# Эти папки не показываем в структуре и не читаем внутри них файлы.
# ==========================================================
HIDE_DIRS=(
    "*/venv/*"
    "*/__pycache__/*"
    "*/.git/*"
    "*/node_modules/*"
    "*/.idea/*"
    "*/logs/*"
    "*/tmp/*"
    "*/__MACOSX/*"
    "*/app_versions/*"
    "*/app_others/*"
    "*/log_folder/*"
    "*/app_other/*"
    "*/logs/*"
)

# ==========================================================
# 📄 ФАЙЛЫ, СОДЕРЖИМОЕ КОТОРЫХ НЕ ЧИТАЕМ
#
# ВАЖНО:
# *.env отсюда специально убран.
# Теперь .env / *.env читаются, но секреты внутри скрываются.
# ==========================================================
SKIP_CONTENT=(
    "*.session"
    "*.pyc"
    "*.pyo"
    "*.pyd"
    "*.log"
    "*.tmp"
    "*.db"
    "*.sqlite"
    "*.bak"
    "*.swp"
    "*.swo"
    "*.exe"
    "*.dll"
    "*.ico"
    "*.png"
    "*.jpg"
    "*.jpeg"
    "*.gif"
    "*.webp"
    "*.svg"
    "desktop.ini"
    "Thumbs.db"
    ".DS_Store"
    "package-lock.json"
    "app icune yazmaly.txt"
    "bashga modullaryn icinde yazmaly.txt"
    "gen_structure.sh"
    "prompt_for_you_ai.txt"
    "structure_project.txt"
    "access_attempts.json"
    "$OUTPUT"
    "$PROMPT_OUTPUT"
)

# ==========================================================
# 🔍 Проверка: является ли файл ENV-файлом
# Маскировку применяем ТОЛЬКО к таким файлам:
# .env
# access.env
# db.env
# tg.env
# tlthn.env
# auto_services.env
# ==========================================================
is_env_file() {
    local filename
    filename="$(basename "$1")"

    if [[ "$filename" == ".env" || "$filename" == *.env ]]; then
        return 0
    fi

    return 1
}

# ==========================================================
# 🛡️ МАСКИРОВКА СЕКРЕТОВ ТОЛЬКО ДЛЯ ENV-ФАЙЛОВ
#
# Исходные файлы НЕ меняет.
# Скрывает только вывод внутри structure_project.txt.
#
# ВАЖНО:
# Эта функция должна применяться только к .env / *.env.
# К Python/HTML/JS/CSS её применять нельзя.
# ==========================================================
mask_env_secrets() {
    if ! command -v perl >/dev/null 2>&1; then
        echo "[⚠️  Perl не найден. ENV-файл не показан, чтобы не раскрыть пароли.]"
        return 0
    fi

    perl -CS -pe '
        my $mask = "****SECRET_HIDDEN****";

        my $sensitive = qr/
            password|passwd|pwd|pass|
            password_hash|
            secret|secret_key|private_key|client_secret|client-secret|
            token|access_token|refresh_token|auth_token|
            bot_token|telegram_token|telegram_bot_token|
            jwt|bearer|
            api_key|apikey|api-token|api_token|
            api_hash|api_id|
            telegram_api_hash|telegram_api_id|
            telethon_api_hash|telethon_api_id|
            session_string|string_session|
            telegram_session_string|telethon_session_string|
            pyrogram_session_string|
            access_key|secret_access_key|
            aws_access_key_id|aws_secret_access_key|
            webhook|webhook_url|
            database_url|db_password|db_pass|db_user_password|
            mysql_password|postgres_password|redis_password|
            mongo_uri|mongodb_uri|
            smtp_password|mail_password|email_password|
            yoomoney_token|yoomoney_secret|
            webmoney_secret|webmoney_key|
            binance_api_key|binance_secret_key|
            bybit_api_key|bybit_secret_key|
            alipay_private_key|alipay_public_key|
            openai_api_key|deepseek_api_key|sambanova_api_key|
            github_token|gitlab_token|
            cloudflare_api_token|cloudflare_api_key
        /ix;

        # --------------------------------------------------
        # Комментарии, где явно написан пароль/токен/секрет,
        # тоже скрываем, потому что часто там пишут пример:
        # # python -c "... generate_password_hash(\"real_password\")"
        # --------------------------------------------------
        if (/^\s*#/ && /(?:password|passwd|pwd|pass|secret|token|api_hash|api_key|bot_token|generate_password_hash|парол)/i) {
            $_ = "# $mask\n";
            next;
        }

        # --------------------------------------------------
        # ENV-формат:
        # KEY=value
        # export KEY=value
        # KEY="value"
        # KEY='\''value'\''
        # --------------------------------------------------
        if (/^(\s*(?:export\s+)?)([A-Za-z_][A-Za-z0-9_]*)(\s*=\s*)(.*)$/) {
            my $prefix = $1;
            my $key = $2;
            my $eq = $3;
            my $value = $4;

            if ($key =~ $sensitive) {
                $_ = $prefix . $key . $eq . $mask . "\n";
            }
        }

        # --------------------------------------------------
        # Дополнительная защита внутри значений ENV
        # Если токен лежит в переменной с необычным названием,
        # попробуем скрыть известные форматы.
        # --------------------------------------------------

        # Telegram bot token:
        # 123456789:ABCDEF...
        s{\b\d{8,12}:[A-Za-z0-9_-]{25,}\b}{$mask}g;

        # OpenAI / похожие ключи
        s{sk-[A-Za-z0-9_-]{20,}}{$mask}g;

        # GitHub classic token
        s{ghp_[A-Za-z0-9_]{20,}}{$mask}g;

        # GitHub fine-grained token
        s{github_pat_[A-Za-z0-9_]{20,}}{$mask}g;

        # GitLab token
        s{glpat-[A-Za-z0-9_\-]{20,}}{$mask}g;

        # Google API key
        s{AIza[0-9A-Za-z\-_]{20,}}{$mask}g;

        # AWS access key
        s{AKIA[0-9A-Z]{16}}{$mask}g;

        # URL с логином/паролем:
        # mysql://user:password@host/db
        # redis://:password@host:6379
        s{([a-z][a-z0-9+.-]*://[^:\s/@]+:)[^@\s/]+(@)}{$1$mask$2}gi;
        s{([a-z][a-z0-9+.-]*://:)[^@\s/]+(@)}{$1$mask$2}gi;
    '
}

# ==========================================================
# 🛠 Формируем аргументы find
# ==========================================================
STRUCT_ARGS=()
for p in "${HIDE_DIRS[@]}"; do
    STRUCT_ARGS+=("!" "-path" "$p")
done

CONTENT_ARGS=("${STRUCT_ARGS[@]}")
for p in "${SKIP_CONTENT[@]}"; do
    CONTENT_ARGS+=("!" "-name" "$p")
done

# ==========================================================
# 📊 Считаем папки и файлы заранее
# ==========================================================
DIR_COUNT=$(find . -mindepth 1 -type d "${STRUCT_ARGS[@]}" 2>/dev/null | wc -l | tr -d ' ')
FILE_COUNT=$(find . -mindepth 1 -type f "${STRUCT_ARGS[@]}" 2>/dev/null | wc -l | tr -d ' ')

# ==========================================================
# 📝 ГЕНЕРАЦИЯ ОТЧЁТА
#
# Добавляем UTF-8 BOM, чтобы Windows / Notepad++ правильно
# открывали русский текст, а не превращали его в кракозябры.
# ==========================================================
printf '\xEF\xBB\xBF' > "$OUTPUT"

{
    echo "📁 ПОЛНАЯ СТРУКТУРА ПРОЕКТА И СОДЕРЖИМОЕ ФАЙЛОВ"
    echo "   Дата: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "   Корень: $(pwd)"
    echo "$DIVIDER"
    echo ""

    # ─── 1. СТРУКТУРА ───────────────────────────────────────
    echo "📂 СТРУКТУРА ПАПОК И ФАЙЛОВ:"
    echo ""

    if command -v tree &>/dev/null; then
        TREE_IGNORE="venv|__pycache__|.git|node_modules|.idea|logs|tmp|__MACOSX|app_versions|app_others|log_folder"
        tree -a --dirsfirst -I "$TREE_IGNORE" . 2>/dev/null || true
    else
        while IFS= read -r -d '' entry; do
            if [[ -d "$entry" ]]; then
                [[ "$entry" != "." ]] && echo "📂 ${entry}/"
            elif [[ -f "$entry" ]]; then
                echo "   📄 $entry"
            fi
        done < <(
            find . \( -type d -o -type f \) "${STRUCT_ARGS[@]}" -print0 2>/dev/null | sort -z
        )
    fi

    printf '\n%s\n\n' "$DIVIDER"

    # ─── 2. СОДЕРЖИМОЕ ФАЙЛОВ ───────────────────────────────
    echo "📄 СОДЕРЖИМОЕ ФАЙЛОВ:"
    echo ""

    while IFS= read -r -d '' file; do
        echo "📍 ПУТЬ: $file"
        echo "$DIVIDER"

        if grep -qI . "$file" 2>/dev/null; then

            if is_env_file "$file"; then
                echo "[🔐 ENV-файл: секретные значения скрыты]"
                cat "$file" 2>/dev/null | mask_env_secrets || echo "[⚠️  Ошибка чтения ENV-файла]"
            else
                cat "$file" 2>/dev/null || echo "[⚠️  Ошибка чтения файла]"
            fi

        else
            echo "[⚠️  Пропущено: бинарный файл]"
        fi

        printf '\n%s\n\n' "$DIVIDER"
    done < <(
        find . -mindepth 1 -type f "${CONTENT_ARGS[@]}" -print0 2>/dev/null | sort -z
    )

    # ─── 3. ИТОГИ ───────────────────────────────────────────
    echo "$DIVIDER"
    echo "📊 ИТОГО: ${DIR_COUNT} папок, ${FILE_COUNT} файлов (структура)"

} >> "$OUTPUT"

echo "✅ Готово! Отчёт: $OUTPUT"
echo "   Папок: $DIR_COUNT | Файлов: $FILE_COUNT"

# ==========================================================
# 📋 ГЕНЕРАЦИЯ ПРОМПТА ДЛЯ AI
# ==========================================================
printf '\xEF\xBB\xBF' > "$PROMPT_OUTPUT"

cat >> "$PROMPT_OUTPUT" << 'EOF'
Я отправляю тебе один большой файл. Внутри может быть:
- структура проекта;
- содержимое разных файлов;
- HTML / CSS / JavaScript;
- Python / Flask / Django / FastAPI;
- PHP / Bitrix / WordPress;
- Telegram Bot / Telethon;
- Docker / Linux;
- env-настройки;
- база данных;
- логи;
- ошибки;
- пояснения.

ТВОЯ ЗАДАЧА:
Сначала полностью прочитать и разобрать этот файл как карту проекта.

ВАЖНО:
Не изменяй файлы без моей прямой команды.
Не удаляй старую логику.
Не ломай рабочие функции.
Не придумывай то, чего нет в присланном файле.

ВАЖНО ПО БЕЗОПАСНОСТИ:
Если в ENV-файле вместо пароля, токена, API-ключа или session-string написано:
****пароль_здесь_скрыт_от_чтения****
значит это значение специально скрыто при генерации отчёта.
Не проси настоящий пароль без необходимости.
Работай по видимой структуре и настройкам.

ВАЖНО ПО КОДУ:
Секреты скрываются только в .env / *.env файлах.
Если в Python, JavaScript, HTML, PHP или другом коде видны строки вида:
os.getenv("TOKEN")
request.form.get("password")
api_hash = os.getenv(...)
это НЕ настоящий секрет, а логика кода.
Не считай это утечкой, если там нет реального значения ключа.

Но ты МОЖЕШЬ:
- анализировать код;
- искать причину ошибки;
- сравнивать связанные файлы;
- объяснять, где проблема;
- показывать опасные места;
- предлагать план исправления;
- показывать пример исправления, если это нужно для понимания;
- писать, какие файлы нужно будет менять.

РЕЖИМ 1 — ПОЛНОЕ ЧТЕНИЕ:

1. Прочитай весь присланный файл.
2. Определи, что внутри:
   - структура проекта;
   - содержимое файлов;
   - коды;
   - настройки;
   - база;
   - логи;
   - ошибки.
3. Если файл большой и часть обрезана, честно скажи:
   - что видно полностью;
   - что видно частично;
   - какие файлы нужно открыть или прислать дополнительно.
4. Не делай вывод по одному куску, пока не проверишь связанные файлы.

РЕЖИМ 2 — КАРТА ПРОЕКТА:

После чтения составь карту:
- тип проекта;
- главный файл запуска;
- папки и их назначение;
- маршруты / контроллеры;
- шаблоны / страницы;
- CSS / JS;
- база данных;
- env-настройки;
- логи;
- отдельные процессы;
- какие файлы связаны между собой.

РЕЖИМ 3 — ПОИСК ПРИЧИНЫ:

Если я прислал ошибку, баг, скриншот, лог или сказал "не работает", ты должен:

1. Найти все файлы, которые могут быть связаны с проблемой.
2. Прочитать не только один файл, а всю цепочку:
   - где вызывается функция;
   - откуда приходят данные;
   - куда сохраняются данные;
   - какой шаблон показывает результат;
   - какой JS/CSS влияет на поведение;
   - какие настройки могут ломать работу;
   - какие логи подтверждают ошибку.
3. Найти реальную причину, а не гадать.
4. Объяснить:
   - где именно проблема;
   - почему она возникает;
   - какой файл отвечает за это;
   - какую часть надо исправлять.
5. Если данных не хватает — честно сказать, какой файл или лог нужен.

РЕЖИМ 4 — ПРЕДЛОЖЕНИЕ ИСПРАВЛЕНИЯ:

Если причина найдена, дай:

1. Краткое объяснение проблемы.
2. Список файлов, которые нужно менять.
3. Что именно надо изменить.
4. Риск: может ли это сломать другие части проекта.
5. Только после этого дай код исправления, если я попросил:
   - "исправь",
   - "напиши код",
   - "дай замену",
   - "полностью напиши файл",
   - "сделай готовый вариант".

ПРАВИЛО БЕЗОПАСНОСТИ:

Пока я не дал команду менять код, ты не говоришь "я изменил файл".
Ты можешь только:
- анализировать;
- находить причину;
- объяснять;
- предлагать;
- показывать пример.

Если я дал команду "исправь" или "напиши полностью", тогда:
1. Сначала скажи, какой файл меняем.
2. Потом дай полный готовый код или точную замену блока.
3. Не сокращай код.
4. Не пиши "остальное без изменений", если я прошу полный файл.
5. Не убирай рабочие функции.
6. Не меняй имена маршрутов, функций, классов и переменных без необходимости.
7. Если меняешь — объясни почему.

ОТВЕЧАЙ:
На русском языке.
Конкретно по файлам, путям, функциям и ошибкам.
Без воды.
Если не уверен — скажи честно.
Если файл обрезан — не притворяйся, что прочитал всё.
EOF

echo "   Промпт: $PROMPT_OUTPUT"
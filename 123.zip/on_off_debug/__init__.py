# on_off_debug/__init__.py

from .debug_mode import (
    debug_info_print,
    debug_success_print,
    debug_success1_print,
    debug_warning_print,
    debug_error_print,
    debug_error1_print,
    critical_error_print,
    log_unicode,
    reload_debug_config,
    set_debug_mode,
    get_flask_debug_mode,
)
from .blueprint import create_debug_blueprint, register_debug_blueprint

__all__ = [
    "debug_info_print",
    "debug_success_print",
    "debug_success1_print",
    "debug_warning_print",
    "debug_error_print",
    "debug_error1_print",
    "critical_error_print",
    "log_unicode",
    "reload_debug_config",
    "set_debug_mode",
    "get_flask_debug_mode",
    "create_debug_blueprint",
    "register_debug_blueprint",
]

# on_off_debug/debug_mode.py
import os
import sys
from datetime import datetime
from typing import Optional

try:
    from on_off_debug.env_tools import (
        read_env_file,
        env_bool,
        env_str,
        resolve_log_dir,
        get_auto_ip,
    )
    from on_off_debug.auto_clean_log import (
        maybe_cleanup_old_logs,
        clean_on_start_if_enabled,
    )
    from on_off_debug.critical_notify import send_critical_notification
    from on_off_debug.internal_logger import write_internal_error

except ImportError:
    from env_tools import (
        read_env_file,
        env_bool,
        env_str,
        resolve_log_dir,
        get_auto_ip,
    )
    from auto_clean_log import (
        maybe_cleanup_old_logs,
        clean_on_start_if_enabled,
    )
    from critical_notify import send_critical_notification
    from internal_logger import write_internal_error


# ==========================================================
# Base paths
# ==========================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# ==========================================================
# Default App Identity
# Эти данные НЕ вставляются в обычные логи.
# Они используются только для critical-уведомлений.
# ==========================================================

DEFAULT_DEBUG_NAME_APP = "unknown_app"
DEFAULT_DEBUG_APP_IP = "auto"
DEFAULT_DEBUG_APP_ENV = "local"
DEFAULT_DEBUG_APP_INSTANCE = "main"


# ==========================================================
# Default Debug Modes
# ==========================================================

DEFAULT_DEBUG_INFO_MODE = True
DEFAULT_DEBUG_SUCCESS_MODE = True
DEFAULT_DEBUG_SUCCESS1_MODE = True
DEFAULT_DEBUG_WARNING_MODE = True
DEFAULT_DEBUG_ERROR_MODE = True
DEFAULT_DEBUG_ERROR1_MODE = True
DEFAULT_DEBUG_CRITICAL_ERROR_MODE = True
DEFAULT_DEBUG_UNICODE_MODE = True
DEFAULT_DEBUG_RELOAD_ENV_EACH_CALL = True


# ==========================================================
# Default Flask Settings
# Важно:
# DEBUG_FLASK_DEBUG управляет только Flask debug mode.
# Он НЕ связан с DEBUG_SUCCESS_MODE и другими логами.
# ==========================================================

DEFAULT_DEBUG_FLASK_DEBUG = False


# ==========================================================
# Working App Identity
# Эти значения загружаются из debug_module.env
# ==========================================================

DEBUG_NAME_APP = DEFAULT_DEBUG_NAME_APP
DEBUG_APP_IP = DEFAULT_DEBUG_APP_IP
DEBUG_APP_ENV = DEFAULT_DEBUG_APP_ENV
DEBUG_APP_INSTANCE = DEFAULT_DEBUG_APP_INSTANCE


# ==========================================================
# Working Debug Modes
# Эти значения загружаются из debug_module.env
# ==========================================================

DEBUG_INFO_MODE = DEFAULT_DEBUG_INFO_MODE
DEBUG_SUCCESS_MODE = DEFAULT_DEBUG_SUCCESS_MODE
DEBUG_SUCCESS1_MODE = DEFAULT_DEBUG_SUCCESS1_MODE
DEBUG_WARNING_MODE = DEFAULT_DEBUG_WARNING_MODE
DEBUG_ERROR_MODE = DEFAULT_DEBUG_ERROR_MODE
DEBUG_ERROR1_MODE = DEFAULT_DEBUG_ERROR1_MODE
DEBUG_CRITICAL_ERROR_MODE = DEFAULT_DEBUG_CRITICAL_ERROR_MODE
DEBUG_UNICODE_MODE = DEFAULT_DEBUG_UNICODE_MODE
DEBUG_RELOAD_ENV_EACH_CALL = DEFAULT_DEBUG_RELOAD_ENV_EACH_CALL


# ==========================================================
# Working Flask Settings
# ==========================================================

DEBUG_FLASK_DEBUG = DEFAULT_DEBUG_FLASK_DEBUG


# ==========================================================
# Log folder
# ==========================================================

BASE_LOG_DIR = os.path.join(BASE_DIR, "log_folder")


def _resolve_app_ip(value: str) -> str:
    """
    Возвращает IP приложения/сервера для critical-уведомлений.

    DEBUG_APP_IP=auto
        -> модуль попробует определить локальный IP сам.

    DEBUG_APP_IP=192.168.8.9
        -> будет использовать указанное значение.
    """
    value = str(value or "").strip()

    if not value or value.lower() == "auto":
        return get_auto_ip()

    return value


def reload_debug_config() -> None:
    """
    Перезагружает настройки debug из debug_module.env.
    """
    global DEBUG_NAME_APP
    global DEBUG_APP_IP
    global DEBUG_APP_ENV
    global DEBUG_APP_INSTANCE

    global DEBUG_INFO_MODE
    global DEBUG_SUCCESS_MODE
    global DEBUG_SUCCESS1_MODE
    global DEBUG_WARNING_MODE
    global DEBUG_ERROR_MODE
    global DEBUG_ERROR1_MODE
    global DEBUG_CRITICAL_ERROR_MODE
    global DEBUG_UNICODE_MODE
    global DEBUG_RELOAD_ENV_EACH_CALL

    global DEBUG_FLASK_DEBUG
    global BASE_LOG_DIR

    env_data = read_env_file()

    # ======================================================
    # App identity
    # Только для critical-уведомлений
    # ======================================================

    DEBUG_NAME_APP = env_str(
        env_data,
        "DEBUG_NAME_APP",
        DEFAULT_DEBUG_NAME_APP,
    )

    DEBUG_APP_IP = _resolve_app_ip(
        env_str(
            env_data,
            "DEBUG_APP_IP",
            DEFAULT_DEBUG_APP_IP,
        )
    )

    DEBUG_APP_ENV = env_str(
        env_data,
        "DEBUG_APP_ENV",
        DEFAULT_DEBUG_APP_ENV,
    )

    DEBUG_APP_INSTANCE = env_str(
        env_data,
        "DEBUG_APP_INSTANCE",
        DEFAULT_DEBUG_APP_INSTANCE,
    )

    # ======================================================
    # Debug modes
    # ======================================================

    DEBUG_INFO_MODE = env_bool(
        env_data,
        "DEBUG_INFO_MODE",
        DEFAULT_DEBUG_INFO_MODE,
    )

    DEBUG_SUCCESS_MODE = env_bool(
        env_data,
        "DEBUG_SUCCESS_MODE",
        DEFAULT_DEBUG_SUCCESS_MODE,
    )

    DEBUG_SUCCESS1_MODE = env_bool(
        env_data,
        "DEBUG_SUCCESS1_MODE",
        DEFAULT_DEBUG_SUCCESS1_MODE,
    )

    DEBUG_WARNING_MODE = env_bool(
        env_data,
        "DEBUG_WARNING_MODE",
        DEFAULT_DEBUG_WARNING_MODE,
    )

    DEBUG_ERROR_MODE = env_bool(
        env_data,
        "DEBUG_ERROR_MODE",
        DEFAULT_DEBUG_ERROR_MODE,
    )

    DEBUG_ERROR1_MODE = env_bool(
        env_data,
        "DEBUG_ERROR1_MODE",
        DEFAULT_DEBUG_ERROR1_MODE,
    )

    DEBUG_CRITICAL_ERROR_MODE = env_bool(
        env_data,
        "DEBUG_CRITICAL_ERROR_MODE",
        DEFAULT_DEBUG_CRITICAL_ERROR_MODE,
    )

    DEBUG_UNICODE_MODE = env_bool(
        env_data,
        "DEBUG_UNICODE_MODE",
        DEFAULT_DEBUG_UNICODE_MODE,
    )

    DEBUG_RELOAD_ENV_EACH_CALL = env_bool(
        env_data,
        "DEBUG_RELOAD_ENV_EACH_CALL",
        DEFAULT_DEBUG_RELOAD_ENV_EACH_CALL,
    )

    # ======================================================
    # Flask settings
    # DEBUG_FLASK_DEBUG управляет только app.run(debug=...)
    # ======================================================

    DEBUG_FLASK_DEBUG = env_bool(
        env_data,
        "DEBUG_FLASK_DEBUG",
        DEFAULT_DEBUG_FLASK_DEBUG,
    )

    # ======================================================
    # Log folder
    # Имя приложения НЕ используется для папок логов.
    # Логи пишутся просто в DEBUG_LOG_DIR.
    # ======================================================

    BASE_LOG_DIR = resolve_log_dir(env_data)


def _reload_before_call_if_enabled() -> None:
    """
    Если DEBUG_RELOAD_ENV_EACH_CALL=True,
    настройки перечитываются перед каждым логом.
    """
    if DEBUG_RELOAD_ENV_EACH_CALL:
        reload_debug_config()


def _console_write(level: str, text: str, is_error: bool = False) -> None:
    """
    Безопасный вывод в консоль без обычного print().
    """
    try:
        stream = sys.stderr if is_error else sys.stdout
        stream.write(f"[{level}] {text}\n")
        stream.flush()

    except Exception as e:
        write_internal_error(
            "debug_mode._console_write",
            str(e),
        )


def _format_log_message(message: str, source: Optional[str] = None) -> str:
    """
    Формирует строку обычного лога.

    Важно:
    DEBUG_NAME_APP и DEBUG_APP_IP сюда НЕ добавляются.
    Они используются только при отправке critical-уведомлений.
    """
    parts = []

    if source:
        parts.append(f"[SOURCE:{source}]")

    parts.append(str(message))

    return " ".join(parts)


def write_log(
    subfolder: str,
    filename: str,
    message: str,
) -> Optional[str]:
    """
    Записывает сообщение в лог-файл в UTF-8.

    Возвращает путь к файлу лога.
    """
    try:
        today = datetime.now().strftime("%d.%m.%Y")
        log_dir = os.path.join(BASE_LOG_DIR, subfolder, today)
        os.makedirs(log_dir, exist_ok=True)

        log_path = os.path.join(log_dir, filename)

        with open(log_path, "a", encoding="utf-8") as f:
            timestamp = datetime.now().strftime("%H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")

        maybe_cleanup_old_logs()

        return log_path

    except Exception as e:
        write_internal_error(
            "debug_mode.write_log",
            str(e),
        )

        return None


def log_unicode(msg: str) -> None:
    """
    Пишет строку msg в stderr напрямую в UTF-8.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_UNICODE_MODE:
        return

    try:
        sys.stderr.buffer.write(str(msg).encode("utf-8"))
        sys.stderr.buffer.write(b"\n")
        sys.stderr.flush()

    except Exception as e:
        write_internal_error(
            "debug_mode.log_unicode",
            str(e),
        )


# ==========================================================
# Debug print functions
# ==========================================================

def debug_info_print(
    message,
    source: Optional[str] = None,
) -> None:
    """
    INFO — обычная информация.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_INFO_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("INFO", final_message)
    write_log("info_print", "info_log.log", final_message)


def debug_success_print(
    message,
    source: Optional[str] = None,
) -> None:
    """
    SUCCESS — успешное выполнение действия.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_SUCCESS_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("SUCCESS", final_message)
    write_log("success_print", "s_log.log", final_message)


def debug_success1_print(
    message,
    source: Optional[str] = None,
) -> None:
    """
    SUCCESS1 — успешный внутренний этап.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_SUCCESS1_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("SUCCESS1", final_message)
    write_log("success1_print", "s1_log.log", final_message)


def debug_warning_print(
    message,
    source: Optional[str] = None,
) -> None:
    """
    WARNING — предупреждение.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_WARNING_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("WARNING", final_message)
    write_log("warning_print", "warning_log.log", final_message)


def debug_error_print(
    message,
    source: Optional[str] = None,
) -> None:
    """
    ERROR — ошибка операции.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_ERROR_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("ERROR", final_message, is_error=True)
    write_log("error_print", "e_log.log", final_message)


def debug_error1_print(
    message,
    source: Optional[str] = None,
) -> None:
    """
    ERROR1 — внутренняя ошибка второго уровня.
    """
    _reload_before_call_if_enabled()

    if not DEBUG_ERROR1_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("ERROR1", final_message, is_error=True)
    write_log("error1_print", "e1_log.log", final_message)


def critical_error_print(
    message: str,
    source: Optional[str] = None,
) -> None:
    """
    CRITICAL — критическая ошибка.

    Только эта функция отправляет уведомления:
    Telegram / Email / Webhook.

    В notification передаются:
    DEBUG_NAME_APP
    DEBUG_APP_IP
    DEBUG_APP_ENV
    DEBUG_APP_INSTANCE
    """
    _reload_before_call_if_enabled()

    if not DEBUG_CRITICAL_ERROR_MODE:
        return

    final_message = _format_log_message(str(message), source)

    _console_write("CRITICAL_ERROR", final_message, is_error=True)

    log_path = write_log(
        "critical_error_print",
        "critical_log.log",
        final_message,
    )

    send_critical_notification(
        message=str(message),
        app_name=DEBUG_NAME_APP,
        app_ip=DEBUG_APP_IP,
        app_env=DEBUG_APP_ENV,
        app_instance=DEBUG_APP_INSTANCE,
        source=source,
        log_path=log_path,
    )


# ==========================================================
# Flask helper
# ==========================================================

def get_flask_debug_mode() -> bool:
    """
    Возвращает Flask debug mode из debug_module.env.

    Используется только для:

        app.run(debug=...)

    Важно:
    это НЕ связано с DEBUG_SUCCESS_MODE.
    """
    reload_debug_config()
    return DEBUG_FLASK_DEBUG


# ==========================================================
# Manual runtime control
# ==========================================================

def set_debug_mode(
    info: bool = True,
    success: bool = True,
    success1: bool = True,
    warning: bool = True,
    error: bool = True,
    error1: bool = True,
    critical_error: bool = True,
    unicode_log: bool = True,
) -> None:
    """
    Временно меняет режимы в текущем процессе.

    После перезапуска или reload_debug_config()
    снова будут использоваться настройки из debug_module.env.
    """
    global DEBUG_INFO_MODE
    global DEBUG_SUCCESS_MODE
    global DEBUG_SUCCESS1_MODE
    global DEBUG_WARNING_MODE
    global DEBUG_ERROR_MODE
    global DEBUG_ERROR1_MODE
    global DEBUG_CRITICAL_ERROR_MODE
    global DEBUG_UNICODE_MODE

    DEBUG_INFO_MODE = info
    DEBUG_SUCCESS_MODE = success
    DEBUG_SUCCESS1_MODE = success1
    DEBUG_WARNING_MODE = warning
    DEBUG_ERROR_MODE = error
    DEBUG_ERROR1_MODE = error1
    DEBUG_CRITICAL_ERROR_MODE = critical_error
    DEBUG_UNICODE_MODE = unicode_log


# ==========================================================
# Auto load config
# ==========================================================

reload_debug_config()
clean_on_start_if_enabled()

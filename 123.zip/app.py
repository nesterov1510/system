from flask import Flask, redirect, url_for
from on_off_debug import get_flask_debug_mode, register_debug_blueprint, debug_info_print
from session_secret_key.session_secret_key_settings import apply_session_secret_key
from start_ip_controll.ip_controll import get_flask_start_config
from access_control import init_access_control
from access_control.access_settings import get_current_access_user
from access_control.user_store import has_permission
from routes.registry import register_project_blueprints
from config import PROJECT_INFO


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
    )
    apply_session_secret_key(app)
    register_debug_blueprint(app, url_prefix="/debug")
    init_access_control(app)

    @app.context_processor
    def inject_project_info():
        """Expose project identity and current Access Control permissions to Jinja."""
        current_user = get_current_access_user()
        return {
            "project_info": PROJECT_INFO,
            "current_access_user": current_user,
            "access_can": lambda permission: has_permission(current_user, permission),
        }

    # Stable application root endpoint.
    # System modules such as access_control/on_off_debug use url_for("index").
    # Keep this endpoint outside blueprints so those modules do not depend on
    # the internal name of the dashboard blueprint.
    @app.get("/", endpoint="index")
    def index():
        # Keep a stable global endpoint for system modules (access_control/debug),
        # but let the dashboard blueprint build its own template context.
        # Rendering dashboard/index.html here directly is unsafe because that
        # template requires metrics and finance_chart.
        return redirect(url_for("dashboard.index"))

    register_project_blueprints(app)
    return app


app = create_app()

if __name__ == "__main__":
    flask_debug = get_flask_debug_mode()
    start_config = get_flask_start_config()
    debug_info_print(
        f"MSB Flask запускается: host={start_config.host}, port={start_config.port}, debug={flask_debug}",
        source="app.start",
    )
    app.run(host=start_config.host, port=start_config.port, debug=flask_debug)

document.addEventListener("DOMContentLoaded", () => {
    const hero = document.querySelector(".hero-card");
    if (hero) hero.dataset.loaded = "true";
});

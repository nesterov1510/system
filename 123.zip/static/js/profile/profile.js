document.addEventListener('DOMContentLoaded', () => {
  const search = document.querySelector('[data-permission-search]');
  const groups = Array.from(document.querySelectorAll('[data-permission-group]'));
  const empty = document.querySelector('[data-permission-empty]');

  groups.forEach((group) => {
    const toggle = group.querySelector('[data-permission-group-toggle]');
    if (!toggle) return;
    toggle.addEventListener('click', () => {
      const collapsed = group.classList.toggle('is-collapsed');
      toggle.setAttribute('aria-expanded', String(!collapsed));
    });
  });

  const applyFilter = () => {
    const query = (search?.value || '').trim().toLowerCase();
    let visibleGroups = 0;

    groups.forEach((group) => {
      const rows = Array.from(group.querySelectorAll('[data-permission-row]'));
      let visibleRows = 0;
      rows.forEach((row) => {
        const haystack = (row.dataset.searchText || '').toLowerCase();
        const visible = !query || haystack.includes(query);
        row.hidden = !visible;
        if (visible) visibleRows += 1;
      });
      group.hidden = visibleRows === 0;
      if (visibleRows > 0) {
        visibleGroups += 1;
        if (query) {
          group.classList.remove('is-collapsed');
          group.querySelector('[data-permission-group-toggle]')?.setAttribute('aria-expanded', 'true');
        }
      }
    });

    if (empty) empty.hidden = visibleGroups !== 0;
  };

  search?.addEventListener('input', applyFilter);

  let toast;
  const showToast = (text) => {
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'profile-copy-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = text;
    toast.classList.add('is-visible');
    window.clearTimeout(showToast.timer);
    showToast.timer = window.setTimeout(() => toast.classList.remove('is-visible'), 1500);
  };

  document.querySelectorAll('[data-copy-value]').forEach((button) => {
    button.addEventListener('click', async () => {
      const value = button.dataset.copyValue || '';
      if (!value) return;
      try {
        await navigator.clipboard.writeText(value);
        showToast('Скопировано');
      } catch (_) {
        const input = document.createElement('textarea');
        input.value = value;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        input.remove();
        showToast('Скопировано');
      }
    });
  });
});

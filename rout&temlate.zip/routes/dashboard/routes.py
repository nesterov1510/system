from __future__ import annotations

from calendar import monthrange
from datetime import date, datetime, timedelta

from flask import Blueprint, jsonify, render_template, request

bp = Blueprint("dashboard", __name__, url_prefix="/dashboard")


PERIODS = {
    "today": "Сегодня",
    "week": "Неделя",
    "14d": "14 дней",
    "month": "Месяц",
    "3m": "3 месяца",
    "6m": "6 месяцев",
    "year": "Год",
    "all": "Всё время",
    "custom": "Свой период",
}


def _subtract_months(value: date, months: int) -> date:
    """Return a date shifted back by whole calendar months without extra deps."""
    month_index = value.year * 12 + (value.month - 1) - months
    year, month_zero = divmod(month_index, 12)
    month = month_zero + 1
    day = min(value.day, monthrange(year, month)[1])
    return date(year, month, day)


def _parse_iso_date(raw: str | None) -> date | None:
    if not raw:
        return None
    try:
        return datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        return None


def _period_bounds(period: str, date_from: date | None = None, date_to: date | None = None) -> tuple[date, date, str]:
    today = date.today()

    if period == "today":
        return today, today, "Сегодня"
    if period == "week":
        return today - timedelta(days=6), today, "Последние 7 дней"
    if period == "14d":
        return today - timedelta(days=13), today, "Последние 14 дней"
    if period == "month":
        return today - timedelta(days=29), today, "Последние 30 дней"
    if period == "3m":
        return _subtract_months(today, 3) + timedelta(days=1), today, "Последние 3 месяца"
    if period == "6m":
        return _subtract_months(today, 6) + timedelta(days=1), today, "Последние 6 месяцев"
    if period == "year":
        return _subtract_months(today, 12) + timedelta(days=1), today, "Последние 12 месяцев"
    if period == "custom" and date_from and date_to:
        start, end = sorted((date_from, date_to))
        return start, end, f"{start.strftime('%d.%m.%Y')} — {end.strftime('%d.%m.%Y')}"

    # Пока реальные финансовые записи не подключены, для пустого "всё время"
    # используем текущий календарный год. После подключения БД start должен стать
    # датой самой ранней финансовой операции.
    return date(today.year, 1, 1), today, "За всё время"


def _month_starts(start: date, end: date) -> list[date]:
    cursor = date(start.year, start.month, 1)
    result: list[date] = []
    while cursor <= end:
        result.append(cursor)
        if cursor.month == 12:
            cursor = date(cursor.year + 1, 1, 1)
        else:
            cursor = date(cursor.year, cursor.month + 1, 1)
    return result or [start]


def _empty_finance_data(period: str = "14d", date_from: date | None = None, date_to: date | None = None) -> dict:
    """Temporary finance data contract until real payment/expense services are connected.

    The response already changes bucket density according to the selected period, so the
    frontend and future DB service can keep the same API contract.
    """
    start, end, caption = _period_bounds(period, date_from, date_to)
    span_days = max(1, (end - start).days + 1)

    points: list[date]
    bucket = "day"

    if span_days <= 45:
        points = [start + timedelta(days=i) for i in range(span_days)]
    elif span_days <= 220:
        bucket = "week"
        points = []
        cursor = start
        while cursor <= end:
            points.append(cursor)
            cursor += timedelta(days=7)
        if points[-1] != end:
            points.append(end)
    else:
        bucket = "month"
        points = _month_starts(start, end)
        if points[-1] != end:
            points.append(end)

    if bucket == "day":
        labels = [point.strftime("%d.%m") for point in points]
        tooltip_labels = [point.strftime("%d.%m.%Y") for point in points]
    elif bucket == "week":
        labels = [point.strftime("%d.%m") for point in points]
        tooltip_labels = [f"Неделя с {point.strftime('%d.%m.%Y')}" for point in points]
    else:
        month_names = ["", "Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"]
        labels = [f"{month_names[point.month]} {str(point.year)[2:]}" for point in points]
        tooltip_labels = [point.strftime("%m.%Y") for point in points]

    return {
        "period": period,
        "period_label": PERIODS.get(period, PERIODS["14d"]),
        "caption": caption,
        "date_from": start.isoformat(),
        "date_to": end.isoformat(),
        "bucket": bucket,
        "labels": labels,
        "tooltip_labels": tooltip_labels,
        # Оборот = все поступившие деньги за период.
        # При подключении БД заполняется из платежей/кассы, прибыль считается отдельно.
        "turnover": [0 for _ in points],
        "profit": [0 for _ in points],
        "expenses": [0 for _ in points],
        "currency": "TMT",
    }


def _empty_dashboard_data():
    metrics = {
        "all_repairs": 0,
        "ready": 0,
        "waiting_parts": 0,
        "accepted_today": 0,
        "in_repair": 0,
        "not_picked_up": 0,
        "disposable": 0,
        "warranty": 0,
    }
    return metrics, _empty_finance_data("14d")


@bp.get("/")
def index():
    metrics, finance_chart = _empty_dashboard_data()
    return render_template(
        "dashboard/index.html",
        metrics=metrics,
        finance_chart=finance_chart,
        finance_periods=PERIODS,
    )


@bp.get("/finance-data")
def finance_data():
    period = request.args.get("period", "14d").strip().lower()
    if period not in PERIODS:
        period = "14d"

    date_from = _parse_iso_date(request.args.get("date_from"))
    date_to = _parse_iso_date(request.args.get("date_to"))

    if period == "custom" and (not date_from or not date_to):
        return jsonify({"ok": False, "error": "Для своего периода укажите обе даты."}), 400

    payload = _empty_finance_data(period, date_from, date_to)
    payload["ok"] = True
    return jsonify(payload)

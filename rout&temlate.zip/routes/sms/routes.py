from flask import Blueprint, render_template

bp = Blueprint("sms", __name__, url_prefix="/sms")

@bp.get("/")
def index():
    return render_template("sms/index.html")

from flask import Blueprint, render_template

bp = Blueprint("donors", __name__, url_prefix="/donors")

@bp.get("/")
def index():
    return render_template("donors/index.html")

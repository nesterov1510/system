from flask import Blueprint, render_template

bp = Blueprint("chat", __name__, url_prefix="/chat")

@bp.get("/")
def index():
    return render_template("chat/index.html")

from flask import Blueprint, render_template

bp = Blueprint("oplata", __name__, url_prefix="/payments")

@bp.get("/")
def index():
    return render_template("oplata/index.html")

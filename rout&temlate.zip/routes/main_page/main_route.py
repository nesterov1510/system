# routes/main_page/main_route.py
"""
Главная страница основного Flask-приложения.

Структура сделана шаблонно:

routes/
└── main_page/
    └── main_route.py

Так в будущем можно добавлять новые разделы:

routes/
├── main_page/
│   └── main_route.py
├── dashboard/
│   └── dashboard_route.py
├── api/
│   └── api_route.py
└── users/
    └── users_route.py
"""
from __future__ import annotations

from flask import Flask, render_template

try:
    from on_off_debug import debug_info_print
except Exception:  # pragma: no cover
    def debug_info_print(message, source=None) -> None:
        return None


LOG_SOURCE = "routes.main_page.main_route"


def register_main_page_routes(app: Flask) -> None:
    """
    Регистрирует route главной страницы.

    Важно:
    endpoint остаётся "index", потому что используется обычный @app.route("/").
    Поэтому старые ссылки url_for("index") не ломаются.
    """

    @app.route("/")
    def index():
        debug_info_print(
            "Открыта главная страница проекта",
            source=LOG_SOURCE,
        )
        return render_template("main.html")

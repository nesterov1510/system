# routes/main_page/__init__.py

from .main_route import register_main_page_routes

__all__ = [
    "register_main_page_routes",
]

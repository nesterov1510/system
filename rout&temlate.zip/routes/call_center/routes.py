from flask import Blueprint, render_template

bp = Blueprint("call_center", __name__, url_prefix="/callcenter")

@bp.get("/")
def index():
    return render_template("call-center/index.html")

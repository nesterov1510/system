"""MSB route blueprints."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from flask import Blueprint, redirect, render_template, session, url_for

from access_control.access_settings import get_current_access_user
from access_control.permissions import (
    ALL_PERMISSIONS,
    PERMISSION_GROUPS,
    default_permissions_for,
)

bp = Blueprint("profile", __name__, url_prefix="/profile")

PROJECT_TZ = timezone(timedelta(hours=5), name="Asia/Ashgabat")


def _format_date(value) -> str:
    if not value:
        return "—"
    if isinstance(value, datetime):
        value = value.date()
    if isinstance(value, date):
        return value.strftime("%d.%m.%Y")
    return str(value)


def _format_datetime(value) -> str:
    if not value:
        return "—"
    if isinstance(value, datetime):
        try:
            if value.tzinfo is None:
                value = value.replace(tzinfo=timezone.utc)
            value = value.astimezone(PROJECT_TZ)
        except Exception:
            pass
        return value.strftime("%d.%m.%Y %H:%M")
    return str(value)


def _calculate_age(birth_date) -> int | None:
    if not isinstance(birth_date, date):
        return None
    today = date.today()
    return today.year - birth_date.year - (
        (today.month, today.day) < (birth_date.month, birth_date.day)
    )


def _session_started_at() -> str:
    raw = session.get("access_login_at")
    if not raw:
        return "—"
    try:
        value = datetime.fromtimestamp(float(raw), tz=PROJECT_TZ)
        return value.strftime("%d.%m.%Y %H:%M")
    except Exception:
        return "—"


@bp.get("/")
def index():
    user = get_current_access_user()
    if not user:
        return redirect(url_for("access_control.access_control_page", next="/profile/"))

    effective_permissions = set(user.get("permissions") or [])
    if user.get("role") == "super_admin":
        effective_permissions = set(ALL_PERMISSIONS)

    role_defaults = set(default_permissions_for(user.get("role")))
    permission_groups = []
    granted_total = 0

    for group_name, permissions in PERMISSION_GROUPS.items():
        items = []
        granted_in_group = 0
        for code, label in permissions.items():
            granted = code in effective_permissions
            if granted:
                granted_total += 1
                granted_in_group += 1
            items.append({
                "code": code,
                "label": label,
                "granted": granted,
                "role_default": code in role_defaults,
            })
        permission_groups.append({
            "name": group_name,
            "items": items,
            "granted": granted_in_group,
            "total": len(items),
        })

    permissions_mode = "Полный доступ" if user.get("role") == "super_admin" else (
        "Индивидуально настроены"
        if effective_permissions != role_defaults
        else "По роли"
    )

    profile = {
        **user,
        "birth_date_text": _format_date(user.get("birth_date")),
        "age": _calculate_age(user.get("birth_date")),
        "created_at_text": _format_datetime(user.get("created_at")),
        "updated_at_text": _format_datetime(user.get("updated_at")),
        "last_login_at_text": _format_datetime(user.get("last_login_at")),
        "session_started_at_text": _session_started_at(),
        "session_ip": session.get("access_ip") or "—",
        "permissions_mode": permissions_mode,
        "granted_permissions": granted_total,
        "total_permissions": len(ALL_PERMISSIONS),
    }

    # Never send password/storage internals to templates.
    profile.pop("password_hash", None)
    profile.pop("permissions_json", None)

    return render_template(
        "profile/index.html",
        profile=profile,
        permission_groups=permission_groups,
    )

from flask import Blueprint, render_template

bp = Blueprint("print_center", __name__, url_prefix="/print")

@bp.get("/")
def index():
    return render_template("print-center/index.html")

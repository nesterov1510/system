from flask import Blueprint, render_template

bp = Blueprint("ai", __name__, url_prefix="/ai")

@bp.get("/")
def index():
    return render_template("ai/index.html")

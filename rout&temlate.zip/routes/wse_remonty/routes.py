from flask import Blueprint, render_template

bp = Blueprint("wse_remonty", __name__, url_prefix="/repairs")

@bp.get("/")
def index():
    return render_template("wse-remonty/index.html")

from flask import Blueprint, render_template

bp = Blueprint("notifications", __name__, url_prefix="/notifications")

@bp.get("/")
def index():
    return render_template("notifications/index.html")

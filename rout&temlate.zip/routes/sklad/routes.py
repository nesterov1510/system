from flask import Blueprint, render_template

bp = Blueprint("sklad", __name__, url_prefix="/warehouse")

@bp.get("/")
def index():
    return render_template("sklad/index.html")

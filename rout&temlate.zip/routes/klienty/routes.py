from flask import Blueprint, render_template

bp = Blueprint("klienty", __name__, url_prefix="/clients")

@bp.get("/")
def index():
    return render_template("klienty/index.html")

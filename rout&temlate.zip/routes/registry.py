from flask import Flask


def register_project_blueprints(app: Flask) -> None:
    from routes.dashboard.routes import bp as dashboard_bp
    from routes.wse_remonty.routes import bp as wse_remonty_bp
    from routes.priemka.routes import bp as priemka_bp
    from routes.klienty.routes import bp as klienty_bp
    from routes.sklad.routes import bp as sklad_bp
    from routes.donors.routes import bp as donors_bp
    from routes.oplata.routes import bp as oplata_bp
    from routes.call_center.routes import bp as call_center_bp
    from routes.chat.routes import bp as chat_bp
    from routes.notifications.routes import bp as notifications_bp
    from routes.print_center.routes import bp as print_center_bp
    from routes.sms.routes import bp as sms_bp
    from routes.ai.routes import bp as ai_bp
    from routes.reports.routes import bp as reports_bp
    from routes.admin.routes import bp as admin_bp
    from routes.profile.routes import bp as profile_bp
    from routes.public_repair.routes import bp as public_repair_bp

    for blueprint in (
        dashboard_bp,
        wse_remonty_bp,
        priemka_bp,
        klienty_bp,
        sklad_bp,
        donors_bp,
        oplata_bp,
        call_center_bp,
        chat_bp,
        notifications_bp,
        print_center_bp,
        sms_bp,
        ai_bp,
        reports_bp,
        admin_bp,
        profile_bp,
        public_repair_bp,
    ):
        app.register_blueprint(blueprint)

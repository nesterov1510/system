from flask import Blueprint, render_template

bp = Blueprint("priemka", __name__, url_prefix="/intake")


@bp.get("/")
def index():
    return render_template("priemka/index.html")


@bp.get("/televisions/")
def televisions():
    return render_template("priemka/televisions/index.html")


@bp.get("/monitors/")
def monitors():
    return render_template("priemka/monitors/index.html")


@bp.get("/android-tuners/")
def android_tuners():
    return render_template("priemka/android-tuners/index.html")


@bp.get("/computers-laptops/")
def computers_laptops():
    return render_template("priemka/computers-laptops/index.html")


@bp.get("/other-repair/")
def other_repair():
    return render_template("priemka/other-repair/index.html")

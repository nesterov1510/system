from flask import Blueprint, render_template

bp = Blueprint("public_repair", __name__, url_prefix="/r")

@bp.get("/<token>")
def status(token: str):
    return render_template("public-repair/status.html", token=token)

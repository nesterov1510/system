from flask import Blueprint, redirect, url_for

bp = Blueprint("admin", __name__, url_prefix="/admin")

@bp.get("/")
def index():
    """User/role administration lives in Access Control."""
    return redirect(url_for("access_control.access_control_page"))

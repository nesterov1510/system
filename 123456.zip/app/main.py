import asyncio
import contextlib
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.db.base import Base
from app.db.datamigrate import run_data_migrations
from app.db.migrate import run_migrations
from app.db.models import *  # noqa: F401,F403 — register all models
from app.db.seed import seed
from app.db.session import async_session_factory, engine
from app.services.reminders import reminder_loop
from app.routers import (
    admin,
    ai,
    auth,
    callcenter,
    chat,
    equipment,
    lookups,
    notifications,
    parts,
    payments,
    prices,
    prints,
    public,
    repairs,
    stats,
    ws,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # MVP: create tables + seed. Replace with Alembic migrations later.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # Новые колонки в уже существующих таблицах (create_all их не добавляет).
    await run_migrations(engine)
    async with async_session_factory() as db:
        await seed(db)
        # Одноразовые пересчёты уже лежащих в БД значений (идемпотентно).
        await run_data_migrations(db)
    # Local file storage for photos (MVP).
    if settings.STORAGE_MODE == "local":
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

    # Фоновая задача: ежедневные SMS-напоминания «заберите технику».
    # Живёт в том же процессе, что и API (при `--workers 1` — одна копия;
    # на нескольких воркерах от двойной отправки защищает условный UPDATE
    # в services/reminders.py).
    reminder_stop = asyncio.Event()
    reminder_task = None
    if settings.REMINDER_ENABLED:
        reminder_task = asyncio.create_task(reminder_loop(reminder_stop))
    try:
        yield
    finally:
        reminder_stop.set()
        if reminder_task is not None:
            reminder_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await reminder_task


app = FastAPI(
    title=settings.APP_NAME,
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

api_prefix = settings.API_PREFIX

app.include_router(auth.router, prefix=api_prefix)
app.include_router(chat.router, prefix=api_prefix)
app.include_router(lookups.router, prefix=api_prefix)
app.include_router(repairs.router, prefix=api_prefix)
app.include_router(callcenter.router, prefix=api_prefix)
app.include_router(prices.router, prefix=api_prefix)
app.include_router(parts.router, prefix=api_prefix)
app.include_router(equipment.router, prefix=api_prefix)
app.include_router(payments.router, prefix=api_prefix)
app.include_router(stats.router, prefix=api_prefix)
app.include_router(ai.router, prefix=api_prefix)
app.include_router(notifications.router, prefix=api_prefix)
app.include_router(public.router, prefix=api_prefix)
app.include_router(prints.router, prefix=api_prefix)
app.include_router(admin.router, prefix=api_prefix)
app.include_router(ws.router)  # WS has no prefix

# --------------------------------------------------------------------------
# Python server-rendered web UI (Jinja2 + HTMX) — замена React/Next.js фронта.
# Страницы на тех же моделях/сервисах/правах, что и JSON-API.
# --------------------------------------------------------------------------
from pathlib import Path as _Path

from app.webui import (
    routes_admin as _web_admin,
    routes_auth as _web_auth,
    routes_chat as _web_chat,
    routes_misc as _web_misc,
    routes_public as _web_public,
    routes_repairs as _web_repairs,
)

_web_static_dir = str(_Path(__file__).parent / "webui" / "static")
app.mount("/static", StaticFiles(directory=_web_static_dir), name="webui-static")

# Публичная страница клиента (без авторизации) — регистрируется до общих.
app.include_router(_web_public.router)
app.include_router(_web_auth.router)
app.include_router(_web_repairs.router)
app.include_router(_web_misc.router)
app.include_router(_web_chat.router)
app.include_router(_web_admin.router)


@app.get("/", include_in_schema=False)
async def _root():
    return RedirectResponse("/repairs", status_code=303)


# Serve uploaded photos (local storage mode).
if settings.STORAGE_MODE == "local":
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    app.mount("/media", StaticFiles(directory=settings.UPLOAD_DIR), name="media")


@app.get("/health", tags=["health"])
async def health():
    return {"status": "ok", "app": settings.APP_NAME}

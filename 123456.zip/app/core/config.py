"""Application configuration.

All values come from environment variables (see `.env.example`).
Secrets live only in env — never hardcoded.
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- App ---
    APP_NAME: str = "MSB"
    ENV: str = "dev"  # dev | prod
    API_PREFIX: str = "/api"
    # Публичный адрес самого сервиса (он отдаёт и HTML-интерфейс, и публичную
    # QR-страницу /r/{token}). Отдельного фронтенда нет — это адрес API на :8085.
    # Для локальной сети укажите IP машины, например http://192.168.8.81:8085
    PUBLIC_BASE_URL: str = "http://localhost:8085"

    # --- Database ---
    # prod: postgresql+asyncpg://user:pass@postgres:5432/msb
    # dev/test (sandbox): sqlite+aiosqlite:///./msb.db
    DATABASE_URL: str = "sqlite+aiosqlite:///./msb.db"

    # --- Auth / JWT ---
    SECRET_KEY: str = "CHANGE_ME_dev_only_0123456789abcdef0123456789abcdef"
    ACCESS_TOKEN_TTL_MIN: int = 30
    REFRESH_TOKEN_TTL_DAYS: int = 7
    ALGORITHM: str = "HS256"

    # --- CORS ---
    # Интерфейс отдаётся тем же сервисом (same-origin на :8085), CORS нужен
    # только внешним API-клиентам.
    CORS_ORIGINS: list[str] = ["http://localhost:8085", "http://127.0.0.1:8085"]

    # --- Storage ---
    # local = filesystem (dev/MVP), s3 = MinIO/S3-compatible (prod).
    STORAGE_MODE: str = "local"
    UPLOAD_DIR: str = "./uploads"
    S3_ENDPOINT: str = "http://localhost:9000"
    S3_ACCESS_KEY: str = "minioadmin"
    S3_SECRET_KEY: str = "minioadmin"
    S3_BUCKET: str = "msb"

    # --- AI ---
    AI_PROVIDER: str = "openai_compat"  # abstraction key
    AI_API_KEY: str = ""
    AI_BASE_URL: str = ""
    AI_MODEL: str = ""

    # --- SMS gateway ---
    # Реальные значения (URL/логин/пароль/вкл-выкл) настраиваются в админке
    # (Admin → SMS, хранится в БД как Setting["sms_server"]) либо через env.
    #
    # ВАЖНО: здесь намеренно НЕТ боевых логина/пароля. Секреты не должны
    # попадать в исходники и в git-историю — только env или настройки в БД.
    # При пустом URL/логине отправка просто возвращает {"ok": False}.
    SMS_ENABLED: bool = False
    SMS_GATEWAY_URL: str = ""
    SMS_GATEWAY_USERNAME: str = ""
    SMS_GATEWAY_PASSWORD: str = ""
    # Сертификат шлюза может быть самоподписанным — тогда это аналог `curl -k`.
    # Включайте только для доверенной внутренней сети.
    SMS_VERIFY_SSL: bool = True
    SMS_TIMEOUT_SEC: float = 10.0

    # --- Ежедневные напоминания «заберите технику» ---
    #
    # После «Ремонт закончен» клиенту раз в сутки уходит SMS с просьбой забрать
    # технику, пока ремонт не выдан (статусы «Готово к выдаче» / «Не забрано»).
    # Текст — шаблон `pickup_reminder` в «Админ → SMS».
    REMINDER_ENABLED: bool = True
    # Как часто фоновая задача просматривает очередь напоминаний (минуты).
    REMINDER_CHECK_INTERVAL_MIN: int = 15
    # Периодичность напоминаний одному клиенту (часы). 24 = раз в сутки.
    REMINDER_EVERY_HOURS: int = 24
    # Первое напоминание — через столько часов после «Ремонт закончен»
    # (в тот же день клиент уже получил SMS о готовности).
    REMINDER_FIRST_DELAY_HOURS: int = 24
    # Тихие часы: не будим клиента ночью (по местному времени сервиса).
    REMINDER_SEND_FROM_HOUR: int = 9
    REMINDER_SEND_TO_HOUR: int = 20
    REMINDER_TIMEZONE: str = "Asia/Ashgabat"
    # 0 = напоминать, пока технику не заберут. Иначе — не больше N напоминаний.
    REMINDER_MAX_COUNT: int = 0

    # --- Seed admin (first boot) ---
    SEED_ADMIN_EMAIL: str = "admin@msb.local"
    SEED_ADMIN_PASSWORD: str = "admin123"  # только dev; в ENV=prod обязательно заменить
    # Регион развёртывания — Туркменистан (+993).
    SEED_ADMIN_PHONE: str = "+99300000000"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

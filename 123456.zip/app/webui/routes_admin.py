"""Админ-страницы: сотрудники и настройки системы (принтер, этикетки, SMS,
общие параметры). Используют те же модели и сервисы, что и JSON-API."""
import base64
import uuid

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select

from app.core.security import hash_password
from app.db.models import PrintJob, User, UserRole
from app.db.session import async_session_factory
from app.services import settings as settings_svc
from app.webui.deps import bound_user, get_web_user
from app.webui.helpers import base_context
from app.webui.templating import render_async

router = APIRouter(tags=["webui-admin"])

ROLE_CHOICES = ["admin", "manager", "operator", "master", "callcenter"]


def _db():
    return async_session_factory()


async def _require_admin(request):
    webuser = await get_web_user(request)
    if not webuser.authenticated:
        return None, None, RedirectResponse("/login", status_code=303)
    if not webuser.user.has_role(UserRole.ADMIN.value):
        return None, None, HTMLResponse("Только администратор", status_code=403)
    db = _db()
    user = await bound_user(db, webuser)
    if user is None:
        await db.close()
        return None, None, RedirectResponse("/login", status_code=303)
    return db, user, None


@router.get("/admin/users", response_class=HTMLResponse)
async def admin_users(request: Request):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        users = (await db.execute(select(User).order_by(User.name))).scalars().all()
        ctx = await base_context(
            request, await get_web_user(request), active="/admin/users",
            users=users, roles=ROLE_CHOICES,
        )
        html = await render_async("admin/users.html", **ctx)
        return HTMLResponse(html)
    finally:
        await db.close()


@router.post("/admin/users/create")
async def admin_users_create(request: Request):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        email = f.get("email", "").lower().strip()
        exists = (await db.execute(select(User).where(User.email == email))).scalar_one_or_none()
        if exists:
            return HTMLResponse("Пользователь с таким email уже есть", status_code=409)
        u = User(
            name=f.get("name", "").strip(),
            email=email,
            phone=(f.get("phone") or "").strip() or None,
            password_hash=hash_password(f.get("password") or "changeme123"),
            role=f.get("role", "operator"),
            active=True,
        )
        db.add(u)
        await db.commit()
        return RedirectResponse("/admin/users", status_code=303)
    finally:
        await db.close()


@router.post("/admin/users/{user_id}/toggle")
async def admin_users_toggle(request: Request, user_id: uuid.UUID):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        if user_id == user.id:
            return HTMLResponse("Нельзя отключить самого себя", status_code=400)
        target = await db.get(User, user_id)
        if target:
            target.active = not target.active
            await db.commit()
        return RedirectResponse("/admin/users", status_code=303)
    finally:
        await db.close()


@router.post("/admin/users/{user_id}/role")
async def admin_users_role(request: Request, user_id: uuid.UUID):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        target = await db.get(User, user_id)
        if target and f.get("role") in ROLE_CHOICES:
            target.role = f.get("role")
            await db.commit()
        return RedirectResponse("/admin/users", status_code=303)
    finally:
        await db.close()


@router.post("/admin/users/{user_id}/reset-password")
async def admin_users_reset(request: Request, user_id: uuid.UUID):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        new_pass = f.get("new_password", "").strip()
        if len(new_pass) < 6:
            return HTMLResponse("Пароль должен быть не короче 6 символов", status_code=400)
        target = await db.get(User, user_id)
        if target:
            target.password_hash = hash_password(new_pass)
            await db.commit()
        return RedirectResponse("/admin/users", status_code=303)
    finally:
        await db.close()


# ==========================================================================
# Настройки системы (принтер, этикетки, SMS, общие параметры)
# ==========================================================================
def _fnum(v, default=None):
    try:
        s = str(v if v is not None else "").strip().replace(",", ".")
        return float(s) if s else default
    except (TypeError, ValueError):
        return default


@router.get("/admin/settings", response_class=HTMLResponse)
async def admin_settings(request: Request, section: str = "general", saved: str | None = None):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        printer = await settings_svc.get_printer(db)
        label = await settings_svc.get_label_printer(db)
        sms = await settings_svc.get_sms_server(db)
        sms_tpl = await settings_svc.get_sms_templates(db)
        storage = await settings_svc.get_setting(db, "storage_months", {"months": 3})
        brand = await settings_svc.get_setting(db, "brand", {"name": "MSB"})
        currency = await settings_svc.get_currency(db)
        legal_text = await settings_svc.get_legal_text(db)
        consent_text = await settings_svc.get_consent_repair_text(db)
        recent = (
            (
                await db.execute(
                    select(PrintJob).order_by(PrintJob.created_at.desc()).limit(8)
                )
            )
            .scalars()
            .all()
        )
        # Пароль SMS-шлюза не показываем (как и в JSON-API).
        sms_view = dict(sms)
        sms_view["password"] = "••••••••" if sms.get("password") else ""
        ctx = await base_context(
            request, await get_web_user(request), active="/admin/settings",
            section=section, saved=saved,
            printer=printer, label=label, sms=sms_view, sms_tpl=sms_tpl,
            storage=storage, brand=brand, currency=currency, recent_jobs=recent,
            settings_svc_legal=legal_text, settings_svc_consent=consent_text,
        )
        html = await render_async("admin/settings.html", **ctx)
        return HTMLResponse(html)
    finally:
        await db.close()


@router.post("/admin/settings/general")
async def admin_settings_general(request: Request):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        months = int(_fnum(f.get("storage_months"), 3) or 3)
        await settings_svc.set_setting(db, "storage_months", {"months": max(1, months)})
        await settings_svc.set_setting(
            db, "brand", {"name": (f.get("brand_name") or "MSB").strip() or "MSB"}
        )
        await settings_svc.set_setting(
            db,
            "currency",
            {
                "code": (f.get("currency_code") or "TMT").strip() or "TMT",
                "symbol": (f.get("currency_symbol") or "ман.").strip() or "ман.",
                "decimals": int(_fnum(f.get("currency_decimals"), 0) or 0),
            },
        )
        legal = (f.get("legal_text") or "").strip()
        if legal:
            await settings_svc.set_setting(db, "legal_text", {"text": legal})
        consent = (f.get("consent_repair_text") or "").strip()
        if consent:
            await settings_svc.set_setting(db, "consent_repair_text", {"text": consent})
        return RedirectResponse("/admin/settings?section=general&saved=1", status_code=303)
    finally:
        await db.close()


@router.post("/admin/settings/printer")
async def admin_settings_printer(request: Request):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        value = {
            "ip": (f.get("printer_ip") or "").strip(),
            "port": int(_fnum(f.get("printer_port"), 631) or 631),
            "mode": (f.get("printer_mode") or "agent").strip(),
            "name": (f.get("printer_name") or "").strip(),
        }
        await settings_svc.set_setting(
            db, "printer", value, "Принтер: IP, порт, режим печати (agent|ipp)"
        )
        return RedirectResponse("/admin/settings?section=printer&saved=1", status_code=303)
    finally:
        await db.close()


@router.post("/admin/settings/label")
async def admin_settings_label(request: Request):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        name = (f.get("label_name") or "").strip()
        ip = (f.get("label_ip") or "").strip()
        if not name or not ip:
            return HTMLResponse("Укажите IP компьютера с CUPS и имя очереди принтера", status_code=400)
        value = {
            "ip": ip,
            "port": int(_fnum(f.get("label_port"), 631) or 631),
            "mode": "cups_remote",
            "name": name,
            "width_mm": 58,
            "height_mm": 38,
            "media": (f.get("label_media") or "Custom.58x38mm").strip(),
        }
        await settings_svc.set_setting(db, "label_printer", value, "CUPS-принтер этикеток 58×38 мм")
        return RedirectResponse("/admin/settings?section=printer&saved=1", status_code=303)
    finally:
        await db.close()


@router.post("/admin/settings/sms")
async def admin_settings_sms(request: Request):
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        f = await request.form()
        current = await settings_svc.get_sms_server(db)
        password = f.get("password") or ""
        # Маскированная/пустая строка — не затираем сохранённый пароль.
        if not password or password.strip("•") == "":
            password = current.get("password", "")
        enabled = f.get("sms_enabled") in ("1", "on", "true", "True")
        value = {
            "enabled": enabled,
            "url": (f.get("sms_url") or "").strip(),
            "username": (f.get("sms_username") or "").strip(),
            "password": password,
            "verify_ssl": f.get("sms_verify_ssl") in ("1", "on", "true", "True"),
            "timeout_sec": _fnum(f.get("sms_timeout"), current.get("timeout_sec", 10.0)) or 10.0,
        }
        if enabled and not value["url"]:
            return HTMLResponse("При включённых SMS укажите адрес шлюза", status_code=400)
        await settings_svc.set_setting(db, "sms_server", value, "SMS-шлюз: адрес, логин/пароль, таймаут")

        await settings_svc.set_setting(
            db,
            "sms_templates",
            {
                "master_assign": (f.get("tpl_master") or "").strip(),
                "ready": (f.get("tpl_ready") or "").strip(),
                "pickup_reminder": (f.get("tpl_reminder") or "").strip(),
            },
            "Шаблоны текстов SMS",
        )
        return RedirectResponse("/admin/settings?section=sms&saved=1", status_code=303)
    finally:
        await db.close()


@router.post("/admin/settings/printer/test")
async def admin_settings_printer_test(request: Request):
    """Тестовая печать бланка А4 (кладёт PDF в очередь print-agent)."""
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        from app.services.print import render_blank_pdf

        printer = await settings_svc.get_printer(db)
        pdf = render_blank_pdf(
            template={"copies": 1, "signature": False},
            number="ТЕСТ-ПЕЧАТЬ", accepted_at="—", city_name="—", branch_name="—",
            client_name="Тестовая печать", client_phone="—", device="Проверка принтера",
            serial="—", complectation="—", fault="—", accepted_by="—", master="—",
            eta_days="", legal_text="", storage_until="—", qr_url="",
        )
        job = PrintJob(
            repair_id=None, template_id="test",
            payload={"pdf_base64": base64.b64encode(pdf).decode("ascii"), "printer": printer},
            status="queued",
        )
        db.add(job)
        await db.commit()
        return RedirectResponse("/admin/settings?section=printer&saved=test", status_code=303)
    finally:
        await db.close()


@router.post("/admin/settings/label/test")
async def admin_settings_label_test(request: Request):
    """Тестовая печать этикетки 58×38 (кладёт PDF в очередь)."""
    db, user, redir = await _require_admin(request)
    if redir:
        return redir
    try:
        from app.core.config import settings as cfg
        from app.services.print import render_repair_label_pdf

        printer = await settings_svc.get_label_printer(db)
        if not printer.get("name") or not printer.get("ip"):
            return HTMLResponse("Сначала настройте CUPS-принтер этикеток (IP и имя очереди)", status_code=400)
        repair_url = f"{cfg.PUBLIC_BASE_URL.rstrip('/')}/repairs"
        pdf = render_repair_label_pdf(
            repair_number="ТЕСТ-58x38", client_name="Тестовый клиент",
            client_phone="+993 61 000000", repair_url=repair_url,
            complectation="Пульт, Шнур питания", defects="Царапины, Линии на экране",
            width_mm=printer.get("width_mm", 58), height_mm=printer.get("height_mm", 38),
        )
        job = PrintJob(
            repair_id=None, template_id="label-test",
            payload={
                "document_kind": "repair_label",
                "pdf_base64": base64.b64encode(pdf).decode("ascii"),
                "printer": printer, "repair_url": repair_url,
            },
            status="queued",
        )
        db.add(job)
        await db.commit()
        return RedirectResponse("/admin/settings?section=printer&saved=test", status_code=303)
    finally:
        await db.close()

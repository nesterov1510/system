"""Smoke-тесты серверного веб-интерфейса на Jinja2 (замена React/Next.js).

Проверяем, что страницы рендерятся, авторизация идёт через httpOnly-cookie,
мастер не попадает в админ-разделы, а публичная страница не отдаёт внутренние
данные. Бизнес-логика — та же, что у JSON-API (покрыта 186 тестами).

Используем общую фикстуру `client` из conftest (засеяны admin/operator/master).
"""
import pytest


def _login(client, email="admin@msb.local", password="admin123"):
    r = client.post(
        "/login",
        data={"email": email, "password": password, "next_url": "/repairs"},
        follow_redirects=False,
    )
    assert r.status_code == 303, r.text
    return r.cookies


def test_login_page_renders_anon(client):
    r = client.get("/login")
    assert r.status_code == 200
    assert "MSB" in r.text and 'name="password"' in r.text


def test_protected_page_redirects_anon(client):
    r = client.get("/repairs", follow_redirects=False)
    assert r.status_code == 303
    assert "/login" in r.headers["location"]


def test_login_sets_http_only_cookies(client):
    r = client.post(
        "/login", data={"email": "admin@msb.local", "password": "admin123"},
        follow_redirects=False,
    )
    cookies = r.headers.get("set-cookie", "")
    assert "msb_access=" in cookies
    assert "httponly" in cookies.lower()


def test_bad_password_shows_error(client):
    r = client.post(
        "/login", data={"email": "admin@msb.local", "password": "wrong"},
        follow_redirects=False,
    )
    assert r.status_code == 401
    assert "Неверный email или пароль" in r.text


def test_logout_clears_session(client):
    client.post("/login", data={"email": "admin@msb.local", "password": "admin123"})
    r = client.get("/logout", follow_redirects=False)
    assert r.status_code == 303
    # После выхода защищённая страница снова уводит на логин.
    assert client.get("/repairs", follow_redirects=False).status_code == 303


@pytest.mark.parametrize("path", [
    "/repairs", "/repairs/new", "/clients", "/callcenter",
    "/parts", "/prices", "/notifications", "/dashboard", "/profile",
    "/chat", "/admin/users",
])
def test_all_main_pages_render_for_admin(client, path):
    cookies = _login(client)
    r = client.get(path, cookies=cookies)
    assert r.status_code == 200, f"{path} -> {r.status_code}: {r.text[:300]}"


def test_intake_flow_creates_repair_and_renders_card(client):
    cookies = _login(client)
    cities = client.get("/api/lookups/cities", cookies=cookies).json()
    r = client.post("/repairs/new", cookies=cookies, data={
        "city_id": cities[0]["id"],
        "full_name": "Веб Тестов",
        "phone": "+993 61 7778899",
        "device_type": "Телевизоры",
        "brand": "Samsung",
        "model": "QE55",
        "fault_client": "не включается",
        "consent_pdn": "1",
        "consent_storage": "1",
    }, follow_redirects=False)
    assert r.status_code == 303, r.text
    location = r.headers["location"]
    card = client.get(location, cookies=cookies)
    assert card.status_code == 200
    assert "Samsung" in card.text and "QE55" in card.text


def test_board_view_renders(client):
    cookies = _login(client)
    r = client.get("/repairs?view=board", cookies=cookies)
    assert r.status_code == 200
    assert "kanban" in r.text or "kcol" in r.text


def test_public_status_page_has_no_internal_data(client):
    cookies = _login(client)
    cities = client.get("/api/lookups/cities", cookies=cookies).json()
    r = client.post("/repairs/new", cookies=cookies, data={
        "city_id": cities[0]["id"],
        "full_name": "Публик Клиент",
        "phone": "+993 62 0001122",
        "device_type": "Другое",
        "fault_client": "неисправность клиента",
        "consent_pdn": "1", "consent_storage": "1",
    }, follow_redirects=False)
    rid = r.headers["location"].split("/repairs/")[1].split("?")[0]
    repair = client.get(f"/api/repairs/{rid}", cookies=cookies).json()
    pub = client.get(f"/r/{repair['public_token']}")
    assert pub.status_code == 200
    assert repair["number"] in pub.text
    # Внутренних данных и имени клиента на публичной странице нет.
    assert "fault_master" not in pub.text
    assert "Публик Клиент" not in pub.text


def test_master_blocked_from_admin_users(client):
    # master@msb.local засеян фикстурой conftest.
    r = client.post("/login", data={"email": "master@msb.local", "password": "master123"},
                    follow_redirects=False)
    assert r.status_code == 303
    page = client.get("/admin/users", cookies=r.cookies, follow_redirects=False)
    assert page.status_code in (403, 303)


def test_chat_message_sent_via_html_form(client):
    """Отправка сообщения — обычная HTML-форма (POST /chat/send -> 303 -> HTML),
    без fetch/JSON в браузере."""
    cookies = _login(client)
    # Открываем чат, берём id первого канала.
    import re

    page = client.get("/chat", cookies=cookies)
    assert page.status_code == 200
    m = re.search(r'name="channel_id"\s+value="([0-9a-f-]{36})"', page.text)
    assert m, "не найдена форма отправки сообщения"
    channel_id = m.group(1)
    r = client.post("/chat/send", cookies=cookies, data={
        "channel_id": channel_id, "text": "HTML-сообщение регресс",
    }, follow_redirects=False)
    assert r.status_code == 303
    # После редиректа (GET) страница чата — это text/html и содержит сообщение.
    target = r.headers["location"]
    after = client.get(target, cookies=cookies)
    assert after.status_code == 200
    assert "text/html" in after.headers["content-type"]
    assert "HTML-сообщение регресс" in after.text


def test_every_navigable_page_is_html(client):
    """Все страницы, доступные в браузере (GET), отдают text/html."""
    cookies = _login(client)
    paths = [
        "/", "/repairs", "/repairs?view=board", "/repairs/new", "/clients",
        "/callcenter", "/parts", "/prices", "/notifications", "/dashboard",
        "/chat", "/admin/users", "/profile", "/login",
    ]
    for path in paths:
        r = client.get(path, cookies=cookies, follow_redirects=True)
        assert r.status_code == 200, f"{path} -> {r.status_code}"
        assert "text/html" in r.headers["content-type"], f"{path} отдаёт {r.headers['content-type']}"


def test_master_can_open_repairs_list(client):
    r = client.post("/login", data={"email": "master@msb.local", "password": "master123"},
                    follow_redirects=False)
    page = client.get("/repairs", cookies=r.cookies)
    assert page.status_code == 200


def test_notifications_page_renders_and_mark_read(client):
    """Страница уведомлений отдаёт HTML и доступна любому сотруднику."""
    cookies = _login(client)
    r = client.get("/notifications", cookies=cookies)
    assert r.status_code == 200
    assert "text/html" in r.headers["content-type"]
    # «Прочитать все» без непрочитанных — корректный PRG-редирект.
    rr = client.post("/notifications/read-all", cookies=cookies, follow_redirects=False)
    assert rr.status_code == 303
    assert rr.headers["location"] == "/notifications"


def test_parts_page_has_equipment_section(client):
    """Склад показывает блок купленной техники (доноров)."""
    cookies = _login(client)
    r = client.post("/equipment/create", cookies=cookies, data={
        "name": "LG 32 — донор", "brand": "LG", "purchase_price": "120",
        "storage_place": "Полка 1",
    }, follow_redirects=False)
    assert r.status_code == 303
    page = client.get("/parts", cookies=cookies)
    assert page.status_code == 200
    assert "LG 32" in page.text


def test_prices_page_and_create(client):
    """Прайс-лист: страница и форма добавления позиции."""
    cookies = _login(client)
    r = client.post("/prices/create", cookies=cookies, data={
        "device_type": "Телевизоры", "fault": "Замена разъёма питания",
        "price_min": "100", "price_max": "250", "price_avg": "180",
    }, follow_redirects=False)
    assert r.status_code == 303
    page = client.get("/prices", cookies=cookies)
    assert page.status_code == 200
    assert "Замена разъёма питания" in page.text


def test_admin_settings_page_sections(client):
    """Страница настроек доступна админу во всех вкладках и отдаёт HTML."""
    cookies = _login(client)
    for section in ("general", "printer", "sms"):
        r = client.get(f"/admin/settings?section={section}", cookies=cookies)
        assert r.status_code == 200, f"{section}: {r.status_code}"
        assert "text/html" in r.headers["content-type"]


def test_admin_settings_save_printer_and_general(client):
    cookies = _login(client)
    r = client.post("/admin/settings/printer", cookies=cookies, data={
        "printer_mode": "agent", "printer_name": "EPSON_TEST", "printer_port": "631",
    }, follow_redirects=False)
    assert r.status_code == 303
    page = client.get("/admin/settings?section=printer", cookies=cookies)
    assert "EPSON_TEST" in page.text
    r2 = client.post("/admin/settings/general", cookies=cookies, data={
        "brand_name": "MSB", "storage_months": "5",
        "currency_code": "TMT", "currency_symbol": "ман.", "currency_decimals": "0",
    }, follow_redirects=False)
    assert r2.status_code == 303


def test_admin_settings_requires_admin(client):
    """Обычный сотрудник (master) не получает доступ к настройкам."""
    r = client.post("/login", data={"email": "master@msb.local", "password": "master123"},
                    follow_redirects=False)
    page = client.get("/admin/settings", cookies=r.cookies, follow_redirects=False)
    assert page.status_code in (403, 303)


def test_intake_rich_form_fields(client):
    """Богатая форма приёмки: экран выбора + все поля эталона рендерятся."""
    cookies = _login(client)
    r = client.get("/repairs/new", cookies=cookies)
    assert r.status_code == 200
    assert "Выберите тип техники" in r.text
    f = client.get("/repairs/new?type=Телевизоры", cookies=cookies)
    assert f.status_code == 200
    for marker in ('data-tv-intake', 'name="equipment"', 'name="condition"',
                   'data-delivery-open', 'data-camera-open', 'name="contact2_relation"',
                   'name="fault_client"', 'name="delivery_district"'):
        assert marker in f.text, marker


def test_intake_create_persists_archive_fields(client):
    """Приёмка сохраняет комплектацию, состояние, доставку и второй контакт."""
    cookies = _login(client)
    # узнаём city_id из формы
    page = client.get("/repairs/new?type=Телевизоры", cookies=cookies).text
    import re, uuid
    m = re.search(r'name="city_id" value="([0-9a-f-]+)"', page)
    cid = m.group(1)
    r = client.post("/repairs/new", cookies=cookies, data={
        "city_id": cid, "device_type": "Телевизоры",
        "brand_manual": "LG", "model_manual": "OLED55", "serial_manual": "SN9",
        "equipment": ["remote", "power_cable"], "equipment_other": "документы",
        "condition": ["screen_scratches"], "condition_other": "скол корпуса",
        "fault_client": "не включается",
        "full_name": "Архив Тест", "phone": "+99361000000",
        "contact2_name": "Второй", "contact2_phone": "+99362000000",
        "contact2_relation": "Доставщик",
        "is_delivery": "1", "delivery_district": "Парахат 1",
        "consent_pdn": "1", "consent_storage": "1", "consent_repair": "1",
    }, follow_redirects=False)
    assert r.status_code == 303
    rid = r.headers["location"].rstrip("/").split("/")[-1].split("?")[0]
    from app.db import models
    # ремонт существует и поля записаны
    assert uuid.UUID(rid)

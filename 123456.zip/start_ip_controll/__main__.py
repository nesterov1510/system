"""Запуск uvicorn с host/port из start_ip_controll.

Использование:
    python -m start_ip_controll

Берёт ``host``/``port`` из ``ip_controll.env`` (или переменных окружения) и
поднимает приложение ``app.main:app``. Файл env можно переопределить:
    IP_CONTROLL_ENV=/path/to/ip_controll.env python -m start_ip_controll
"""
from __future__ import annotations

import logging
import sys

import uvicorn

from .ip_controll import get_server_start_config

# Пакеты, без которых приложение не стартует (имя для импорта -> имя в pip).
_REQUIRED = {
    "pydantic_settings": "pydantic-settings",
    "pydantic": "pydantic",
    "fastapi": "fastapi",
    "sqlalchemy": "sqlalchemy",
    "jinja2": "jinja2",
    "reportlab": "reportlab",
    "qrcode": "qrcode[pil]",
    "jwt": "PyJWT",
    "bcrypt": "bcrypt",
    "multipart": "python-multipart",
    "httpx": "httpx",
    "requests": "requests",
    "asyncpg": "asyncpg",
    "aiosqlite": "aiosqlite",
}


def _check_dependencies() -> None:
    """Дать понятную ошибку, если в текущем интерпретаторе нет зависимостей."""
    missing = []
    for module, pip_name in _REQUIRED.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(pip_name)
    if missing:
        logging.getLogger("start_ip_controll").error(
            "В текущем интерпретаторе (%s) не установлены зависимости: %s\n"
            "Установите их ТЕМ ЖЕ интерпретатором, которым запускаете сервис:\n"
            "  %s -m pip install -r requirements.txt\n"
            "Либо (если пакеты кладёте в каталог пользователя):\n"
            "  %s -m pip install --user -r requirements.txt\n"
            "После установки перезапустите сервис: systemctl restart msb-api",
            sys.executable,
            ", ".join(sorted(set(missing))),
            sys.executable,
            sys.executable,
        )
        raise SystemExit(1)


def main() -> None:
    logging.basicConfig(level=logging.INFO)
    cfg = get_server_start_config()
    _check_dependencies()
    uvicorn.run("app.main:app", host=cfg.host, port=cfg.port, workers=1)


if __name__ == "__main__":
    main()
